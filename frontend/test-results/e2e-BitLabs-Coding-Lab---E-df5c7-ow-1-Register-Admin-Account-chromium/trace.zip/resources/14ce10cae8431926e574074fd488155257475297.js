import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/Sidebar.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1cbb189e"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/components/layout/Sidebar.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { NavLink } from "/node_modules/.vite/deps/react-router-dom.js?v=1cbb189e";
export default function Sidebar({ role }) {
  const links = role === "candidate" ? [
    { to: "/candidate/dashboard", label: "Candidate Dashboard" },
    { to: "/practice", label: "Practice Arena" }
  ] : [
    { to: "/recruiter/dashboard", label: "Recruiter Dashboard" },
    { to: "/recruiter/assessments/new", label: "New Assessment" }
  ];
  return /* @__PURE__ */ jsxDEV("aside", { className: "hidden min-h-[calc(100vh-4rem)] w-64 border-r border-slate-200 bg-white p-4 lg:block", children: /* @__PURE__ */ jsxDEV("nav", { className: "space-y-1", children: links.map(
    (link) => /* @__PURE__ */ jsxDEV(
      NavLink,
      {
        to: link.to,
        className: ({ isActive }) => [
          "block rounded-md px-3 py-2 text-sm font-medium transition",
          isActive ? "bg-brand-50 text-brand-700 font-semibold" : "text-slate-600 hover:bg-slate-100 hover:text-slate-950"
        ].join(" "),
        children: link.label
      },
      link.to,
      false,
      {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/components/layout/Sidebar.tsx",
        lineNumber: 42,
        columnNumber: 9
      },
      this
    )
  ) }, void 0, false, {
    fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/components/layout/Sidebar.tsx",
    lineNumber: 40,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/components/layout/Sidebar.tsx",
    lineNumber: 39,
    columnNumber: 5
  }, this);
}
_c = Sidebar;
var _c;
$RefreshReg$(_c, "Sidebar");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/components/layout/Sidebar.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/components/layout/Sidebar.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0JVOzs7Ozs7Ozs7Ozs7Ozs7O0FBdEJWLFNBQVNBLGVBQWU7QUFNeEIsd0JBQXdCQyxRQUFRLEVBQUVDLEtBQW1CLEdBQUc7QUFDdEQsUUFBTUMsUUFDSkQsU0FBUyxjQUNMO0FBQUEsSUFDRSxFQUFFRSxJQUFJLHdCQUF3QkMsT0FBTyxzQkFBc0I7QUFBQSxJQUMzRCxFQUFFRCxJQUFJLGFBQWFDLE9BQU8saUJBQWlCO0FBQUEsRUFBQyxJQUU5QztBQUFBLElBQ0UsRUFBRUQsSUFBSSx3QkFBd0JDLE9BQU8sc0JBQXNCO0FBQUEsSUFDM0QsRUFBRUQsSUFBSSw4QkFBOEJDLE9BQU8saUJBQWlCO0FBQUEsRUFBQztBQUdyRSxTQUNFLHVCQUFDLFdBQU0sV0FBVSx3RkFDZixpQ0FBQyxTQUFJLFdBQVUsYUFDWkYsZ0JBQU1HO0FBQUFBLElBQUksQ0FBQ0MsU0FDVjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBRUMsSUFBSUEsS0FBS0g7QUFBQUEsUUFDVCxXQUFXLENBQUMsRUFBRUksU0FBUyxNQUNyQjtBQUFBLFVBQ0U7QUFBQSxVQUNBQSxXQUFXLDZDQUE2QztBQUFBLFFBQXdELEVBQ2hIQyxLQUFLLEdBQUc7QUFBQSxRQUdYRixlQUFLRjtBQUFBQTtBQUFBQSxNQVRERSxLQUFLSDtBQUFBQSxNQURaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFXQTtBQUFBLEVBQ0QsS0FkSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBZUEsS0FoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWlCQTtBQUVKO0FBQUNNLEtBaEN1QlQ7QUFBTyxJQUFBUztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJOYXZMaW5rIiwiU2lkZWJhciIsInJvbGUiLCJsaW5rcyIsInRvIiwibGFiZWwiLCJtYXAiLCJsaW5rIiwiaXNBY3RpdmUiLCJqb2luIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiU2lkZWJhci50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTmF2TGluayB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XG5cbnR5cGUgU2lkZWJhclByb3BzID0ge1xuICByb2xlOiBcInJlY3J1aXRlclwiIHwgXCJjYW5kaWRhdGVcIjtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFNpZGViYXIoeyByb2xlIH06IFNpZGViYXJQcm9wcykge1xuICBjb25zdCBsaW5rcyA9XG4gICAgcm9sZSA9PT0gXCJjYW5kaWRhdGVcIlxuICAgICAgPyBbXG4gICAgICAgICAgeyB0bzogXCIvY2FuZGlkYXRlL2Rhc2hib2FyZFwiLCBsYWJlbDogXCJDYW5kaWRhdGUgRGFzaGJvYXJkXCIgfSxcbiAgICAgICAgICB7IHRvOiBcIi9wcmFjdGljZVwiLCBsYWJlbDogXCJQcmFjdGljZSBBcmVuYVwiIH0sXG4gICAgICAgIF1cbiAgICAgIDogW1xuICAgICAgICAgIHsgdG86IFwiL3JlY3J1aXRlci9kYXNoYm9hcmRcIiwgbGFiZWw6IFwiUmVjcnVpdGVyIERhc2hib2FyZFwiIH0sXG4gICAgICAgICAgeyB0bzogXCIvcmVjcnVpdGVyL2Fzc2Vzc21lbnRzL25ld1wiLCBsYWJlbDogXCJOZXcgQXNzZXNzbWVudFwiIH0sXG4gICAgICAgIF07XG5cbiAgcmV0dXJuIChcbiAgICA8YXNpZGUgY2xhc3NOYW1lPVwiaGlkZGVuIG1pbi1oLVtjYWxjKDEwMHZoLTRyZW0pXSB3LTY0IGJvcmRlci1yIGJvcmRlci1zbGF0ZS0yMDAgYmctd2hpdGUgcC00IGxnOmJsb2NrXCI+XG4gICAgICA8bmF2IGNsYXNzTmFtZT1cInNwYWNlLXktMVwiPlxuICAgICAgICB7bGlua3MubWFwKChsaW5rKSA9PiAoXG4gICAgICAgICAgPE5hdkxpbmtcbiAgICAgICAgICAgIGtleT17bGluay50b31cbiAgICAgICAgICAgIHRvPXtsaW5rLnRvfVxuICAgICAgICAgICAgY2xhc3NOYW1lPXsoeyBpc0FjdGl2ZSB9KSA9PlxuICAgICAgICAgICAgICBbXG4gICAgICAgICAgICAgICAgXCJibG9jayByb3VuZGVkLW1kIHB4LTMgcHktMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRyYW5zaXRpb25cIixcbiAgICAgICAgICAgICAgICBpc0FjdGl2ZSA/IFwiYmctYnJhbmQtNTAgdGV4dC1icmFuZC03MDAgZm9udC1zZW1pYm9sZFwiIDogXCJ0ZXh0LXNsYXRlLTYwMCBob3ZlcjpiZy1zbGF0ZS0xMDAgaG92ZXI6dGV4dC1zbGF0ZS05NTBcIlxuICAgICAgICAgICAgICBdLmpvaW4oXCIgXCIpXG4gICAgICAgICAgICB9XG4gICAgICAgICAgPlxuICAgICAgICAgICAge2xpbmsubGFiZWx9XG4gICAgICAgICAgPC9OYXZMaW5rPlxuICAgICAgICApKX1cbiAgICAgIDwvbmF2PlxuICAgIDwvYXNpZGU+XG4gICk7XG59XG4iXSwiZmlsZSI6IkM6L1VzZXJzL1lhc3dhbnRoIFJhaHVsL0Rvd25sb2Fkcy9CaXRMYWJzLUNvZGluZy1MYWIvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvbGF5b3V0L1NpZGViYXIudHN4In0=