import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/AssessmentBuilder.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1cbb189e"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=1cbb189e"; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=1cbb189e";
import toast from "/node_modules/.vite/deps/react-hot-toast.js?v=1cbb189e";
import { createAssessment, generateAITests } from "/src/api/assessments.ts";
import Button from "/src/components/ui/Button.tsx";
import Spinner from "/src/components/ui/Spinner.tsx";
const supportedLanguages = ["Python", "C", "C++", "Java", "JavaScript"];
const emptyTestRow = () => ({
  id: crypto.randomUUID(),
  input: "",
  expected_output: "",
  is_hidden: false,
  is_edge_case: false
});
export default function AssessmentBuilder() {
  _s();
  const navigate = useNavigate();
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [difficulty, setDifficulty] = useState("easy");
  const [timeLimitMins, setTimeLimitMins] = useState(30);
  const [languageSupport, setLanguageSupport] = useState(["Python"]);
  const [problemStatement, setProblemStatement] = useState("");
  const [constraints, setConstraints] = useState("");
  const [examples, setExamples] = useState("");
  const [manualTests, setManualTests] = useState([emptyTestRow()]);
  const [aiGeneratedTests, setAiGeneratedTests] = useState([]);
  const [activeTab, setActiveTab] = useState("manual");
  const [aiLoading, setAiLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [starterCode, setStarterCode] = useState({});
  const normalizedLanguages = useMemo(
    () => languageSupport.map((language) => language.toLowerCase()).filter(Boolean),
    [languageSupport]
  );
  const toggleLanguage = (language) => {
    setLanguageSupport((current) => {
      if (current.includes(language)) {
        return current.filter((item) => item !== language);
      }
      return [...current, language];
    });
  };
  const updateManualRow = (index, field, value) => {
    setManualTests(
      (current) => current.map((row, rowIndex) => {
        if (rowIndex !== index) return row;
        return {
          ...row,
          [field]: value
        };
      })
    );
  };
  const addManualRow = () => {
    setManualTests((current) => [...current, emptyTestRow()]);
  };
  const removeManualRow = (index) => {
    setManualTests((current) => current.filter((_, rowIndex) => rowIndex !== index));
  };
  const handleImportAITests = () => {
    const imported = aiGeneratedTests.map((item) => ({
      id: crypto.randomUUID(),
      input: item.input,
      expected_output: item.expected_output,
      is_hidden: item.type === "hidden",
      is_edge_case: item.type === "edge"
    }));
    setManualTests((current) => {
      const filtered = current.filter((r) => r.input.trim() || r.expected_output.trim());
      return [...filtered, ...imported];
    });
    setActiveTab("manual");
    toast.success("AI test cases imported to the manual list.");
  };
  const handleGenerateAITests = async () => {
    if (!problemStatement.trim()) {
      toast.error("Problem statement is required before generating AI tests.");
      return;
    }
    try {
      setAiLoading(true);
      const generated = await generateAITests({
        problem_statement: problemStatement,
        language: normalizedLanguages[0] ?? "python",
        difficulty
      });
      const merged = [];
      const addGenerated = (source, type) => {
        for (const item of source) {
          merged.push({
            input: item.input,
            expected_output: item.expected_output,
            type
          });
        }
      };
      addGenerated(generated.visible_tests ?? [], "visible");
      addGenerated(generated.hidden_tests ?? [], "hidden");
      addGenerated(generated.edge_cases ?? [], "edge");
      setAiGeneratedTests(merged);
      setActiveTab("ai");
      toast.success("AI-generated test cases were produced.");
    } catch (error) {
      toast.error("AI test generation failed.");
    } finally {
      setAiLoading(false);
    }
  };
  const handleCreateAssessment = async () => {
    if (!title.trim() || !problemStatement.trim()) {
      toast.error("Assessment title and problem statement are required.");
      return;
    }
    try {
      setSubmitting(true);
      const payload = {
        title: title.trim(),
        description: description.trim(),
        difficulty,
        time_limit_mins: Number(timeLimitMins) || 30,
        language_support: normalizedLanguages,
        questions: [
          {
            problem_statement: problemStatement.trim(),
            constraints: constraints.trim(),
            examples: examples.trim() ? { example_1: examples.trim() } : {},
            starter_code: starterCode,
            test_cases: (manualTests.length ? manualTests : [emptyTestRow()]).filter((row) => row.input.trim() || row.expected_output.trim()).map((row) => ({
              input: row.input.trim(),
              expected_output: row.expected_output.trim(),
              is_hidden: row.is_hidden,
              is_edge_case: row.is_edge_case
            }))
          }
        ]
      };
      await createAssessment(payload);
      toast.success("Assessment created successfully.");
      navigate("/recruiter/dashboard");
    } catch (error) {
      toast.error("Assessment creation failed.");
    } finally {
      setSubmitting(false);
    }
  };
  return /* @__PURE__ */ jsxDEV("section", { className: "mx-auto max-w-5xl space-y-6", children: [
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-semibold text-slate-950", children: "Assessment Builder" }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
        lineNumber: 186,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-slate-600", children: "Create coding challenges with test cases and AI-assisted generation." }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
        lineNumber: 187,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
      lineNumber: 185,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "space-y-6 rounded-xl border border-slate-200 bg-white p-6 shadow-sm", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-slate-900", children: "Assessment Details" }, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
          lineNumber: 192,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid gap-4 md:grid-cols-2", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "md:col-span-2 block", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "mb-1 block text-sm font-medium text-slate-700", children: "Title" }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
              lineNumber: 195,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("input", { value: title, onChange: (event) => setTitle(event.target.value), className: "w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-slate-900 outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-100", required: true }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
              lineNumber: 196,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
            lineNumber: 194,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "md:col-span-2 block", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "mb-1 block text-sm font-medium text-slate-700", children: "Description" }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
              lineNumber: 200,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("textarea", { value: description, onChange: (event) => setDescription(event.target.value), className: "min-h-28 w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-slate-900 outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-100" }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
              lineNumber: 201,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
            lineNumber: 199,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "block", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "mb-1 block text-sm font-medium text-slate-700", children: "Difficulty" }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
              lineNumber: 205,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("select", { value: difficulty, onChange: (event) => setDifficulty(event.target.value), className: "w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-slate-900 outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-100", children: [
              /* @__PURE__ */ jsxDEV("option", { value: "easy", children: "easy" }, void 0, false, {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
                lineNumber: 207,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "medium", children: "medium" }, void 0, false, {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
                lineNumber: 208,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "hard", children: "hard" }, void 0, false, {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
                lineNumber: 209,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
              lineNumber: 206,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
            lineNumber: 204,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "block", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "mb-1 block text-sm font-medium text-slate-700", children: "Time Limit (minutes)" }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
              lineNumber: 214,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "number", min: 5, value: timeLimitMins, onChange: (event) => setTimeLimitMins(Number(event.target.value) || 30), className: "w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-slate-900 outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-100" }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
              lineNumber: 215,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
            lineNumber: 213,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
          lineNumber: 193,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("span", { className: "mb-2 block text-sm font-medium text-slate-700", children: "Supported Languages" }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
            lineNumber: 220,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-3", children: supportedLanguages.map(
            (language) => /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 rounded-md border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-700", children: [
              /* @__PURE__ */ jsxDEV("input", { type: "checkbox", checked: languageSupport.includes(language), onChange: () => toggleLanguage(language), className: "h-4 w-4" }, void 0, false, {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
                lineNumber: 224,
                columnNumber: 19
              }, this),
              language
            ] }, language, true, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
              lineNumber: 223,
              columnNumber: 15
            }, this)
          ) }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
            lineNumber: 221,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
          lineNumber: 219,
          columnNumber: 11
        }, this),
        languageSupport.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "space-y-4 border-t border-slate-100 pt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "mb-1 block text-sm font-medium text-slate-700", children: "Starter Code (Optional)" }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
            lineNumber: 233,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-slate-500", children: "Provide starter code templates that candidates will see when starting the challenge in each supported language." }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
            lineNumber: 234,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid gap-4 md:grid-cols-2", children: languageSupport.map((lang) => {
            const langKey = lang.toLowerCase();
            return /* @__PURE__ */ jsxDEV("label", { className: "block rounded-lg border border-slate-100 bg-slate-50 p-4", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "mb-2 block text-xs font-semibold uppercase tracking-wider text-slate-500", children: [
                lang,
                " Starter Code"
              ] }, void 0, true, {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
                lineNumber: 240,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                "textarea",
                {
                  value: starterCode[langKey] || "",
                  onChange: (e) => {
                    const val = e.target.value;
                    setStarterCode((prev) => ({ ...prev, [langKey]: val }));
                  },
                  className: "min-h-24 w-full rounded-md border border-slate-300 bg-white font-mono px-3 py-2 text-sm text-slate-900 outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-100",
                  placeholder: `// Starter code for ${lang}...`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
                  lineNumber: 241,
                  columnNumber: 23
                },
                this
              )
            ] }, lang, true, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
              lineNumber: 239,
              columnNumber: 19
            }, this);
          }) }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
            lineNumber: 235,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
          lineNumber: 232,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
        lineNumber: 191,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-4 border-t border-slate-200 pt-6", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-slate-900", children: "Problem Statement" }, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
          lineNumber: 259,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("label", { className: "block", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "mb-1 block text-sm font-medium text-slate-700", children: "Problem Statement" }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
            lineNumber: 261,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("textarea", { value: problemStatement, onChange: (event) => setProblemStatement(event.target.value), className: "min-h-36 w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-slate-900 outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-100", required: true }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
            lineNumber: 262,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
          lineNumber: 260,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("label", { className: "block", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "mb-1 block text-sm font-medium text-slate-700", children: "Constraints" }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
            lineNumber: 265,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("textarea", { value: constraints, onChange: (event) => setConstraints(event.target.value), className: "min-h-20 w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-slate-900 outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-100" }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
            lineNumber: 266,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
          lineNumber: 264,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("label", { className: "block", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "mb-1 block text-sm font-medium text-slate-700", children: "Examples" }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
            lineNumber: 269,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("textarea", { value: examples, onChange: (event) => setExamples(event.target.value), className: "min-h-20 w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-slate-900 outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-100", placeholder: "Input: 5 -> Output: 10" }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
            lineNumber: 270,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
          lineNumber: 268,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
        lineNumber: 258,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-4 border-t border-slate-200 pt-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-slate-900", children: "Test Cases" }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
            lineNumber: 276,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex rounded-lg border border-slate-200 bg-slate-50 p-1", children: [
            /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => setActiveTab("manual"), className: `rounded-md px-3 py-1.5 text-sm font-medium ${activeTab === "manual" ? "bg-white text-slate-900 shadow-sm" : "text-slate-600"}`, children: "Add Manually" }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
              lineNumber: 278,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => setActiveTab("ai"), className: `rounded-md px-3 py-1.5 text-sm font-medium ${activeTab === "ai" ? "bg-white text-slate-900 shadow-sm" : "text-slate-600"}`, children: "Generate with AI" }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
              lineNumber: 281,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
            lineNumber: 277,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
          lineNumber: 275,
          columnNumber: 11
        }, this),
        activeTab === "manual" ? /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "overflow-hidden rounded-lg border border-slate-200", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full text-left text-sm", children: [
            /* @__PURE__ */ jsxDEV("thead", { className: "bg-slate-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
              /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 font-semibold text-slate-600", children: "Input" }, void 0, false, {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
                lineNumber: 293,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 font-semibold text-slate-600", children: "Expected Output" }, void 0, false, {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
                lineNumber: 294,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 font-semibold text-slate-600", children: "Hidden?" }, void 0, false, {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
                lineNumber: 295,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 font-semibold text-slate-600", children: "Edge Case?" }, void 0, false, {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
                lineNumber: 296,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 font-semibold text-slate-600", children: "Remove" }, void 0, false, {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
                lineNumber: 297,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
              lineNumber: 292,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
              lineNumber: 291,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("tbody", { children: manualTests.map(
              (row, index) => /* @__PURE__ */ jsxDEV("tr", { className: "border-t border-slate-200", children: [
                /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2", children: /* @__PURE__ */ jsxDEV("input", { value: row.input, onChange: (event) => updateManualRow(index, "input", event.target.value), className: "w-full rounded-md border border-slate-300 bg-white px-2 py-1.5 text-slate-900 outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-100" }, void 0, false, {
                  fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
                  lineNumber: 303,
                  columnNumber: 51
                }, this) }, void 0, false, {
                  fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
                  lineNumber: 303,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2", children: /* @__PURE__ */ jsxDEV("input", { value: row.expected_output, onChange: (event) => updateManualRow(index, "expected_output", event.target.value), className: "w-full rounded-md border border-slate-300 bg-white px-2 py-1.5 text-slate-900 outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-100" }, void 0, false, {
                  fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
                  lineNumber: 304,
                  columnNumber: 51
                }, this) }, void 0, false, {
                  fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
                  lineNumber: 304,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2", children: /* @__PURE__ */ jsxDEV("input", { type: "checkbox", checked: row.is_hidden, onChange: (event) => updateManualRow(index, "is_hidden", event.target.checked), className: "h-4 w-4" }, void 0, false, {
                  fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
                  lineNumber: 305,
                  columnNumber: 51
                }, this) }, void 0, false, {
                  fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
                  lineNumber: 305,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2", children: /* @__PURE__ */ jsxDEV("input", { type: "checkbox", checked: row.is_edge_case, onChange: (event) => updateManualRow(index, "is_edge_case", event.target.checked), className: "h-4 w-4" }, void 0, false, {
                  fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
                  lineNumber: 306,
                  columnNumber: 51
                }, this) }, void 0, false, {
                  fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
                  lineNumber: 306,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2", children: /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => removeManualRow(index), className: "text-sm font-medium text-red-600 hover:text-red-700", children: "Remove" }, void 0, false, {
                  fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
                  lineNumber: 307,
                  columnNumber: 51
                }, this) }, void 0, false, {
                  fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
                  lineNumber: 307,
                  columnNumber: 25
                }, this)
              ] }, row.id, true, {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
                lineNumber: 302,
                columnNumber: 19
              }, this)
            ) }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
              lineNumber: 300,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
            lineNumber: 290,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
            lineNumber: 289,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { type: "button", variant: "secondary", onClick: addManualRow, children: "Add Row" }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
            lineNumber: 313,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
          lineNumber: 288,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
          /* @__PURE__ */ jsxDEV(Button, { type: "button", className: "min-w-44", disabled: aiLoading, onClick: handleGenerateAITests, children: aiLoading ? /* @__PURE__ */ jsxDEV(Spinner, { label: "Generating" }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
            lineNumber: 318,
            columnNumber: 30
          }, this) : "Generate Test Cases" }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
            lineNumber: 317,
            columnNumber: 15
          }, this),
          aiGeneratedTests.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "overflow-hidden rounded-lg border border-slate-200", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full text-left text-sm", children: [
              /* @__PURE__ */ jsxDEV("thead", { className: "bg-slate-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
                /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 font-semibold text-slate-600", children: "Input" }, void 0, false, {
                  fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
                  lineNumber: 327,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 font-semibold text-slate-600", children: "Expected Output" }, void 0, false, {
                  fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
                  lineNumber: 328,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 font-semibold text-slate-600", children: "Type" }, void 0, false, {
                  fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
                  lineNumber: 329,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
                lineNumber: 326,
                columnNumber: 25
              }, this) }, void 0, false, {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
                lineNumber: 325,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("tbody", { children: aiGeneratedTests.map(
                (row, index) => /* @__PURE__ */ jsxDEV("tr", { className: "border-t border-slate-200", children: [
                  /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2", children: row.input }, void 0, false, {
                    fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
                    lineNumber: 335,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2", children: row.expected_output }, void 0, false, {
                    fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
                    lineNumber: 336,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 capitalize", children: row.type }, void 0, false, {
                    fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
                    lineNumber: 337,
                    columnNumber: 29
                  }, this)
                ] }, `${row.type}-${index}`, true, {
                  fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
                  lineNumber: 334,
                  columnNumber: 21
                }, this)
              ) }, void 0, false, {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
                lineNumber: 332,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
              lineNumber: 324,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
              lineNumber: 323,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(Button, { type: "button", onClick: handleImportAITests, children: "Import to Manual List" }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
              lineNumber: 343,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
            lineNumber: 322,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
          lineNumber: 316,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
        lineNumber: 274,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end border-t border-slate-200 pt-6", children: /* @__PURE__ */ jsxDEV(Button, { type: "button", disabled: submitting, onClick: handleCreateAssessment, children: submitting ? /* @__PURE__ */ jsxDEV(Spinner, { label: "Creating" }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
        lineNumber: 354,
        columnNumber: 27
      }, this) : "Create Assessment" }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
        lineNumber: 353,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
        lineNumber: 352,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
      lineNumber: 190,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx",
    lineNumber: 184,
    columnNumber: 5
  }, this);
}
_s(AssessmentBuilder, "7MPvBstf+NOX+oTNV/EasKfQdnc=", false, function() {
  return [useNavigate];
});
_c = AssessmentBuilder;
var _c;
$RefreshReg$(_c, "AssessmentBuilder");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AssessmentBuilder.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0tROzs7Ozs7Ozs7Ozs7Ozs7OztBQXRLUixTQUFTQSxTQUFTQyxnQkFBZ0I7QUFDbEMsU0FBU0MsbUJBQW1CO0FBQzVCLE9BQU9DLFdBQVc7QUFDbEIsU0FBU0Msa0JBQWtCQyx1QkFBNkQ7QUFDeEYsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxhQUFhO0FBRXBCLE1BQU1DLHFCQUFxQixDQUFDLFVBQVUsS0FBSyxPQUFPLFFBQVEsWUFBWTtBQUV0RSxNQUFNQyxlQUFlQSxPQUE0QztBQUFBLEVBQy9EQyxJQUFJQyxPQUFPQyxXQUFXO0FBQUEsRUFDdEJDLE9BQU87QUFBQSxFQUNQQyxpQkFBaUI7QUFBQSxFQUNqQkMsV0FBVztBQUFBLEVBQ1hDLGNBQWM7QUFDaEI7QUFFQSx3QkFBd0JDLG9CQUFvQjtBQUFBQyxLQUFBO0FBQzFDLFFBQU1DLFdBQVdqQixZQUFZO0FBQzdCLFFBQU0sQ0FBQ2tCLE9BQU9DLFFBQVEsSUFBSXBCLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNxQixhQUFhQyxjQUFjLElBQUl0QixTQUFTLEVBQUU7QUFDakQsUUFBTSxDQUFDdUIsWUFBWUMsYUFBYSxJQUFJeEIsU0FBUyxNQUFNO0FBQ25ELFFBQU0sQ0FBQ3lCLGVBQWVDLGdCQUFnQixJQUFJMUIsU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQzJCLGlCQUFpQkMsa0JBQWtCLElBQUk1QixTQUFtQixDQUFDLFFBQVEsQ0FBQztBQUMzRSxRQUFNLENBQUM2QixrQkFBa0JDLG1CQUFtQixJQUFJOUIsU0FBUyxFQUFFO0FBQzNELFFBQU0sQ0FBQytCLGFBQWFDLGNBQWMsSUFBSWhDLFNBQVMsRUFBRTtBQUNqRCxRQUFNLENBQUNpQyxVQUFVQyxXQUFXLElBQUlsQyxTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDbUMsYUFBYUMsY0FBYyxJQUFJcEMsU0FBcUQsQ0FBQ1EsYUFBYSxDQUFDLENBQUM7QUFDM0csUUFBTSxDQUFDNkIsa0JBQWtCQyxtQkFBbUIsSUFBSXRDLFNBQWlHLEVBQUU7QUFDbkosUUFBTSxDQUFDdUMsV0FBV0MsWUFBWSxJQUFJeEMsU0FBMEIsUUFBUTtBQUNwRSxRQUFNLENBQUN5QyxXQUFXQyxZQUFZLElBQUkxQyxTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDMkMsWUFBWUMsYUFBYSxJQUFJNUMsU0FBUyxLQUFLO0FBQ2xELFFBQU0sQ0FBQzZDLGFBQWFDLGNBQWMsSUFBSTlDLFNBQWlDLENBQUMsQ0FBQztBQUV6RSxRQUFNK0Msc0JBQXNCaEQ7QUFBQUEsSUFDMUIsTUFBTTRCLGdCQUFnQnFCLElBQUksQ0FBQ0MsYUFBYUEsU0FBU0MsWUFBWSxDQUFDLEVBQUVDLE9BQU9DLE9BQU87QUFBQSxJQUM5RSxDQUFDekIsZUFBZTtBQUFBLEVBQ2xCO0FBRUEsUUFBTTBCLGlCQUFpQkEsQ0FBQ0osYUFBcUI7QUFDM0NyQix1QkFBbUIsQ0FBQzBCLFlBQVk7QUFDOUIsVUFBSUEsUUFBUUMsU0FBU04sUUFBUSxHQUFHO0FBQzlCLGVBQU9LLFFBQVFILE9BQU8sQ0FBQ0ssU0FBU0EsU0FBU1AsUUFBUTtBQUFBLE1BQ25EO0FBQ0EsYUFBTyxDQUFDLEdBQUdLLFNBQVNMLFFBQVE7QUFBQSxJQUM5QixDQUFDO0FBQUEsRUFDSDtBQUVBLFFBQU1RLGtCQUFrQkEsQ0FBQ0MsT0FBZUMsT0FBNkNDLFVBQTRCO0FBQy9HeEI7QUFBQUEsTUFBZSxDQUFDa0IsWUFDZEEsUUFBUU4sSUFBSSxDQUFDYSxLQUFLQyxhQUFhO0FBQzdCLFlBQUlBLGFBQWFKLE1BQU8sUUFBT0c7QUFDL0IsZUFBTztBQUFBLFVBQ0wsR0FBR0E7QUFBQUEsVUFDSCxDQUFDRixLQUFLLEdBQUdDO0FBQUFBLFFBQ1g7QUFBQSxNQUNGLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUVBLFFBQU1HLGVBQWVBLE1BQU07QUFDekIzQixtQkFBZSxDQUFDa0IsWUFBWSxDQUFDLEdBQUdBLFNBQVM5QyxhQUFhLENBQUMsQ0FBQztBQUFBLEVBQzFEO0FBRUEsUUFBTXdELGtCQUFrQkEsQ0FBQ04sVUFBa0I7QUFDekN0QixtQkFBZSxDQUFDa0IsWUFBWUEsUUFBUUgsT0FBTyxDQUFDYyxHQUFHSCxhQUFhQSxhQUFhSixLQUFLLENBQUM7QUFBQSxFQUNqRjtBQUVBLFFBQU1RLHNCQUFzQkEsTUFBTTtBQUNoQyxVQUFNQyxXQUFXOUIsaUJBQWlCVyxJQUFJLENBQUNRLFVBQVU7QUFBQSxNQUMvQy9DLElBQUlDLE9BQU9DLFdBQVc7QUFBQSxNQUN0QkMsT0FBTzRDLEtBQUs1QztBQUFBQSxNQUNaQyxpQkFBaUIyQyxLQUFLM0M7QUFBQUEsTUFDdEJDLFdBQVcwQyxLQUFLWSxTQUFTO0FBQUEsTUFDekJyRCxjQUFjeUMsS0FBS1ksU0FBUztBQUFBLElBQzlCLEVBQUU7QUFFRmhDLG1CQUFlLENBQUNrQixZQUFZO0FBQzFCLFlBQU1lLFdBQVdmLFFBQVFILE9BQU8sQ0FBQ21CLE1BQU1BLEVBQUUxRCxNQUFNMkQsS0FBSyxLQUFLRCxFQUFFekQsZ0JBQWdCMEQsS0FBSyxDQUFDO0FBQ2pGLGFBQU8sQ0FBQyxHQUFHRixVQUFVLEdBQUdGLFFBQVE7QUFBQSxJQUNsQyxDQUFDO0FBRUQzQixpQkFBYSxRQUFRO0FBQ3JCdEMsVUFBTXNFLFFBQVEsNENBQTRDO0FBQUEsRUFDNUQ7QUFFQSxRQUFNQyx3QkFBd0IsWUFBWTtBQUN4QyxRQUFJLENBQUM1QyxpQkFBaUIwQyxLQUFLLEdBQUc7QUFDNUJyRSxZQUFNd0UsTUFBTSwyREFBMkQ7QUFDdkU7QUFBQSxJQUNGO0FBRUEsUUFBSTtBQUNGaEMsbUJBQWEsSUFBSTtBQUNqQixZQUFNaUMsWUFBWSxNQUFNdkUsZ0JBQWdCO0FBQUEsUUFDdEN3RSxtQkFBbUIvQztBQUFBQSxRQUNuQm9CLFVBQVVGLG9CQUFvQixDQUFDLEtBQUs7QUFBQSxRQUNwQ3hCO0FBQUFBLE1BQ0YsQ0FBQztBQUVELFlBQU1zRCxTQUFpRztBQUN2RyxZQUFNQyxlQUFlQSxDQUFDQyxRQUF3R1gsU0FBd0M7QUFDcEssbUJBQVdaLFFBQVF1QixRQUFRO0FBQ3pCRixpQkFBT0csS0FBSztBQUFBLFlBQ1ZwRSxPQUFPNEMsS0FBSzVDO0FBQUFBLFlBQ1pDLGlCQUFpQjJDLEtBQUszQztBQUFBQSxZQUN0QnVEO0FBQUFBLFVBQ0YsQ0FBQztBQUFBLFFBQ0g7QUFBQSxNQUNGO0FBQ0FVLG1CQUFhSCxVQUFVTSxpQkFBaUIsSUFBSSxTQUFTO0FBQ3JESCxtQkFBYUgsVUFBVU8sZ0JBQWdCLElBQUksUUFBUTtBQUNuREosbUJBQWFILFVBQVVRLGNBQWMsSUFBSSxNQUFNO0FBQy9DN0MsMEJBQW9CdUMsTUFBTTtBQUMxQnJDLG1CQUFhLElBQUk7QUFDakJ0QyxZQUFNc0UsUUFBUSx3Q0FBd0M7QUFBQSxJQUN4RCxTQUFTRSxPQUFPO0FBQ2R4RSxZQUFNd0UsTUFBTSw0QkFBNEI7QUFBQSxJQUMxQyxVQUFDO0FBQ0NoQyxtQkFBYSxLQUFLO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBRUEsUUFBTTBDLHlCQUF5QixZQUFZO0FBQ3pDLFFBQUksQ0FBQ2pFLE1BQU1vRCxLQUFLLEtBQUssQ0FBQzFDLGlCQUFpQjBDLEtBQUssR0FBRztBQUM3Q3JFLFlBQU13RSxNQUFNLHNEQUFzRDtBQUNsRTtBQUFBLElBQ0Y7QUFFQSxRQUFJO0FBQ0Y5QixvQkFBYyxJQUFJO0FBQ2xCLFlBQU15QyxVQUFVO0FBQUEsUUFDZGxFLE9BQU9BLE1BQU1vRCxLQUFLO0FBQUEsUUFDbEJsRCxhQUFhQSxZQUFZa0QsS0FBSztBQUFBLFFBQzlCaEQ7QUFBQUEsUUFDQStELGlCQUFpQkMsT0FBTzlELGFBQWEsS0FBSztBQUFBLFFBQzFDK0Qsa0JBQWtCekM7QUFBQUEsUUFDbEIwQyxXQUFXO0FBQUEsVUFDVDtBQUFBLFlBQ0ViLG1CQUFtQi9DLGlCQUFpQjBDLEtBQUs7QUFBQSxZQUN6Q3hDLGFBQWFBLFlBQVl3QyxLQUFLO0FBQUEsWUFDOUJ0QyxVQUFVQSxTQUFTc0MsS0FBSyxJQUFJLEVBQUVtQixXQUFXekQsU0FBU3NDLEtBQUssRUFBRSxJQUFLLENBQUM7QUFBQSxZQUMvRG9CLGNBQWM5QztBQUFBQSxZQUNkK0MsYUFBYXpELFlBQVkwRCxTQUFTMUQsY0FBYyxDQUFDM0IsYUFBYSxDQUFDLEdBQUcyQyxPQUFPLENBQUNVLFFBQVFBLElBQUlqRCxNQUFNMkQsS0FBSyxLQUFLVixJQUFJaEQsZ0JBQWdCMEQsS0FBSyxDQUFDLEVBQUV2QixJQUFJLENBQUNhLFNBQVM7QUFBQSxjQUM5SWpELE9BQU9pRCxJQUFJakQsTUFBTTJELEtBQUs7QUFBQSxjQUN0QjFELGlCQUFpQmdELElBQUloRCxnQkFBZ0IwRCxLQUFLO0FBQUEsY0FDMUN6RCxXQUFXK0MsSUFBSS9DO0FBQUFBLGNBQ2ZDLGNBQWM4QyxJQUFJOUM7QUFBQUEsWUFDcEIsRUFBRTtBQUFBLFVBQ0o7QUFBQSxRQUFDO0FBQUEsTUFFTDtBQUVBLFlBQU1aLGlCQUFpQmtGLE9BQU87QUFDOUJuRixZQUFNc0UsUUFBUSxrQ0FBa0M7QUFDaER0RCxlQUFTLHNCQUFzQjtBQUFBLElBQ2pDLFNBQVN3RCxPQUFPO0FBQ2R4RSxZQUFNd0UsTUFBTSw2QkFBNkI7QUFBQSxJQUMzQyxVQUFDO0FBQ0M5QixvQkFBYyxLQUFLO0FBQUEsSUFDckI7QUFBQSxFQUNGO0FBRUEsU0FDRSx1QkFBQyxhQUFRLFdBQVUsK0JBQ2pCO0FBQUEsMkJBQUMsU0FDQztBQUFBLDZCQUFDLFFBQUcsV0FBVSx5Q0FBd0Msa0NBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0U7QUFBQSxNQUN4RSx1QkFBQyxPQUFFLFdBQVUsK0JBQThCLG9GQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStHO0FBQUEsU0FGakg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsdUVBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLCtCQUFDLFFBQUcsV0FBVSx3Q0FBdUMsa0NBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUU7QUFBQSxRQUN2RSx1QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsdUJBQ2Y7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsaURBQWdELHFCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxRTtBQUFBLFlBQ3JFLHVCQUFDLFdBQU0sT0FBT3pCLE9BQU8sVUFBVSxDQUFDMkUsVUFBVTFFLFNBQVMwRSxNQUFNQyxPQUFPbkMsS0FBSyxHQUFHLFdBQVUscUpBQW9KLFVBQVEsUUFBOU87QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOE87QUFBQSxlQUZoUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFFQSx1QkFBQyxXQUFNLFdBQVUsdUJBQ2Y7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsaURBQWdELDJCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyRTtBQUFBLFlBQzNFLHVCQUFDLGNBQVMsT0FBT3ZDLGFBQWEsVUFBVSxDQUFDeUUsVUFBVXhFLGVBQWV3RSxNQUFNQyxPQUFPbkMsS0FBSyxHQUFHLFdBQVUsZ0tBQWpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZQO0FBQUEsZUFGL1A7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBRUEsdUJBQUMsV0FBTSxXQUFVLFNBQ2Y7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsaURBQWdELDBCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwRTtBQUFBLFlBQzFFLHVCQUFDLFlBQU8sT0FBT3JDLFlBQVksVUFBVSxDQUFDdUUsVUFBVXRFLGNBQWNzRSxNQUFNQyxPQUFPbkMsS0FBSyxHQUFHLFdBQVUscUpBQzNGO0FBQUEscUNBQUMsWUFBTyxPQUFNLFFBQU8sb0JBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlCO0FBQUEsY0FDekIsdUJBQUMsWUFBTyxPQUFNLFVBQVMsc0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTZCO0FBQUEsY0FDN0IsdUJBQUMsWUFBTyxPQUFNLFFBQU8sb0JBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlCO0FBQUEsaUJBSDNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSUE7QUFBQSxlQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxVQUVBLHVCQUFDLFdBQU0sV0FBVSxTQUNmO0FBQUEsbUNBQUMsVUFBSyxXQUFVLGlEQUFnRCxvQ0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0Y7QUFBQSxZQUNwRix1QkFBQyxXQUFNLE1BQUssVUFBUyxLQUFLLEdBQUcsT0FBT25DLGVBQWUsVUFBVSxDQUFDcUUsVUFBVXBFLGlCQUFpQjZELE9BQU9PLE1BQU1DLE9BQU9uQyxLQUFLLEtBQUssRUFBRSxHQUFHLFdBQVUsdUpBQXRJO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlSO0FBQUEsZUFGM1I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLGFBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3QkE7QUFBQSxRQUVBLHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsaURBQWdELG1DQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRjtBQUFBLFVBQ25GLHVCQUFDLFNBQUksV0FBVSx3QkFDWnJELDZCQUFtQnlDO0FBQUFBLFlBQUksQ0FBQ0MsYUFDdkIsdUJBQUMsV0FBcUIsV0FBVSwyR0FDOUI7QUFBQSxxQ0FBQyxXQUFNLE1BQUssWUFBVyxTQUFTdEIsZ0JBQWdCNEIsU0FBU04sUUFBUSxHQUFHLFVBQVUsTUFBTUksZUFBZUosUUFBUSxHQUFHLFdBQVUsYUFBeEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUk7QUFBQSxjQUNoSUE7QUFBQUEsaUJBRlNBLFVBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFVBQ0QsS0FOSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsYUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxRQUVDdEIsZ0JBQWdCa0UsU0FBUyxLQUN4Qix1QkFBQyxTQUFJLFdBQVUsNENBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsaURBQWdELHVDQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1RjtBQUFBLFVBQ3ZGLHVCQUFDLE9BQUUsV0FBVSwwQkFBeUIsK0hBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFKO0FBQUEsVUFDckosdUJBQUMsU0FBSSxXQUFVLDZCQUNabEUsMEJBQWdCcUIsSUFBSSxDQUFDZ0QsU0FBUztBQUM3QixrQkFBTUMsVUFBVUQsS0FBSzlDLFlBQVk7QUFDakMsbUJBQ0UsdUJBQUMsV0FBaUIsV0FBVSw0REFDMUI7QUFBQSxxQ0FBQyxVQUFLLFdBQVUsNEVBQTRFOEM7QUFBQUE7QUFBQUEsZ0JBQUs7QUFBQSxtQkFBakc7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBOEc7QUFBQSxjQUM5RztBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxPQUFPbkQsWUFBWW9ELE9BQU8sS0FBSztBQUFBLGtCQUMvQixVQUFVLENBQUNDLE1BQU07QUFDZiwwQkFBTUMsTUFBTUQsRUFBRUgsT0FBT25DO0FBQ3JCZCxtQ0FBZSxDQUFDc0QsVUFBVSxFQUFFLEdBQUdBLE1BQU0sQ0FBQ0gsT0FBTyxHQUFHRSxJQUFJLEVBQUU7QUFBQSxrQkFDeEQ7QUFBQSxrQkFDQSxXQUFVO0FBQUEsa0JBQ1YsYUFBYSx1QkFBdUJILElBQUk7QUFBQTtBQUFBLGdCQVAxQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FPZ0Q7QUFBQSxpQkFUdENBLE1BQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFXQTtBQUFBLFVBRUosQ0FBQyxLQWpCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWtCQTtBQUFBLGFBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFzQkE7QUFBQSxXQS9ESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBaUVBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsNENBQ2I7QUFBQSwrQkFBQyxRQUFHLFdBQVUsd0NBQXVDLGlDQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNFO0FBQUEsUUFDdEUsdUJBQUMsV0FBTSxXQUFVLFNBQ2Y7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsaURBQWdELGlDQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpRjtBQUFBLFVBQ2pGLHVCQUFDLGNBQVMsT0FBT25FLGtCQUFrQixVQUFVLENBQUNpRSxVQUFVaEUsb0JBQW9CZ0UsTUFBTUMsT0FBT25DLEtBQUssR0FBRyxXQUFVLDhKQUE2SixVQUFRLFFBQWhSO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdSO0FBQUEsYUFGbFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxXQUFNLFdBQVUsU0FDZjtBQUFBLGlDQUFDLFVBQUssV0FBVSxpREFBZ0QsMkJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJFO0FBQUEsVUFDM0UsdUJBQUMsY0FBUyxPQUFPN0IsYUFBYSxVQUFVLENBQUMrRCxVQUFVOUQsZUFBZThELE1BQU1DLE9BQU9uQyxLQUFLLEdBQUcsV0FBVSxnS0FBakc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNlA7QUFBQSxhQUYvUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLFdBQU0sV0FBVSxTQUNmO0FBQUEsaUNBQUMsVUFBSyxXQUFVLGlEQUFnRCx3QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0U7QUFBQSxVQUN4RSx1QkFBQyxjQUFTLE9BQU8zQixVQUFVLFVBQVUsQ0FBQzZELFVBQVU1RCxZQUFZNEQsTUFBTUMsT0FBT25DLEtBQUssR0FBRyxXQUFVLDhKQUE2SixhQUFZLDRCQUFwUTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0UjtBQUFBLGFBRjlSO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWNBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsNENBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsd0NBQXVDLDBCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErRDtBQUFBLFVBQy9ELHVCQUFDLFNBQUksV0FBVSwyREFDYjtBQUFBLG1DQUFDLFlBQU8sTUFBSyxVQUFTLFNBQVMsTUFBTXBCLGFBQWEsUUFBUSxHQUFHLFdBQVcsOENBQThDRCxjQUFjLFdBQVcsc0NBQXNDLGdCQUFnQixJQUFHLDRCQUF4TTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxZQUFPLE1BQUssVUFBUyxTQUFTLE1BQU1DLGFBQWEsSUFBSSxHQUFHLFdBQVcsOENBQThDRCxjQUFjLE9BQU8sc0NBQXNDLGdCQUFnQixJQUFHLGdDQUFoTTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsYUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxRQUVDQSxjQUFjLFdBQ2IsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsc0RBQ2IsaUNBQUMsV0FBTSxXQUFVLGdDQUNmO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGVBQ2YsaUNBQUMsUUFDQztBQUFBLHFDQUFDLFFBQUcsV0FBVSwwQ0FBeUMscUJBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTREO0FBQUEsY0FDNUQsdUJBQUMsUUFBRyxXQUFVLDBDQUF5QywrQkFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBc0U7QUFBQSxjQUN0RSx1QkFBQyxRQUFHLFdBQVUsMENBQXlDLHVCQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE4RDtBQUFBLGNBQzlELHVCQUFDLFFBQUcsV0FBVSwwQ0FBeUMsMEJBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlFO0FBQUEsY0FDakUsdUJBQUMsUUFBRyxXQUFVLDBDQUF5QyxzQkFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkQ7QUFBQSxpQkFML0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFNQSxLQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxZQUNBLHVCQUFDLFdBQ0VKLHNCQUFZYTtBQUFBQSxjQUFJLENBQUNhLEtBQUtILFVBQ3JCLHVCQUFDLFFBQWdCLFdBQVUsNkJBQ3pCO0FBQUEsdUNBQUMsUUFBRyxXQUFVLGFBQVksaUNBQUMsV0FBTSxPQUFPRyxJQUFJakQsT0FBTyxVQUFVLENBQUNrRixVQUFVckMsZ0JBQWdCQyxPQUFPLFNBQVNvQyxNQUFNQyxPQUFPbkMsS0FBSyxHQUFHLFdBQVUseUpBQTdHO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWtRLEtBQTVSO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQStSO0FBQUEsZ0JBQy9SLHVCQUFDLFFBQUcsV0FBVSxhQUFZLGlDQUFDLFdBQU0sT0FBT0MsSUFBSWhELGlCQUFpQixVQUFVLENBQUNpRixVQUFVckMsZ0JBQWdCQyxPQUFPLG1CQUFtQm9DLE1BQU1DLE9BQU9uQyxLQUFLLEdBQUcsV0FBVSx5SkFBakk7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc1IsS0FBaFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBbVQ7QUFBQSxnQkFDblQsdUJBQUMsUUFBRyxXQUFVLGFBQVksaUNBQUMsV0FBTSxNQUFLLFlBQVcsU0FBU0MsSUFBSS9DLFdBQVcsVUFBVSxDQUFDZ0YsVUFBVXJDLGdCQUFnQkMsT0FBTyxhQUFhb0MsTUFBTUMsT0FBT00sT0FBTyxHQUFHLFdBQVUsYUFBekk7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBa0osS0FBNUs7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBK0s7QUFBQSxnQkFDL0ssdUJBQUMsUUFBRyxXQUFVLGFBQVksaUNBQUMsV0FBTSxNQUFLLFlBQVcsU0FBU3hDLElBQUk5QyxjQUFjLFVBQVUsQ0FBQytFLFVBQVVyQyxnQkFBZ0JDLE9BQU8sZ0JBQWdCb0MsTUFBTUMsT0FBT00sT0FBTyxHQUFHLFdBQVUsYUFBL0k7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBd0osS0FBbEw7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBcUw7QUFBQSxnQkFDckwsdUJBQUMsUUFBRyxXQUFVLGFBQVksaUNBQUMsWUFBTyxNQUFLLFVBQVMsU0FBUyxNQUFNckMsZ0JBQWdCTixLQUFLLEdBQUcsV0FBVSx1REFBc0Qsc0JBQTdIO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW1JLEtBQTdKO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXNLO0FBQUEsbUJBTC9KRyxJQUFJcEQsSUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU1BO0FBQUEsWUFDRCxLQVRIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBVUE7QUFBQSxlQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXFCQSxLQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXVCQTtBQUFBLFVBQ0EsdUJBQUMsVUFBTyxNQUFLLFVBQVMsU0FBUSxhQUFZLFNBQVNzRCxjQUFjLHVCQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3RTtBQUFBLGFBekIxRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMEJBLElBRUEsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxpQ0FBQyxVQUFPLE1BQUssVUFBUyxXQUFVLFlBQVcsVUFBVXRCLFdBQVcsU0FBU2dDLHVCQUN0RWhDLHNCQUFZLHVCQUFDLFdBQVEsT0FBTSxnQkFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyQixJQUFNLHlCQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFFQ0osaUJBQWlCd0QsU0FBUyxLQUN6Qix1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSxzREFDYixpQ0FBQyxXQUFNLFdBQVUsZ0NBQ2Y7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZUFDZixpQ0FBQyxRQUNDO0FBQUEsdUNBQUMsUUFBRyxXQUFVLDBDQUF5QyxxQkFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNEQ7QUFBQSxnQkFDNUQsdUJBQUMsUUFBRyxXQUFVLDBDQUF5QywrQkFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0U7QUFBQSxnQkFDdEUsdUJBQUMsUUFBRyxXQUFVLDBDQUF5QyxvQkFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkQ7QUFBQSxtQkFIN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFJQSxLQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBTUE7QUFBQSxjQUNBLHVCQUFDLFdBQ0V4RCwyQkFBaUJXO0FBQUFBLGdCQUFJLENBQUNhLEtBQUtILFVBQzFCLHVCQUFDLFFBQWdDLFdBQVUsNkJBQ3pDO0FBQUEseUNBQUMsUUFBRyxXQUFVLGFBQWFHLGNBQUlqRCxTQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFxQztBQUFBLGtCQUNyQyx1QkFBQyxRQUFHLFdBQVUsYUFBYWlELGNBQUloRCxtQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBK0M7QUFBQSxrQkFDL0MsdUJBQUMsUUFBRyxXQUFVLHdCQUF3QmdELGNBQUlPLFFBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQStDO0FBQUEscUJBSHhDLEdBQUdQLElBQUlPLElBQUksSUFBSVYsS0FBSyxJQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUlBO0FBQUEsY0FDRCxLQVBIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBUUE7QUFBQSxpQkFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFpQkEsS0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFtQkE7QUFBQSxZQUNBLHVCQUFDLFVBQU8sTUFBSyxVQUFTLFNBQVNRLHFCQUFvQixxQ0FBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBd0JBO0FBQUEsYUE5Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWdDQTtBQUFBLFdBMUVKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE0RUE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxtREFDYixpQ0FBQyxVQUFPLE1BQUssVUFBUyxVQUFVdkIsWUFBWSxTQUFTeUMsd0JBQ2xEekMsdUJBQWEsdUJBQUMsV0FBUSxPQUFNLGNBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5QixJQUFNLHVCQUQvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxTQXRLRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdUtBO0FBQUEsT0E3S0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQThLQTtBQUVKO0FBQUMxQixHQW5VdUJELG1CQUFpQjtBQUFBLFVBQ3RCZixXQUFXO0FBQUE7QUFBQSxLQUROZTtBQUFpQixJQUFBc0Y7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlTWVtbyIsInVzZVN0YXRlIiwidXNlTmF2aWdhdGUiLCJ0b2FzdCIsImNyZWF0ZUFzc2Vzc21lbnQiLCJnZW5lcmF0ZUFJVGVzdHMiLCJCdXR0b24iLCJTcGlubmVyIiwic3VwcG9ydGVkTGFuZ3VhZ2VzIiwiZW1wdHlUZXN0Um93IiwiaWQiLCJjcnlwdG8iLCJyYW5kb21VVUlEIiwiaW5wdXQiLCJleHBlY3RlZF9vdXRwdXQiLCJpc19oaWRkZW4iLCJpc19lZGdlX2Nhc2UiLCJBc3Nlc3NtZW50QnVpbGRlciIsIl9zIiwibmF2aWdhdGUiLCJ0aXRsZSIsInNldFRpdGxlIiwiZGVzY3JpcHRpb24iLCJzZXREZXNjcmlwdGlvbiIsImRpZmZpY3VsdHkiLCJzZXREaWZmaWN1bHR5IiwidGltZUxpbWl0TWlucyIsInNldFRpbWVMaW1pdE1pbnMiLCJsYW5ndWFnZVN1cHBvcnQiLCJzZXRMYW5ndWFnZVN1cHBvcnQiLCJwcm9ibGVtU3RhdGVtZW50Iiwic2V0UHJvYmxlbVN0YXRlbWVudCIsImNvbnN0cmFpbnRzIiwic2V0Q29uc3RyYWludHMiLCJleGFtcGxlcyIsInNldEV4YW1wbGVzIiwibWFudWFsVGVzdHMiLCJzZXRNYW51YWxUZXN0cyIsImFpR2VuZXJhdGVkVGVzdHMiLCJzZXRBaUdlbmVyYXRlZFRlc3RzIiwiYWN0aXZlVGFiIiwic2V0QWN0aXZlVGFiIiwiYWlMb2FkaW5nIiwic2V0QWlMb2FkaW5nIiwic3VibWl0dGluZyIsInNldFN1Ym1pdHRpbmciLCJzdGFydGVyQ29kZSIsInNldFN0YXJ0ZXJDb2RlIiwibm9ybWFsaXplZExhbmd1YWdlcyIsIm1hcCIsImxhbmd1YWdlIiwidG9Mb3dlckNhc2UiLCJmaWx0ZXIiLCJCb29sZWFuIiwidG9nZ2xlTGFuZ3VhZ2UiLCJjdXJyZW50IiwiaW5jbHVkZXMiLCJpdGVtIiwidXBkYXRlTWFudWFsUm93IiwiaW5kZXgiLCJmaWVsZCIsInZhbHVlIiwicm93Iiwicm93SW5kZXgiLCJhZGRNYW51YWxSb3ciLCJyZW1vdmVNYW51YWxSb3ciLCJfIiwiaGFuZGxlSW1wb3J0QUlUZXN0cyIsImltcG9ydGVkIiwidHlwZSIsImZpbHRlcmVkIiwiciIsInRyaW0iLCJzdWNjZXNzIiwiaGFuZGxlR2VuZXJhdGVBSVRlc3RzIiwiZXJyb3IiLCJnZW5lcmF0ZWQiLCJwcm9ibGVtX3N0YXRlbWVudCIsIm1lcmdlZCIsImFkZEdlbmVyYXRlZCIsInNvdXJjZSIsInB1c2giLCJ2aXNpYmxlX3Rlc3RzIiwiaGlkZGVuX3Rlc3RzIiwiZWRnZV9jYXNlcyIsImhhbmRsZUNyZWF0ZUFzc2Vzc21lbnQiLCJwYXlsb2FkIiwidGltZV9saW1pdF9taW5zIiwiTnVtYmVyIiwibGFuZ3VhZ2Vfc3VwcG9ydCIsInF1ZXN0aW9ucyIsImV4YW1wbGVfMSIsInN0YXJ0ZXJfY29kZSIsInRlc3RfY2FzZXMiLCJsZW5ndGgiLCJldmVudCIsInRhcmdldCIsImxhbmciLCJsYW5nS2V5IiwiZSIsInZhbCIsInByZXYiLCJjaGVja2VkIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQXNzZXNzbWVudEJ1aWxkZXIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZU1lbW8sIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XG5pbXBvcnQgdG9hc3QgZnJvbSBcInJlYWN0LWhvdC10b2FzdFwiO1xuaW1wb3J0IHsgY3JlYXRlQXNzZXNzbWVudCwgZ2VuZXJhdGVBSVRlc3RzLCBzYXZlQUlUZXN0cywgdHlwZSBBc3Nlc3NtZW50VGVzdENhc2UgfSBmcm9tIFwiLi4vYXBpL2Fzc2Vzc21lbnRzXCI7XG5pbXBvcnQgQnV0dG9uIGZyb20gXCIuLi9jb21wb25lbnRzL3VpL0J1dHRvblwiO1xuaW1wb3J0IFNwaW5uZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvdWkvU3Bpbm5lclwiO1xuXG5jb25zdCBzdXBwb3J0ZWRMYW5ndWFnZXMgPSBbXCJQeXRob25cIiwgXCJDXCIsIFwiQysrXCIsIFwiSmF2YVwiLCBcIkphdmFTY3JpcHRcIl0gYXMgY29uc3Q7XG5cbmNvbnN0IGVtcHR5VGVzdFJvdyA9ICgpOiBBc3Nlc3NtZW50VGVzdENhc2UgJiB7IGlkOiBzdHJpbmcgfSA9PiAoe1xuICBpZDogY3J5cHRvLnJhbmRvbVVVSUQoKSxcbiAgaW5wdXQ6IFwiXCIsXG4gIGV4cGVjdGVkX291dHB1dDogXCJcIixcbiAgaXNfaGlkZGVuOiBmYWxzZSxcbiAgaXNfZWRnZV9jYXNlOiBmYWxzZVxufSk7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEFzc2Vzc21lbnRCdWlsZGVyKCkge1xuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gIGNvbnN0IFt0aXRsZSwgc2V0VGl0bGVdID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFtkZXNjcmlwdGlvbiwgc2V0RGVzY3JpcHRpb25dID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFtkaWZmaWN1bHR5LCBzZXREaWZmaWN1bHR5XSA9IHVzZVN0YXRlKFwiZWFzeVwiKTtcbiAgY29uc3QgW3RpbWVMaW1pdE1pbnMsIHNldFRpbWVMaW1pdE1pbnNdID0gdXNlU3RhdGUoMzApO1xuICBjb25zdCBbbGFuZ3VhZ2VTdXBwb3J0LCBzZXRMYW5ndWFnZVN1cHBvcnRdID0gdXNlU3RhdGU8c3RyaW5nW10+KFtcIlB5dGhvblwiXSk7XG4gIGNvbnN0IFtwcm9ibGVtU3RhdGVtZW50LCBzZXRQcm9ibGVtU3RhdGVtZW50XSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbY29uc3RyYWludHMsIHNldENvbnN0cmFpbnRzXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbZXhhbXBsZXMsIHNldEV4YW1wbGVzXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbbWFudWFsVGVzdHMsIHNldE1hbnVhbFRlc3RzXSA9IHVzZVN0YXRlPEFycmF5PEFzc2Vzc21lbnRUZXN0Q2FzZSAmIHsgaWQ6IHN0cmluZyB9Pj4oW2VtcHR5VGVzdFJvdygpXSk7XG4gIGNvbnN0IFthaUdlbmVyYXRlZFRlc3RzLCBzZXRBaUdlbmVyYXRlZFRlc3RzXSA9IHVzZVN0YXRlPEFycmF5PHsgaW5wdXQ6IHN0cmluZzsgZXhwZWN0ZWRfb3V0cHV0OiBzdHJpbmc7IHR5cGU6IFwidmlzaWJsZVwiIHwgXCJoaWRkZW5cIiB8IFwiZWRnZVwiIH0+PihbXSk7XG4gIGNvbnN0IFthY3RpdmVUYWIsIHNldEFjdGl2ZVRhYl0gPSB1c2VTdGF0ZTxcIm1hbnVhbFwiIHwgXCJhaVwiPihcIm1hbnVhbFwiKTtcbiAgY29uc3QgW2FpTG9hZGluZywgc2V0QWlMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3N1Ym1pdHRpbmcsIHNldFN1Ym1pdHRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbc3RhcnRlckNvZGUsIHNldFN0YXJ0ZXJDb2RlXSA9IHVzZVN0YXRlPFJlY29yZDxzdHJpbmcsIHN0cmluZz4+KHt9KTtcblxuICBjb25zdCBub3JtYWxpemVkTGFuZ3VhZ2VzID0gdXNlTWVtbyhcbiAgICAoKSA9PiBsYW5ndWFnZVN1cHBvcnQubWFwKChsYW5ndWFnZSkgPT4gbGFuZ3VhZ2UudG9Mb3dlckNhc2UoKSkuZmlsdGVyKEJvb2xlYW4pLFxuICAgIFtsYW5ndWFnZVN1cHBvcnRdXG4gICk7XG5cbiAgY29uc3QgdG9nZ2xlTGFuZ3VhZ2UgPSAobGFuZ3VhZ2U6IHN0cmluZykgPT4ge1xuICAgIHNldExhbmd1YWdlU3VwcG9ydCgoY3VycmVudCkgPT4ge1xuICAgICAgaWYgKGN1cnJlbnQuaW5jbHVkZXMobGFuZ3VhZ2UpKSB7XG4gICAgICAgIHJldHVybiBjdXJyZW50LmZpbHRlcigoaXRlbSkgPT4gaXRlbSAhPT0gbGFuZ3VhZ2UpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIFsuLi5jdXJyZW50LCBsYW5ndWFnZV07XG4gICAgfSk7XG4gIH07XG5cbiAgY29uc3QgdXBkYXRlTWFudWFsUm93ID0gKGluZGV4OiBudW1iZXIsIGZpZWxkOiBrZXlvZiBPbWl0PEFzc2Vzc21lbnRUZXN0Q2FzZSwgXCJpZFwiPiwgdmFsdWU6IHN0cmluZyB8IGJvb2xlYW4pID0+IHtcbiAgICBzZXRNYW51YWxUZXN0cygoY3VycmVudCkgPT5cbiAgICAgIGN1cnJlbnQubWFwKChyb3csIHJvd0luZGV4KSA9PiB7XG4gICAgICAgIGlmIChyb3dJbmRleCAhPT0gaW5kZXgpIHJldHVybiByb3c7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgLi4ucm93LFxuICAgICAgICAgIFtmaWVsZF06IHZhbHVlXG4gICAgICAgIH07XG4gICAgICB9KVxuICAgICk7XG4gIH07XG5cbiAgY29uc3QgYWRkTWFudWFsUm93ID0gKCkgPT4ge1xuICAgIHNldE1hbnVhbFRlc3RzKChjdXJyZW50KSA9PiBbLi4uY3VycmVudCwgZW1wdHlUZXN0Um93KCldKTtcbiAgfTtcblxuICBjb25zdCByZW1vdmVNYW51YWxSb3cgPSAoaW5kZXg6IG51bWJlcikgPT4ge1xuICAgIHNldE1hbnVhbFRlc3RzKChjdXJyZW50KSA9PiBjdXJyZW50LmZpbHRlcigoXywgcm93SW5kZXgpID0+IHJvd0luZGV4ICE9PSBpbmRleCkpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUltcG9ydEFJVGVzdHMgPSAoKSA9PiB7XG4gICAgY29uc3QgaW1wb3J0ZWQgPSBhaUdlbmVyYXRlZFRlc3RzLm1hcCgoaXRlbSkgPT4gKHtcbiAgICAgIGlkOiBjcnlwdG8ucmFuZG9tVVVJRCgpLFxuICAgICAgaW5wdXQ6IGl0ZW0uaW5wdXQsXG4gICAgICBleHBlY3RlZF9vdXRwdXQ6IGl0ZW0uZXhwZWN0ZWRfb3V0cHV0LFxuICAgICAgaXNfaGlkZGVuOiBpdGVtLnR5cGUgPT09IFwiaGlkZGVuXCIsXG4gICAgICBpc19lZGdlX2Nhc2U6IGl0ZW0udHlwZSA9PT0gXCJlZGdlXCJcbiAgICB9KSk7XG5cbiAgICBzZXRNYW51YWxUZXN0cygoY3VycmVudCkgPT4ge1xuICAgICAgY29uc3QgZmlsdGVyZWQgPSBjdXJyZW50LmZpbHRlcigocikgPT4gci5pbnB1dC50cmltKCkgfHwgci5leHBlY3RlZF9vdXRwdXQudHJpbSgpKTtcbiAgICAgIHJldHVybiBbLi4uZmlsdGVyZWQsIC4uLmltcG9ydGVkXTtcbiAgICB9KTtcblxuICAgIHNldEFjdGl2ZVRhYihcIm1hbnVhbFwiKTtcbiAgICB0b2FzdC5zdWNjZXNzKFwiQUkgdGVzdCBjYXNlcyBpbXBvcnRlZCB0byB0aGUgbWFudWFsIGxpc3QuXCIpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUdlbmVyYXRlQUlUZXN0cyA9IGFzeW5jICgpID0+IHtcbiAgICBpZiAoIXByb2JsZW1TdGF0ZW1lbnQudHJpbSgpKSB7XG4gICAgICB0b2FzdC5lcnJvcihcIlByb2JsZW0gc3RhdGVtZW50IGlzIHJlcXVpcmVkIGJlZm9yZSBnZW5lcmF0aW5nIEFJIHRlc3RzLlwiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICB0cnkge1xuICAgICAgc2V0QWlMb2FkaW5nKHRydWUpO1xuICAgICAgY29uc3QgZ2VuZXJhdGVkID0gYXdhaXQgZ2VuZXJhdGVBSVRlc3RzKHtcbiAgICAgICAgcHJvYmxlbV9zdGF0ZW1lbnQ6IHByb2JsZW1TdGF0ZW1lbnQsXG4gICAgICAgIGxhbmd1YWdlOiBub3JtYWxpemVkTGFuZ3VhZ2VzWzBdID8/IFwicHl0aG9uXCIsXG4gICAgICAgIGRpZmZpY3VsdHlcbiAgICAgIH0pO1xuXG4gICAgICBjb25zdCBtZXJnZWQ6IEFycmF5PHsgaW5wdXQ6IHN0cmluZzsgZXhwZWN0ZWRfb3V0cHV0OiBzdHJpbmc7IHR5cGU6IFwidmlzaWJsZVwiIHwgXCJoaWRkZW5cIiB8IFwiZWRnZVwiIH0+ID0gW107XG4gICAgICBjb25zdCBhZGRHZW5lcmF0ZWQgPSAoc291cmNlOiBBcnJheTx7IGlucHV0OiBzdHJpbmc7IGV4cGVjdGVkX291dHB1dDogc3RyaW5nOyBpc19oaWRkZW4/OiBib29sZWFuOyBpc19lZGdlX2Nhc2U/OiBib29sZWFuIH0+LCB0eXBlOiBcInZpc2libGVcIiB8IFwiaGlkZGVuXCIgfCBcImVkZ2VcIikgPT4ge1xuICAgICAgICBmb3IgKGNvbnN0IGl0ZW0gb2Ygc291cmNlKSB7XG4gICAgICAgICAgbWVyZ2VkLnB1c2goe1xuICAgICAgICAgICAgaW5wdXQ6IGl0ZW0uaW5wdXQsXG4gICAgICAgICAgICBleHBlY3RlZF9vdXRwdXQ6IGl0ZW0uZXhwZWN0ZWRfb3V0cHV0LFxuICAgICAgICAgICAgdHlwZVxuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICB9O1xuICAgICAgYWRkR2VuZXJhdGVkKGdlbmVyYXRlZC52aXNpYmxlX3Rlc3RzID8/IFtdLCBcInZpc2libGVcIik7XG4gICAgICBhZGRHZW5lcmF0ZWQoZ2VuZXJhdGVkLmhpZGRlbl90ZXN0cyA/PyBbXSwgXCJoaWRkZW5cIik7XG4gICAgICBhZGRHZW5lcmF0ZWQoZ2VuZXJhdGVkLmVkZ2VfY2FzZXMgPz8gW10sIFwiZWRnZVwiKTtcbiAgICAgIHNldEFpR2VuZXJhdGVkVGVzdHMobWVyZ2VkKTtcbiAgICAgIHNldEFjdGl2ZVRhYihcImFpXCIpO1xuICAgICAgdG9hc3Quc3VjY2VzcyhcIkFJLWdlbmVyYXRlZCB0ZXN0IGNhc2VzIHdlcmUgcHJvZHVjZWQuXCIpO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICB0b2FzdC5lcnJvcihcIkFJIHRlc3QgZ2VuZXJhdGlvbiBmYWlsZWQuXCIpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRBaUxvYWRpbmcoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBoYW5kbGVDcmVhdGVBc3Nlc3NtZW50ID0gYXN5bmMgKCkgPT4ge1xuICAgIGlmICghdGl0bGUudHJpbSgpIHx8ICFwcm9ibGVtU3RhdGVtZW50LnRyaW0oKSkge1xuICAgICAgdG9hc3QuZXJyb3IoXCJBc3Nlc3NtZW50IHRpdGxlIGFuZCBwcm9ibGVtIHN0YXRlbWVudCBhcmUgcmVxdWlyZWQuXCIpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIHRyeSB7XG4gICAgICBzZXRTdWJtaXR0aW5nKHRydWUpO1xuICAgICAgY29uc3QgcGF5bG9hZCA9IHtcbiAgICAgICAgdGl0bGU6IHRpdGxlLnRyaW0oKSxcbiAgICAgICAgZGVzY3JpcHRpb246IGRlc2NyaXB0aW9uLnRyaW0oKSxcbiAgICAgICAgZGlmZmljdWx0eSxcbiAgICAgICAgdGltZV9saW1pdF9taW5zOiBOdW1iZXIodGltZUxpbWl0TWlucykgfHwgMzAsXG4gICAgICAgIGxhbmd1YWdlX3N1cHBvcnQ6IG5vcm1hbGl6ZWRMYW5ndWFnZXMsXG4gICAgICAgIHF1ZXN0aW9uczogW1xuICAgICAgICAgIHtcbiAgICAgICAgICAgIHByb2JsZW1fc3RhdGVtZW50OiBwcm9ibGVtU3RhdGVtZW50LnRyaW0oKSxcbiAgICAgICAgICAgIGNvbnN0cmFpbnRzOiBjb25zdHJhaW50cy50cmltKCksXG4gICAgICAgICAgICBleGFtcGxlczogZXhhbXBsZXMudHJpbSgpID8geyBleGFtcGxlXzE6IGV4YW1wbGVzLnRyaW0oKSB9IDogKHt9IGFzIFJlY29yZDxzdHJpbmcsIHN0cmluZz4pLFxuICAgICAgICAgICAgc3RhcnRlcl9jb2RlOiBzdGFydGVyQ29kZSxcbiAgICAgICAgICAgIHRlc3RfY2FzZXM6IChtYW51YWxUZXN0cy5sZW5ndGggPyBtYW51YWxUZXN0cyA6IFtlbXB0eVRlc3RSb3coKV0pLmZpbHRlcigocm93KSA9PiByb3cuaW5wdXQudHJpbSgpIHx8IHJvdy5leHBlY3RlZF9vdXRwdXQudHJpbSgpKS5tYXAoKHJvdykgPT4gKHtcbiAgICAgICAgICAgICAgaW5wdXQ6IHJvdy5pbnB1dC50cmltKCksXG4gICAgICAgICAgICAgIGV4cGVjdGVkX291dHB1dDogcm93LmV4cGVjdGVkX291dHB1dC50cmltKCksXG4gICAgICAgICAgICAgIGlzX2hpZGRlbjogcm93LmlzX2hpZGRlbixcbiAgICAgICAgICAgICAgaXNfZWRnZV9jYXNlOiByb3cuaXNfZWRnZV9jYXNlXG4gICAgICAgICAgICB9KSlcbiAgICAgICAgICB9XG4gICAgICAgIF1cbiAgICAgIH07XG5cbiAgICAgIGF3YWl0IGNyZWF0ZUFzc2Vzc21lbnQocGF5bG9hZCk7XG4gICAgICB0b2FzdC5zdWNjZXNzKFwiQXNzZXNzbWVudCBjcmVhdGVkIHN1Y2Nlc3NmdWxseS5cIik7XG4gICAgICBuYXZpZ2F0ZShcIi9yZWNydWl0ZXIvZGFzaGJvYXJkXCIpO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICB0b2FzdC5lcnJvcihcIkFzc2Vzc21lbnQgY3JlYXRpb24gZmFpbGVkLlwiKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0U3VibWl0dGluZyhmYWxzZSk7XG4gICAgfVxuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwibXgtYXV0byBtYXgtdy01eGwgc3BhY2UteS02XCI+XG4gICAgICA8ZGl2PlxuICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTk1MFwiPkFzc2Vzc21lbnQgQnVpbGRlcjwvaDI+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LXNsYXRlLTYwMFwiPkNyZWF0ZSBjb2RpbmcgY2hhbGxlbmdlcyB3aXRoIHRlc3QgY2FzZXMgYW5kIEFJLWFzc2lzdGVkIGdlbmVyYXRpb24uPC9wPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgYmctd2hpdGUgcC02IHNoYWRvdy1zbVwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS05MDBcIj5Bc3Nlc3NtZW50IERldGFpbHM8L2gzPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBnYXAtNCBtZDpncmlkLWNvbHMtMlwiPlxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cIm1kOmNvbC1zcGFuLTIgYmxvY2tcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWItMSBibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNzAwXCI+VGl0bGU8L3NwYW4+XG4gICAgICAgICAgICAgIDxpbnB1dCB2YWx1ZT17dGl0bGV9IG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldFRpdGxlKGV2ZW50LnRhcmdldC52YWx1ZSl9IGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItc2xhdGUtMzAwIGJnLXdoaXRlIHB4LTMgcHktMiB0ZXh0LXNsYXRlLTkwMCBvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLWJyYW5kLTUwMCBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1icmFuZC0xMDBcIiByZXF1aXJlZCAvPlxuICAgICAgICAgICAgPC9sYWJlbD5cblxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cIm1kOmNvbC1zcGFuLTIgYmxvY2tcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWItMSBibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNzAwXCI+RGVzY3JpcHRpb248L3NwYW4+XG4gICAgICAgICAgICAgIDx0ZXh0YXJlYSB2YWx1ZT17ZGVzY3JpcHRpb259IG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldERlc2NyaXB0aW9uKGV2ZW50LnRhcmdldC52YWx1ZSl9IGNsYXNzTmFtZT1cIm1pbi1oLTI4IHctZnVsbCByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItc2xhdGUtMzAwIGJnLXdoaXRlIHB4LTMgcHktMiB0ZXh0LXNsYXRlLTkwMCBvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLWJyYW5kLTUwMCBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1icmFuZC0xMDBcIiAvPlxuICAgICAgICAgICAgPC9sYWJlbD5cblxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1iLTEgYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTcwMFwiPkRpZmZpY3VsdHk8L3NwYW4+XG4gICAgICAgICAgICAgIDxzZWxlY3QgdmFsdWU9e2RpZmZpY3VsdHl9IG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldERpZmZpY3VsdHkoZXZlbnQudGFyZ2V0LnZhbHVlKX0gY2xhc3NOYW1lPVwidy1mdWxsIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1zbGF0ZS0zMDAgYmctd2hpdGUgcHgtMyBweS0yIHRleHQtc2xhdGUtOTAwIG91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItYnJhbmQtNTAwIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJyYW5kLTEwMFwiPlxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJlYXN5XCI+ZWFzeTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJtZWRpdW1cIj5tZWRpdW08L29wdGlvbj5cbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiaGFyZFwiPmhhcmQ8L29wdGlvbj5cbiAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICA8L2xhYmVsPlxuXG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2tcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWItMSBibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNzAwXCI+VGltZSBMaW1pdCAobWludXRlcyk8L3NwYW4+XG4gICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwibnVtYmVyXCIgbWluPXs1fSB2YWx1ZT17dGltZUxpbWl0TWluc30gb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0VGltZUxpbWl0TWlucyhOdW1iZXIoZXZlbnQudGFyZ2V0LnZhbHVlKSB8fCAzMCl9IGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItc2xhdGUtMzAwIGJnLXdoaXRlIHB4LTMgcHktMiB0ZXh0LXNsYXRlLTkwMCBvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLWJyYW5kLTUwMCBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1icmFuZC0xMDBcIiAvPlxuICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYi0yIGJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS03MDBcIj5TdXBwb3J0ZWQgTGFuZ3VhZ2VzPC9zcGFuPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAtM1wiPlxuICAgICAgICAgICAgICB7c3VwcG9ydGVkTGFuZ3VhZ2VzLm1hcCgobGFuZ3VhZ2UpID0+IChcbiAgICAgICAgICAgICAgICA8bGFiZWwga2V5PXtsYW5ndWFnZX0gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBiZy1zbGF0ZS01MCBweC0zIHB5LTIgdGV4dC1zbSB0ZXh0LXNsYXRlLTcwMFwiPlxuICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJjaGVja2JveFwiIGNoZWNrZWQ9e2xhbmd1YWdlU3VwcG9ydC5pbmNsdWRlcyhsYW5ndWFnZSl9IG9uQ2hhbmdlPXsoKSA9PiB0b2dnbGVMYW5ndWFnZShsYW5ndWFnZSl9IGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxuICAgICAgICAgICAgICAgICAge2xhbmd1YWdlfVxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7bGFuZ3VhZ2VTdXBwb3J0Lmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTQgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTEwMCBwdC00XCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1iLTEgYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTcwMFwiPlN0YXJ0ZXIgQ29kZSAoT3B0aW9uYWwpPC9zcGFuPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwXCI+UHJvdmlkZSBzdGFydGVyIGNvZGUgdGVtcGxhdGVzIHRoYXQgY2FuZGlkYXRlcyB3aWxsIHNlZSB3aGVuIHN0YXJ0aW5nIHRoZSBjaGFsbGVuZ2UgaW4gZWFjaCBzdXBwb3J0ZWQgbGFuZ3VhZ2UuPC9wPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ2FwLTQgbWQ6Z3JpZC1jb2xzLTJcIj5cbiAgICAgICAgICAgICAgICB7bGFuZ3VhZ2VTdXBwb3J0Lm1hcCgobGFuZykgPT4ge1xuICAgICAgICAgICAgICAgICAgY29uc3QgbGFuZ0tleSA9IGxhbmcudG9Mb3dlckNhc2UoKTtcbiAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBrZXk9e2xhbmd9IGNsYXNzTmFtZT1cImJsb2NrIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS0xMDAgYmctc2xhdGUtNTAgcC00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWItMiBibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtNTAwXCI+e2xhbmd9IFN0YXJ0ZXIgQ29kZTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8dGV4dGFyZWFcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzdGFydGVyQ29kZVtsYW5nS2V5XSB8fCBcIlwifVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHZhbCA9IGUudGFyZ2V0LnZhbHVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRTdGFydGVyQ29kZSgocHJldikgPT4gKHsgLi4ucHJldiwgW2xhbmdLZXldOiB2YWwgfSkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1pbi1oLTI0IHctZnVsbCByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItc2xhdGUtMzAwIGJnLXdoaXRlIGZvbnQtbW9ubyBweC0zIHB5LTIgdGV4dC1zbSB0ZXh0LXNsYXRlLTkwMCBvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLWJyYW5kLTUwMCBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1icmFuZC0xMDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9e2AvLyBTdGFydGVyIGNvZGUgZm9yICR7bGFuZ30uLi5gfVxuICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00IGJvcmRlci10IGJvcmRlci1zbGF0ZS0yMDAgcHQtNlwiPlxuICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS05MDBcIj5Qcm9ibGVtIFN0YXRlbWVudDwvaDM+XG4gICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYi0xIGJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS03MDBcIj5Qcm9ibGVtIFN0YXRlbWVudDwvc3Bhbj5cbiAgICAgICAgICAgIDx0ZXh0YXJlYSB2YWx1ZT17cHJvYmxlbVN0YXRlbWVudH0gb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0UHJvYmxlbVN0YXRlbWVudChldmVudC50YXJnZXQudmFsdWUpfSBjbGFzc05hbWU9XCJtaW4taC0zNiB3LWZ1bGwgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCBiZy13aGl0ZSBweC0zIHB5LTIgdGV4dC1zbGF0ZS05MDAgb3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1icmFuZC01MDAgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYnJhbmQtMTAwXCIgcmVxdWlyZWQgLz5cbiAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9ja1wiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWItMSBibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNzAwXCI+Q29uc3RyYWludHM8L3NwYW4+XG4gICAgICAgICAgICA8dGV4dGFyZWEgdmFsdWU9e2NvbnN0cmFpbnRzfSBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXRDb25zdHJhaW50cyhldmVudC50YXJnZXQudmFsdWUpfSBjbGFzc05hbWU9XCJtaW4taC0yMCB3LWZ1bGwgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCBiZy13aGl0ZSBweC0zIHB5LTIgdGV4dC1zbGF0ZS05MDAgb3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1icmFuZC01MDAgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYnJhbmQtMTAwXCIgLz5cbiAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9ja1wiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWItMSBibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNzAwXCI+RXhhbXBsZXM8L3NwYW4+XG4gICAgICAgICAgICA8dGV4dGFyZWEgdmFsdWU9e2V4YW1wbGVzfSBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXRFeGFtcGxlcyhldmVudC50YXJnZXQudmFsdWUpfSBjbGFzc05hbWU9XCJtaW4taC0yMCB3LWZ1bGwgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCBiZy13aGl0ZSBweC0zIHB5LTIgdGV4dC1zbGF0ZS05MDAgb3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1icmFuZC01MDAgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYnJhbmQtMTAwXCIgcGxhY2Vob2xkZXI9XCJJbnB1dDogNSAtPiBPdXRwdXQ6IDEwXCIgLz5cbiAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNCBib3JkZXItdCBib3JkZXItc2xhdGUtMjAwIHB0LTZcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtOTAwXCI+VGVzdCBDYXNlczwvaDM+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBiZy1zbGF0ZS01MCBwLTFcIj5cbiAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlVGFiKFwibWFudWFsXCIpfSBjbGFzc05hbWU9e2Byb3VuZGVkLW1kIHB4LTMgcHktMS41IHRleHQtc20gZm9udC1tZWRpdW0gJHthY3RpdmVUYWIgPT09IFwibWFudWFsXCIgPyBcImJnLXdoaXRlIHRleHQtc2xhdGUtOTAwIHNoYWRvdy1zbVwiIDogXCJ0ZXh0LXNsYXRlLTYwMFwifWB9PlxuICAgICAgICAgICAgICAgIEFkZCBNYW51YWxseVxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlVGFiKFwiYWlcIil9IGNsYXNzTmFtZT17YHJvdW5kZWQtbWQgcHgtMyBweS0xLjUgdGV4dC1zbSBmb250LW1lZGl1bSAke2FjdGl2ZVRhYiA9PT0gXCJhaVwiID8gXCJiZy13aGl0ZSB0ZXh0LXNsYXRlLTkwMCBzaGFkb3ctc21cIiA6IFwidGV4dC1zbGF0ZS02MDBcIn1gfT5cbiAgICAgICAgICAgICAgICBHZW5lcmF0ZSB3aXRoIEFJXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7YWN0aXZlVGFiID09PSBcIm1hbnVhbFwiID8gKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMFwiPlxuICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJtaW4tdy1mdWxsIHRleHQtbGVmdCB0ZXh0LXNtXCI+XG4gICAgICAgICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwiYmctc2xhdGUtNTBcIj5cbiAgICAgICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTIgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTYwMFwiPklucHV0PC90aD5cbiAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0yIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS02MDBcIj5FeHBlY3RlZCBPdXRwdXQ8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTIgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTYwMFwiPkhpZGRlbj88L3RoPlxuICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTIgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTYwMFwiPkVkZ2UgQ2FzZT88L3RoPlxuICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTIgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTYwMFwiPlJlbW92ZTwvdGg+XG4gICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICAgICAgPHRib2R5PlxuICAgICAgICAgICAgICAgICAgICB7bWFudWFsVGVzdHMubWFwKChyb3csIGluZGV4KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgPHRyIGtleT17cm93LmlkfSBjbGFzc05hbWU9XCJib3JkZXItdCBib3JkZXItc2xhdGUtMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0yXCI+PGlucHV0IHZhbHVlPXtyb3cuaW5wdXR9IG9uQ2hhbmdlPXsoZXZlbnQpID0+IHVwZGF0ZU1hbnVhbFJvdyhpbmRleCwgXCJpbnB1dFwiLCBldmVudC50YXJnZXQudmFsdWUpfSBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCBiZy13aGl0ZSBweC0yIHB5LTEuNSB0ZXh0LXNsYXRlLTkwMCBvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLWJyYW5kLTUwMCBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1icmFuZC0xMDBcIiAvPjwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0yXCI+PGlucHV0IHZhbHVlPXtyb3cuZXhwZWN0ZWRfb3V0cHV0fSBvbkNoYW5nZT17KGV2ZW50KSA9PiB1cGRhdGVNYW51YWxSb3coaW5kZXgsIFwiZXhwZWN0ZWRfb3V0cHV0XCIsIGV2ZW50LnRhcmdldC52YWx1ZSl9IGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItc2xhdGUtMzAwIGJnLXdoaXRlIHB4LTIgcHktMS41IHRleHQtc2xhdGUtOTAwIG91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItYnJhbmQtNTAwIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJyYW5kLTEwMFwiIC8+PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTJcIj48aW5wdXQgdHlwZT1cImNoZWNrYm94XCIgY2hlY2tlZD17cm93LmlzX2hpZGRlbn0gb25DaGFuZ2U9eyhldmVudCkgPT4gdXBkYXRlTWFudWFsUm93KGluZGV4LCBcImlzX2hpZGRlblwiLCBldmVudC50YXJnZXQuY2hlY2tlZCl9IGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPjwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0yXCI+PGlucHV0IHR5cGU9XCJjaGVja2JveFwiIGNoZWNrZWQ9e3Jvdy5pc19lZGdlX2Nhc2V9IG9uQ2hhbmdlPXsoZXZlbnQpID0+IHVwZGF0ZU1hbnVhbFJvdyhpbmRleCwgXCJpc19lZGdlX2Nhc2VcIiwgZXZlbnQudGFyZ2V0LmNoZWNrZWQpfSBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz48L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktMlwiPjxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHJlbW92ZU1hbnVhbFJvdyhpbmRleCl9IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1yZWQtNjAwIGhvdmVyOnRleHQtcmVkLTcwMFwiPlJlbW92ZTwvYnV0dG9uPjwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8QnV0dG9uIHR5cGU9XCJidXR0b25cIiB2YXJpYW50PVwic2Vjb25kYXJ5XCIgb25DbGljaz17YWRkTWFudWFsUm93fT5BZGQgUm93PC9CdXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApIDogKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgPEJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwibWluLXctNDRcIiBkaXNhYmxlZD17YWlMb2FkaW5nfSBvbkNsaWNrPXtoYW5kbGVHZW5lcmF0ZUFJVGVzdHN9PlxuICAgICAgICAgICAgICAgIHthaUxvYWRpbmcgPyA8U3Bpbm5lciBsYWJlbD1cIkdlbmVyYXRpbmdcIiAvPiA6IFwiR2VuZXJhdGUgVGVzdCBDYXNlc1wifVxuICAgICAgICAgICAgICA8L0J1dHRvbj5cblxuICAgICAgICAgICAgICB7YWlHZW5lcmF0ZWRUZXN0cy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwibWluLXctZnVsbCB0ZXh0LWxlZnQgdGV4dC1zbVwiPlxuICAgICAgICAgICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1zbGF0ZS01MFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0yIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS02MDBcIj5JbnB1dDwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTIgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTYwMFwiPkV4cGVjdGVkIE91dHB1dDwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTIgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTYwMFwiPlR5cGU8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICAgICAgICAgIDx0Ym9keT5cbiAgICAgICAgICAgICAgICAgICAgICAgIHthaUdlbmVyYXRlZFRlc3RzLm1hcCgocm93LCBpbmRleCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtgJHtyb3cudHlwZX0tJHtpbmRleH1gfSBjbGFzc05hbWU9XCJib3JkZXItdCBib3JkZXItc2xhdGUtMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktMlwiPntyb3cuaW5wdXR9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0yXCI+e3Jvdy5leHBlY3RlZF9vdXRwdXR9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0yIGNhcGl0YWxpemVcIj57cm93LnR5cGV9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxCdXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9e2hhbmRsZUltcG9ydEFJVGVzdHN9PlxuICAgICAgICAgICAgICAgICAgICBJbXBvcnQgdG8gTWFudWFsIExpc3RcbiAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIGJvcmRlci10IGJvcmRlci1zbGF0ZS0yMDAgcHQtNlwiPlxuICAgICAgICAgIDxCdXR0b24gdHlwZT1cImJ1dHRvblwiIGRpc2FibGVkPXtzdWJtaXR0aW5nfSBvbkNsaWNrPXtoYW5kbGVDcmVhdGVBc3Nlc3NtZW50fT5cbiAgICAgICAgICAgIHtzdWJtaXR0aW5nID8gPFNwaW5uZXIgbGFiZWw9XCJDcmVhdGluZ1wiIC8+IDogXCJDcmVhdGUgQXNzZXNzbWVudFwifVxuICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvc2VjdGlvbj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiQzovVXNlcnMvWWFzd2FudGggUmFodWwvRG93bmxvYWRzL0JpdExhYnMtQ29kaW5nLUxhYi9mcm9udGVuZC9zcmMvcm91dGVzL0Fzc2Vzc21lbnRCdWlsZGVyLnRzeCJ9