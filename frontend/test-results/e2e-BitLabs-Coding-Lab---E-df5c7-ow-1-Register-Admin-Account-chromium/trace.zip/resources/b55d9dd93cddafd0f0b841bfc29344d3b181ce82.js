import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/CandidateDashboard.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1cbb189e"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=1cbb189e"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=1cbb189e";
import toast from "/node_modules/.vite/deps/react-hot-toast.js?v=1cbb189e";
import { approveCandidateInvitation, getCandidateInvitations } from "/src/api/assessments.ts";
import { getProgress, getHistory } from "/src/api/practice.ts";
import { getSubmission } from "/src/api/submissions.ts";
import { clearToken } from "/src/api/auth.ts";
import Badge from "/src/components/ui/Badge.tsx";
import Button from "/src/components/ui/Button.tsx";
import Spinner from "/src/components/ui/Spinner.tsx";
export default function CandidateDashboard() {
  _s();
  const navigate = useNavigate();
  const [invitations, setInvitations] = useState([]);
  const [solvedCount, setSolvedCount] = useState(0);
  const [lastActive, setLastActive] = useState(null);
  const [practiceHistory, setPracticeHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [approvingId, setApprovingId] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalLoading, setModalLoading] = useState(false);
  const [selectedSubmission, setSelectedSubmission] = useState(null);
  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      const invData = await getCandidateInvitations();
      setInvitations(invData);
      const progressData = await getProgress();
      setSolvedCount(progressData.total_solved);
      setLastActive(progressData.last_active);
      const historyData = await getHistory();
      setPracticeHistory(historyData);
    } catch (error) {
      toast.error("Unable to load dashboard data.");
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    void fetchDashboardData();
  }, []);
  const handleApprove = async (invitationId) => {
    try {
      setApprovingId(invitationId);
      const res = await approveCandidateInvitation(invitationId);
      toast.success("Assessment approved! Your test link has been generated.");
      setInvitations(
        (prev) => prev.map(
          (item) => item.invitation_id === invitationId ? { ...item, status: "active", token: res.token, test_url: res.test_url } : item
        )
      );
    } catch (error) {
      toast.error("Failed to approve assessment.");
    } finally {
      setApprovingId(null);
    }
  };
  const handleLogout = () => {
    clearToken();
    navigate("/auth");
    toast.success("Logged out successfully.");
  };
  const handleViewAIReview = async (submissionId) => {
    try {
      setIsModalOpen(true);
      setModalLoading(true);
      setSelectedSubmission(null);
      const subData = await getSubmission(submissionId);
      setSelectedSubmission(subData);
    } catch (err) {
      toast.error("Failed to load AI evaluation details.");
      setIsModalOpen(false);
    } finally {
      setModalLoading(false);
    }
  };
  if (loading) {
    return /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-[60vh] items-center justify-center bg-white", children: /* @__PURE__ */ jsxDEV(Spinner, { label: "Loading workspace data..." }, void 0, false, {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
      lineNumber: 126,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
      lineNumber: 125,
      columnNumber: 7
    }, this);
  }
  const pendingList = invitations.filter((item) => item.status === "pending");
  const activeList = invitations.filter((item) => item.status === "active");
  const completedList = invitations.filter((item) => item.status === "completed");
  return /* @__PURE__ */ jsxDEV("div", { className: "bg-white min-h-screen text-slate-800 p-6 max-w-5xl mx-auto space-y-8 select-none", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between border-b border-slate-200 pb-4 mb-6", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold text-slate-900", children: "BitLabs — Candidate Dashboard" }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
        lineNumber: 139,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: handleLogout,
          className: "rounded border border-slate-350 bg-white hover:bg-slate-50 text-slate-700 px-4 py-1.5 text-sm font-semibold shadow-sm transition-colors",
          children: "Logout"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
          lineNumber: 140,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
      lineNumber: 138,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid gap-6 md:grid-cols-3", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "rounded-xl border border-slate-200 bg-slate-50 p-6 shadow-sm flex flex-col justify-between", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-semibold uppercase tracking-wider text-slate-500 block mb-1", children: "Problems Solved" }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
            lineNumber: 153,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-4xl font-extrabold text-blue-600", children: solvedCount }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
            lineNumber: 156,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
          lineNumber: 152,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-slate-400 mt-2 block", children: "Keep coding to level up!" }, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
          lineNumber: 158,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
        lineNumber: 151,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "rounded-xl border border-slate-200 bg-slate-50 p-6 shadow-sm flex flex-col justify-between", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-semibold uppercase tracking-wider text-slate-500 block mb-1", children: "Last Active" }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
            lineNumber: 164,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-lg font-bold text-slate-800 block", children: lastActive ? new Date(lastActive).toLocaleDateString("en-US", {
            year: "numeric",
            month: "short",
            day: "numeric",
            hour: "2-digit",
            minute: "2-digit"
          }) : "N/A" }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
            lineNumber: 167,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
          lineNumber: 163,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-slate-400 mt-2 block", children: "Your last practice session" }, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
          lineNumber: 177,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
        lineNumber: 162,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "rounded-xl border border-slate-200 bg-slate-50 p-6 shadow-sm flex flex-col justify-between", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-semibold uppercase tracking-wider text-slate-500 block mb-1", children: "Practice Arena" }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
            lineNumber: 183,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-slate-600 block", children: "Sharpen your code skills with AI feedback." }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
            lineNumber: 186,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
          lineNumber: 182,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => navigate("/practice"),
            className: "w-full mt-4 bg-blue-600 hover:bg-blue-700 text-white rounded py-2 text-sm font-semibold transition-colors shadow-sm",
            children: "Go Practice →"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
            lineNumber: 188,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
        lineNumber: 181,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
      lineNumber: 149,
      columnNumber: 7
    }, this),
    pendingList.length > 0 && /* @__PURE__ */ jsxDEV("section", { className: "space-y-4 pt-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 text-amber-800", children: [
        /* @__PURE__ */ jsxDEV("svg", { className: "h-5 w-5 text-amber-500", fill: "none", viewBox: "0 0 24 24", strokeWidth: 2, stroke: "currentColor", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", d: "M12 9v3.75m9-.75a9 9 0 1 1-18 0 9 9 0 0 1 18 0Zm-9 3.75h.008v.008H12v-.008Z" }, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
          lineNumber: 202,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
          lineNumber: 201,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-bold text-slate-900", children: [
          "Pending Assessments (",
          pendingList.length,
          ") — Action Required"
        ] }, void 0, true, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
          lineNumber: 204,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
        lineNumber: 200,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid gap-4", children: pendingList.map(
        (item) => /* @__PURE__ */ jsxDEV("div", { className: "rounded-xl border border-amber-200 bg-amber-50/60 p-5 shadow-sm", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-start justify-between gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsxDEV("h4", { className: "text-lg font-bold text-slate-900", children: item.title }, void 0, false, {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
                lineNumber: 215,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(Badge, { status: "draft", children: "pending approval" }, void 0, false, {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
                lineNumber: 216,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
              lineNumber: 214,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "mt-1.5 text-sm text-slate-700", children: item.description }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
              lineNumber: 218,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mt-3 flex flex-wrap gap-4 text-xs font-medium text-slate-600", children: [
              /* @__PURE__ */ jsxDEV("span", { children: [
                "Difficulty: ",
                /* @__PURE__ */ jsxDEV("strong", { className: "capitalize text-slate-800", children: item.difficulty }, void 0, false, {
                  fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
                  lineNumber: 220,
                  columnNumber: 41
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
                lineNumber: 220,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: [
                "Time Limit: ",
                /* @__PURE__ */ jsxDEV("strong", { className: "text-slate-800", children: [
                  item.time_limit_mins,
                  " mins"
                ] }, void 0, true, {
                  fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
                  lineNumber: 221,
                  columnNumber: 41
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
                lineNumber: 221,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
              lineNumber: 219,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
            lineNumber: 213,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              type: "button",
              disabled: approvingId === item.invitation_id,
              onClick: () => handleApprove(item.invitation_id),
              children: approvingId === item.invitation_id ? /* @__PURE__ */ jsxDEV(Spinner, { label: "Approving" }, void 0, false, {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
                lineNumber: 231,
                columnNumber: 17
              }, this) : "Approve Assessment & Generate Link"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
              lineNumber: 225,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
          lineNumber: 212,
          columnNumber: 17
        }, this) }, item.invitation_id, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
          lineNumber: 211,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
        lineNumber: 209,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
      lineNumber: 199,
      columnNumber: 7
    }, this),
    activeList.length > 0 && /* @__PURE__ */ jsxDEV("section", { className: "space-y-4 pt-4", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-bold text-slate-900", children: "Active Assessments" }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
        lineNumber: 246,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid gap-4", children: activeList.map(
        (item) => /* @__PURE__ */ jsxDEV("div", { className: "rounded-xl border border-emerald-200 bg-emerald-50/50 p-5 shadow-sm", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center justify-between gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsxDEV("h4", { className: "text-lg font-bold text-slate-900", children: item.title }, void 0, false, {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
                lineNumber: 253,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(Badge, { status: "active", children: "ready to take" }, void 0, false, {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
                lineNumber: 254,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
              lineNumber: 252,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-slate-700", children: item.description }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
              lineNumber: 256,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mt-3 flex flex-wrap gap-4 text-xs font-medium text-slate-600", children: [
              /* @__PURE__ */ jsxDEV("span", { children: [
                "Difficulty: ",
                /* @__PURE__ */ jsxDEV("strong", { className: "capitalize text-slate-800", children: item.difficulty }, void 0, false, {
                  fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
                  lineNumber: 258,
                  columnNumber: 41
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
                lineNumber: 258,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: [
                "Time Limit: ",
                /* @__PURE__ */ jsxDEV("strong", { className: "text-slate-800", children: [
                  item.time_limit_mins,
                  " mins"
                ] }, void 0, true, {
                  fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
                  lineNumber: 259,
                  columnNumber: 41
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
                lineNumber: 259,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
              lineNumber: 257,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
            lineNumber: 251,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { type: "button", onClick: () => navigate(`/assessment/${item.token}`), children: "Start Assessment →" }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
            lineNumber: 263,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
          lineNumber: 250,
          columnNumber: 17
        }, this) }, item.invitation_id, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
          lineNumber: 249,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
        lineNumber: 247,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
      lineNumber: 245,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "space-y-4 pt-4", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-bold text-slate-900", children: "My Assessments" }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
        lineNumber: 275,
        columnNumber: 9
      }, this),
      completedList.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "rounded-xl border border-slate-200 bg-slate-50 p-6 text-center text-sm text-slate-500 italic", children: "No assessments taken yet." }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
        lineNumber: 277,
        columnNumber: 9
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto rounded-xl border border-slate-200 bg-white shadow-sm", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-slate-200 text-left text-sm", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-slate-50 font-semibold text-slate-700 text-xs uppercase tracking-wider", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("th", { className: "px-6 py-3", children: "Assessment" }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
            lineNumber: 285,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-6 py-3", children: "Score" }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
            lineNumber: 286,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-6 py-3", children: "Status" }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
            lineNumber: 287,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-6 py-3", children: "Date" }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
            lineNumber: 288,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-6 py-3", children: "AI Review" }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
            lineNumber: 289,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
          lineNumber: 284,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
          lineNumber: 283,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "divide-y divide-slate-200 text-slate-800", children: completedList.map(
          (item) => /* @__PURE__ */ jsxDEV("tr", { className: "hover:bg-slate-50/50", children: [
            /* @__PURE__ */ jsxDEV("td", { className: "px-6 py-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "font-semibold text-slate-900", children: item.title }, void 0, false, {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
                lineNumber: 296,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-slate-500 capitalize", children: item.difficulty }, void 0, false, {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
                lineNumber: 297,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
              lineNumber: 295,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-6 py-4 font-bold text-slate-900", children: item.score !== null ? `${item.score} / 100` : "Pending" }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
              lineNumber: 299,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-6 py-4", children: /* @__PURE__ */ jsxDEV("span", { className: "inline-flex rounded-full bg-slate-100 px-2 py-0.5 text-xs font-medium text-slate-800 border border-slate-200", children: "Submitted" }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
              lineNumber: 303,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
              lineNumber: 302,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-6 py-4 text-xs text-slate-500", children: new Date(item.expires_at).toLocaleDateString() }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
              lineNumber: 307,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-6 py-4", children: item.submission_id ? /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => handleViewAIReview(item.submission_id),
                className: "bg-blue-50 hover:bg-blue-100 text-blue-600 rounded px-3 py-1.5 text-xs font-semibold transition-colors border border-blue-200",
                children: "View Review"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
                lineNumber: 312,
                columnNumber: 19
              },
              this
            ) : /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-slate-400", children: "Unavailable" }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
              lineNumber: 319,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
              lineNumber: 310,
              columnNumber: 21
            }, this)
          ] }, item.invitation_id, true, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
            lineNumber: 294,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
          lineNumber: 292,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
        lineNumber: 282,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
        lineNumber: 281,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
      lineNumber: 274,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "space-y-4 pt-4", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-bold text-slate-900", children: "Practice Activity" }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
        lineNumber: 332,
        columnNumber: 9
      }, this),
      practiceHistory.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "rounded-xl border border-slate-200 bg-slate-50 p-6 text-center text-sm text-slate-500 italic", children: "Start practicing to see your history here." }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
        lineNumber: 334,
        columnNumber: 9
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto rounded-xl border border-slate-200 bg-white shadow-sm", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-slate-200 text-left text-sm", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-slate-50 font-semibold text-slate-700 text-xs uppercase tracking-wider", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("th", { className: "px-6 py-3", children: "Language" }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
            lineNumber: 342,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-6 py-3", children: "Result" }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
            lineNumber: 343,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-6 py-3", children: "Date" }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
            lineNumber: 344,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
          lineNumber: 341,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
          lineNumber: 340,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "divide-y divide-slate-200 text-slate-800", children: practiceHistory.slice(0, 20).map(
          (att) => /* @__PURE__ */ jsxDEV("tr", { className: "hover:bg-slate-50/50", children: [
            /* @__PURE__ */ jsxDEV("td", { className: "px-6 py-4 font-mono font-medium text-slate-700 capitalize", children: att.language }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
              lineNumber: 350,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-6 py-4", children: att.is_correct ? /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1 rounded bg-green-50 border border-green-200 px-2 py-0.5 text-xs font-semibold text-green-700", children: "✓ Correct" }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
              lineNumber: 355,
              columnNumber: 19
            }, this) : /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1 rounded bg-rose-50 border border-rose-200 px-2 py-0.5 text-xs font-semibold text-rose-700", children: "✗ Needs Work" }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
              lineNumber: 359,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
              lineNumber: 353,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-6 py-4 text-xs text-slate-500", children: new Date(att.attempted_at).toLocaleString() }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
              lineNumber: 364,
              columnNumber: 21
            }, this)
          ] }, att.id, true, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
            lineNumber: 349,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
          lineNumber: 347,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
        lineNumber: 339,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
        lineNumber: 338,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
      lineNumber: 331,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "rounded-2xl border border-slate-200 bg-slate-50 p-8 text-center shadow-sm max-w-xl mx-auto mt-6", children: [
      /* @__PURE__ */ jsxDEV("h4", { className: "text-xl font-bold text-slate-900 mb-2", children: "Ready to practice?" }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
        lineNumber: 377,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-slate-600 text-sm mb-5", children: "Access the open coding playground and test your code against sandbox execution." }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
        lineNumber: 378,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => navigate("/practice"),
          className: "bg-blue-600 hover:bg-blue-700 text-white rounded px-6 py-2 text-sm font-semibold transition-colors shadow-md",
          children: "Open Practice Arena"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
          lineNumber: 381,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
      lineNumber: 376,
      columnNumber: 7
    }, this),
    isModalOpen && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 p-4 animate-fade-in", children: /* @__PURE__ */ jsxDEV("div", { className: "w-full max-w-2xl rounded-xl border border-slate-200 bg-white p-6 shadow-xl flex flex-col max-h-[90vh]", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between border-b border-slate-200 pb-3", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-bold text-slate-900 flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV("span", { children: "🤖" }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
            lineNumber: 395,
            columnNumber: 17
          }, this),
          " AI Evaluation Summary"
        ] }, void 0, true, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
          lineNumber: 394,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setIsModalOpen(false),
            className: "text-slate-400 hover:text-slate-600 text-sm font-bold p-1",
            children: "✕"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
            lineNumber: 397,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
        lineNumber: 393,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-1 overflow-y-auto py-4 space-y-4", children: modalLoading ? /* @__PURE__ */ jsxDEV("div", { className: "py-12 flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(Spinner, { label: "AI is loading evaluation detail..." }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
        lineNumber: 408,
        columnNumber: 19
      }, this) }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
        lineNumber: 407,
        columnNumber: 13
      }, this) : selectedSubmission ? /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between p-4 bg-slate-50 rounded-xl border border-slate-200", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-slate-500 font-semibold uppercase tracking-wider block", children: "AI Evaluated Score" }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
              lineNumber: 415,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-baseline gap-0.5 mt-0.5", children: [
              /* @__PURE__ */ jsxDEV("span", { className: `text-4xl font-extrabold ${selectedSubmission.ai_evaluation?.ai_score && selectedSubmission.ai_evaluation.ai_score >= 70 ? "text-green-600" : selectedSubmission.ai_evaluation?.ai_score && selectedSubmission.ai_evaluation.ai_score >= 40 ? "text-yellow-600" : "text-red-600"}`, children: selectedSubmission.ai_evaluation?.ai_score ?? 0 }, void 0, false, {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
                lineNumber: 417,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-slate-400 text-xs font-semibold", children: "/100" }, void 0, false, {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
                lineNumber: 426,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
              lineNumber: 416,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
            lineNumber: 414,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("span", { className: "inline-flex rounded-full bg-blue-50 border border-blue-200 px-3 py-1 text-xs font-semibold text-blue-700", children: "Review Done" }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
            lineNumber: 430,
            columnNumber: 23
          }, this) }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
            lineNumber: 429,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
          lineNumber: 413,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h5", { className: "text-sm font-bold text-slate-800 uppercase tracking-wider mb-1", children: "Strengths" }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
            lineNumber: 438,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-slate-600 text-sm leading-relaxed whitespace-pre-wrap", children: selectedSubmission.ai_evaluation?.strengths || "No specific feedback generated." }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
            lineNumber: 439,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
          lineNumber: 437,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h5", { className: "text-sm font-bold text-slate-800 uppercase tracking-wider mb-1", children: "Weaknesses" }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
            lineNumber: 446,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-slate-600 text-sm leading-relaxed whitespace-pre-wrap", children: selectedSubmission.ai_evaluation?.weaknesses || "No critical issues detected." }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
            lineNumber: 447,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
          lineNumber: 445,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h5", { className: "text-sm font-bold text-slate-800 uppercase tracking-wider mb-1", children: "Recommendations" }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
            lineNumber: 454,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-slate-600 text-sm leading-relaxed whitespace-pre-wrap", children: selectedSubmission.ai_evaluation?.recommendations || "Continue practicing!" }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
            lineNumber: 455,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
          lineNumber: 453,
          columnNumber: 19
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
        lineNumber: 411,
        columnNumber: 13
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "text-center text-slate-500 py-8 text-sm italic", children: "Could not load evaluation." }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
        lineNumber: 461,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
        lineNumber: 405,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "border-t border-slate-200 pt-3 flex justify-end", children: /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => setIsModalOpen(false),
          className: "bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold px-4 py-2 rounded text-sm transition-colors border border-slate-300",
          children: "Close"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
          lineNumber: 468,
          columnNumber: 15
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
        lineNumber: 467,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
      lineNumber: 392,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
      lineNumber: 391,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx",
    lineNumber: 136,
    columnNumber: 5
  }, this);
}
_s(CandidateDashboard, "lABU1B0pV2FfHeQbQtkIm1zGsGM=", false, function() {
  return [useNavigate];
});
_c = CandidateDashboard;
var _c;
$RefreshReg$(_c, "CandidateDashboard");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/CandidateDashboard.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMEdROzs7Ozs7Ozs7Ozs7Ozs7OztBQTFHUixTQUFTQSxXQUFXQyxnQkFBZ0I7QUFDcEMsU0FBU0MsbUJBQW1CO0FBQzVCLE9BQU9DLFdBQVc7QUFDbEIsU0FBU0MsNEJBQTRCQywrQkFBeUQ7QUFDOUYsU0FBU0MsYUFBYUMsa0JBQThDO0FBQ3BFLFNBQVNDLHFCQUFxQjtBQUM5QixTQUFTQyxrQkFBa0I7QUFDM0IsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGFBQWE7QUFhcEIsd0JBQXdCQyxxQkFBcUI7QUFBQUMsS0FBQTtBQUMzQyxRQUFNQyxXQUFXYixZQUFZO0FBQzdCLFFBQU0sQ0FBQ2MsYUFBYUMsY0FBYyxJQUFJaEIsU0FBZ0MsRUFBRTtBQUN4RSxRQUFNLENBQUNpQixhQUFhQyxjQUFjLElBQUlsQixTQUFTLENBQUM7QUFDaEQsUUFBTSxDQUFDbUIsWUFBWUMsYUFBYSxJQUFJcEIsU0FBd0IsSUFBSTtBQUNoRSxRQUFNLENBQUNxQixpQkFBaUJDLGtCQUFrQixJQUFJdEIsU0FBa0MsRUFBRTtBQUVsRixRQUFNLENBQUN1QixTQUFTQyxVQUFVLElBQUl4QixTQUFTLElBQUk7QUFDM0MsUUFBTSxDQUFDeUIsYUFBYUMsY0FBYyxJQUFJMUIsU0FBd0IsSUFBSTtBQUdsRSxRQUFNLENBQUMyQixhQUFhQyxjQUFjLElBQUk1QixTQUFTLEtBQUs7QUFDcEQsUUFBTSxDQUFDNkIsY0FBY0MsZUFBZSxJQUFJOUIsU0FBUyxLQUFLO0FBQ3RELFFBQU0sQ0FBQytCLG9CQUFvQkMscUJBQXFCLElBQUloQyxTQUFtQyxJQUFJO0FBRTNGLFFBQU1pQyxxQkFBcUIsWUFBWTtBQUNyQyxRQUFJO0FBQ0ZULGlCQUFXLElBQUk7QUFFZixZQUFNVSxVQUFVLE1BQU05Qix3QkFBd0I7QUFDOUNZLHFCQUFla0IsT0FBTztBQUd0QixZQUFNQyxlQUFlLE1BQU05QixZQUFZO0FBQ3ZDYSxxQkFBZWlCLGFBQWFDLFlBQVk7QUFDeENoQixvQkFBY2UsYUFBYUUsV0FBVztBQUd0QyxZQUFNQyxjQUFjLE1BQU1oQyxXQUFXO0FBQ3JDZ0IseUJBQW1CZ0IsV0FBVztBQUFBLElBQ2hDLFNBQVNDLE9BQU87QUFDZHJDLFlBQU1xQyxNQUFNLGdDQUFnQztBQUFBLElBQzlDLFVBQUM7QUFDQ2YsaUJBQVcsS0FBSztBQUFBLElBQ2xCO0FBQUEsRUFDRjtBQUVBekIsWUFBVSxNQUFNO0FBQ2QsU0FBS2tDLG1CQUFtQjtBQUFBLEVBQzFCLEdBQUcsRUFBRTtBQUVMLFFBQU1PLGdCQUFnQixPQUFPQyxpQkFBeUI7QUFDcEQsUUFBSTtBQUNGZixxQkFBZWUsWUFBWTtBQUMzQixZQUFNQyxNQUFNLE1BQU12QywyQkFBMkJzQyxZQUFZO0FBQ3pEdkMsWUFBTXlDLFFBQVEseURBQXlEO0FBQ3ZFM0I7QUFBQUEsUUFBZSxDQUFDNEIsU0FDZEEsS0FBS0M7QUFBQUEsVUFBSSxDQUFDQyxTQUNSQSxLQUFLQyxrQkFBa0JOLGVBQ25CLEVBQUUsR0FBR0ssTUFBTUUsUUFBUSxVQUFVQyxPQUFPUCxJQUFJTyxPQUFPQyxVQUFVUixJQUFJUSxTQUFTLElBQ3RFSjtBQUFBQSxRQUNOO0FBQUEsTUFDRjtBQUFBLElBQ0YsU0FBU1AsT0FBTztBQUNkckMsWUFBTXFDLE1BQU0sK0JBQStCO0FBQUEsSUFDN0MsVUFBQztBQUNDYixxQkFBZSxJQUFJO0FBQUEsSUFDckI7QUFBQSxFQUNGO0FBRUEsUUFBTXlCLGVBQWVBLE1BQU07QUFDekIzQyxlQUFXO0FBQ1hNLGFBQVMsT0FBTztBQUNoQlosVUFBTXlDLFFBQVEsMEJBQTBCO0FBQUEsRUFDMUM7QUFFQSxRQUFNUyxxQkFBcUIsT0FBT0MsaUJBQXlCO0FBQ3pELFFBQUk7QUFDRnpCLHFCQUFlLElBQUk7QUFDbkJFLHNCQUFnQixJQUFJO0FBQ3BCRSw0QkFBc0IsSUFBSTtBQUMxQixZQUFNc0IsVUFBVSxNQUFNL0MsY0FBYzhDLFlBQVk7QUFDaERyQiw0QkFBc0JzQixPQUFPO0FBQUEsSUFDL0IsU0FBU0MsS0FBSztBQUNackQsWUFBTXFDLE1BQU0sdUNBQXVDO0FBQ25EWCxxQkFBZSxLQUFLO0FBQUEsSUFDdEIsVUFBQztBQUNDRSxzQkFBZ0IsS0FBSztBQUFBLElBQ3ZCO0FBQUEsRUFDRjtBQUVBLE1BQUlQLFNBQVM7QUFDWCxXQUNFLHVCQUFDLFNBQUksV0FBVSwwREFDYixpQ0FBQyxXQUFRLE9BQU0sK0JBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwQyxLQUQ1QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBRUEsUUFBTWlDLGNBQWN6QyxZQUFZMEMsT0FBTyxDQUFDWCxTQUFTQSxLQUFLRSxXQUFXLFNBQVM7QUFDMUUsUUFBTVUsYUFBYTNDLFlBQVkwQyxPQUFPLENBQUNYLFNBQVNBLEtBQUtFLFdBQVcsUUFBUTtBQUN4RSxRQUFNVyxnQkFBZ0I1QyxZQUFZMEMsT0FBTyxDQUFDWCxTQUFTQSxLQUFLRSxXQUFXLFdBQVc7QUFFOUUsU0FDRSx1QkFBQyxTQUFJLFdBQVUsb0ZBRWI7QUFBQSwyQkFBQyxTQUFJLFdBQVUseUVBQ2I7QUFBQSw2QkFBQyxRQUFHLFdBQVUscUNBQW9DLDZDQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStFO0FBQUEsTUFDL0U7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFNBQVNHO0FBQUFBLFVBQ1QsV0FBVTtBQUFBLFVBQXlJO0FBQUE7QUFBQSxRQUZySjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFLQTtBQUFBLFNBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsNkJBRWI7QUFBQSw2QkFBQyxTQUFJLFdBQVUsOEZBQ2I7QUFBQSwrQkFBQyxTQUNDO0FBQUEsaUNBQUMsVUFBSyxXQUFVLDRFQUEwRSwrQkFBMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsVUFBSyxXQUFVLHlDQUF5Q2xDLHlCQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxRTtBQUFBLGFBSnZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFFBQ0EsdUJBQUMsVUFBSyxXQUFVLHFDQUFvQyx3Q0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0RTtBQUFBLFdBUDlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLDhGQUNiO0FBQUEsK0JBQUMsU0FDQztBQUFBLGlDQUFDLFVBQUssV0FBVSw0RUFBMEUsMkJBQTFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFVBQUssV0FBVSwwQ0FDYkUsdUJBQWEsSUFBSXlDLEtBQUt6QyxVQUFVLEVBQUUwQyxtQkFBbUIsU0FBUztBQUFBLFlBQzdEQyxNQUFNO0FBQUEsWUFDTkMsT0FBTztBQUFBLFlBQ1BDLEtBQUs7QUFBQSxZQUNMQyxNQUFNO0FBQUEsWUFDTkMsUUFBUTtBQUFBLFVBQ1YsQ0FBQyxJQUFJLFNBUFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLGFBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWFBO0FBQUEsUUFDQSx1QkFBQyxVQUFLLFdBQVUscUNBQW9DLDBDQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThFO0FBQUEsV0FmaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdCQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLDhGQUNiO0FBQUEsK0JBQUMsU0FDQztBQUFBLGlDQUFDLFVBQUssV0FBVSw0RUFBMEUsOEJBQTFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFVBQUssV0FBVSxnQ0FBK0IsMERBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlGO0FBQUEsYUFKM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUyxNQUFNcEQsU0FBUyxXQUFXO0FBQUEsWUFDbkMsV0FBVTtBQUFBLFlBQXFIO0FBQUE7QUFBQSxVQUZqSTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLQTtBQUFBLFdBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWFBO0FBQUEsU0E3Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQThDQTtBQUFBLElBR0MwQyxZQUFZVyxTQUFTLEtBQ3BCLHVCQUFDLGFBQVEsV0FBVSxrQkFDakI7QUFBQSw2QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsMEJBQXlCLE1BQUssUUFBTyxTQUFRLGFBQVksYUFBYSxHQUFHLFFBQU8sZ0JBQzdGLGlDQUFDLFVBQUssZUFBYyxTQUFRLGdCQUFlLFNBQVEsR0FBRSxpRkFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrSSxLQURwSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFFBQUcsV0FBVSxvQ0FBa0M7QUFBQTtBQUFBLFVBQ3hCWCxZQUFZVztBQUFBQSxVQUFPO0FBQUEsYUFEM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxjQUNaWCxzQkFBWVg7QUFBQUEsUUFBSSxDQUFDQyxTQUNoQix1QkFBQyxTQUE2QixXQUFVLG1FQUN0QyxpQ0FBQyxTQUFJLFdBQVUsb0RBQ2I7QUFBQSxpQ0FBQyxTQUNDO0FBQUEsbUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEscUNBQUMsUUFBRyxXQUFVLG9DQUFvQ0EsZUFBS3NCLFNBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTZEO0FBQUEsY0FDN0QsdUJBQUMsU0FBTSxRQUFPLFNBQVEsZ0NBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNDO0FBQUEsaUJBRnhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLE9BQUUsV0FBVSxpQ0FBaUN0QixlQUFLdUIsZUFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0Q7QUFBQSxZQUMvRCx1QkFBQyxTQUFJLFdBQVUsZ0VBQ2I7QUFBQSxxQ0FBQyxVQUFLO0FBQUE7QUFBQSxnQkFBWSx1QkFBQyxZQUFPLFdBQVUsNkJBQTZCdkIsZUFBS3dCLGNBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQStEO0FBQUEsbUJBQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTBGO0FBQUEsY0FDMUYsdUJBQUMsVUFBSztBQUFBO0FBQUEsZ0JBQVksdUJBQUMsWUFBTyxXQUFVLGtCQUFrQnhCO0FBQUFBLHVCQUFLeUI7QUFBQUEsa0JBQWdCO0FBQUEscUJBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQThEO0FBQUEsbUJBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlGO0FBQUEsaUJBRjNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxlQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVUE7QUFBQSxVQUVBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxVQUFVOUMsZ0JBQWdCcUIsS0FBS0M7QUFBQUEsY0FDL0IsU0FBUyxNQUFNUCxjQUFjTSxLQUFLQyxhQUFhO0FBQUEsY0FFOUN0QiwwQkFBZ0JxQixLQUFLQyxnQkFDcEIsdUJBQUMsV0FBUSxPQUFNLGVBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMEIsSUFFMUI7QUFBQTtBQUFBLFlBUko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBVUE7QUFBQSxhQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0JBLEtBekJRRCxLQUFLQyxlQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEwQkE7QUFBQSxNQUNELEtBN0JIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE4QkE7QUFBQSxTQXhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBeUNBO0FBQUEsSUFJRFcsV0FBV1MsU0FBUyxLQUNuQix1QkFBQyxhQUFRLFdBQVUsa0JBQ2pCO0FBQUEsNkJBQUMsUUFBRyxXQUFVLG9DQUFtQyxrQ0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRTtBQUFBLE1BQ25FLHVCQUFDLFNBQUksV0FBVSxjQUNaVCxxQkFBV2I7QUFBQUEsUUFBSSxDQUFDQyxTQUNmLHVCQUFDLFNBQTZCLFdBQVUsdUVBQ3RDLGlDQUFDLFNBQUksV0FBVSxxREFDYjtBQUFBLGlDQUFDLFNBQ0M7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxxQ0FBQyxRQUFHLFdBQVUsb0NBQW9DQSxlQUFLc0IsU0FBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkQ7QUFBQSxjQUM3RCx1QkFBQyxTQUFNLFFBQU8sVUFBUyw2QkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBb0M7QUFBQSxpQkFGdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsT0FBRSxXQUFVLCtCQUErQnRCLGVBQUt1QixlQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2RDtBQUFBLFlBQzdELHVCQUFDLFNBQUksV0FBVSxnRUFDYjtBQUFBLHFDQUFDLFVBQUs7QUFBQTtBQUFBLGdCQUFZLHVCQUFDLFlBQU8sV0FBVSw2QkFBNkJ2QixlQUFLd0IsY0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBK0Q7QUFBQSxtQkFBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMEY7QUFBQSxjQUMxRix1QkFBQyxVQUFLO0FBQUE7QUFBQSxnQkFBWSx1QkFBQyxZQUFPLFdBQVUsa0JBQWtCeEI7QUFBQUEsdUJBQUt5QjtBQUFBQSxrQkFBZ0I7QUFBQSxxQkFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBOEQ7QUFBQSxtQkFBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBeUY7QUFBQSxpQkFGM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLGVBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLFVBRUEsdUJBQUMsVUFBTyxNQUFLLFVBQVMsU0FBUyxNQUFNekQsU0FBUyxlQUFlZ0MsS0FBS0csS0FBSyxFQUFFLEdBQUUsa0NBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnQkEsS0FqQlFILEtBQUtDLGVBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWtCQTtBQUFBLE1BQ0QsS0FyQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXNCQTtBQUFBLFNBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F5QkE7QUFBQSxJQUlGLHVCQUFDLGFBQVEsV0FBVSxrQkFDakI7QUFBQSw2QkFBQyxRQUFHLFdBQVUsb0NBQW1DLDhCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStEO0FBQUEsTUFDOURZLGNBQWNRLFdBQVcsSUFDeEIsdUJBQUMsU0FBSSxXQUFVLGdHQUE4Rix5Q0FBN0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBLElBRUEsdUJBQUMsU0FBSSxXQUFVLHlFQUNiLGlDQUFDLFdBQU0sV0FBVSwwREFDZjtBQUFBLCtCQUFDLFdBQU0sV0FBVSw2RUFDZixpQ0FBQyxRQUNDO0FBQUEsaUNBQUMsUUFBRyxXQUFVLGFBQVksMEJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9DO0FBQUEsVUFDcEMsdUJBQUMsUUFBRyxXQUFVLGFBQVkscUJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStCO0FBQUEsVUFDL0IsdUJBQUMsUUFBRyxXQUFVLGFBQVksc0JBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdDO0FBQUEsVUFDaEMsdUJBQUMsUUFBRyxXQUFVLGFBQVksb0JBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThCO0FBQUEsVUFDOUIsdUJBQUMsUUFBRyxXQUFVLGFBQVkseUJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1DO0FBQUEsYUFMckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsUUFDQSx1QkFBQyxXQUFNLFdBQVUsNENBQ2RSLHdCQUFjZDtBQUFBQSxVQUFJLENBQUNDLFNBQ2xCLHVCQUFDLFFBQTRCLFdBQVUsd0JBQ3JDO0FBQUEsbUNBQUMsUUFBRyxXQUFVLGFBQ1o7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsZ0NBQWdDQSxlQUFLc0IsU0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMEQ7QUFBQSxjQUMxRCx1QkFBQyxTQUFJLFdBQVUscUNBQXFDdEIsZUFBS3dCLGNBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9FO0FBQUEsaUJBRnRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLFFBQUcsV0FBVSxzQ0FDWHhCLGVBQUswQixVQUFVLE9BQU8sR0FBRzFCLEtBQUswQixLQUFLLFdBQVcsYUFEakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsUUFBRyxXQUFVLGFBQ1osaUNBQUMsVUFBSyxXQUFVLGdIQUE4Ryx5QkFBOUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSUE7QUFBQSxZQUNBLHVCQUFDLFFBQUcsV0FBVSxvQ0FDWCxjQUFJWixLQUFLZCxLQUFLMkIsVUFBVSxFQUFFWixtQkFBbUIsS0FEaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsUUFBRyxXQUFVLGFBQ1hmLGVBQUs0QixnQkFDSjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVMsTUFBTXRCLG1CQUFtQk4sS0FBSzRCLGFBQWM7QUFBQSxnQkFDckQsV0FBVTtBQUFBLGdCQUErSDtBQUFBO0FBQUEsY0FGM0k7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0EsSUFFQSx1QkFBQyxVQUFLLFdBQVUsMEJBQXlCLDJCQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRCxLQVR4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVdBO0FBQUEsZUEzQk81QixLQUFLQyxlQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBNEJBO0FBQUEsUUFDRCxLQS9CSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0NBO0FBQUEsV0ExQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTJDQSxLQTVDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNkNBO0FBQUEsU0FwREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXNEQTtBQUFBLElBR0EsdUJBQUMsYUFBUSxXQUFVLGtCQUNqQjtBQUFBLDZCQUFDLFFBQUcsV0FBVSxvQ0FBbUMsaUNBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0U7QUFBQSxNQUNqRTFCLGdCQUFnQjhDLFdBQVcsSUFDMUIsdUJBQUMsU0FBSSxXQUFVLGdHQUE4RiwwREFBN0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBLElBRUEsdUJBQUMsU0FBSSxXQUFVLHlFQUNiLGlDQUFDLFdBQU0sV0FBVSwwREFDZjtBQUFBLCtCQUFDLFdBQU0sV0FBVSw2RUFDZixpQ0FBQyxRQUNDO0FBQUEsaUNBQUMsUUFBRyxXQUFVLGFBQVksd0JBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtDO0FBQUEsVUFDbEMsdUJBQUMsUUFBRyxXQUFVLGFBQVksc0JBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdDO0FBQUEsVUFDaEMsdUJBQUMsUUFBRyxXQUFVLGFBQVksb0JBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThCO0FBQUEsYUFIaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBLEtBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BO0FBQUEsUUFDQSx1QkFBQyxXQUFNLFdBQVUsNENBQ2Q5QywwQkFBZ0JzRCxNQUFNLEdBQUcsRUFBRSxFQUFFOUI7QUFBQUEsVUFBSSxDQUFDK0IsUUFDakMsdUJBQUMsUUFBZ0IsV0FBVSx3QkFDekI7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsNkRBQ1hBLGNBQUlDLFlBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsUUFBRyxXQUFVLGFBQ1hELGNBQUlFLGFBQ0gsdUJBQUMsVUFBSyxXQUFVLCtIQUE2SCx5QkFBN0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQSxJQUVBLHVCQUFDLFVBQUssV0FBVSw0SEFBMEgsNEJBQTFJO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUEsS0FSSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVVBO0FBQUEsWUFDQSx1QkFBQyxRQUFHLFdBQVUsb0NBQ1gsY0FBSWxCLEtBQUtnQixJQUFJRyxZQUFZLEVBQUVDLGVBQWUsS0FEN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBakJPSixJQUFJSyxJQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBa0JBO0FBQUEsUUFDRCxLQXJCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBc0JBO0FBQUEsV0E5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQStCQSxLQWhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBaUNBO0FBQUEsU0F4Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBDQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLG1HQUNiO0FBQUEsNkJBQUMsUUFBRyxXQUFVLHlDQUF3QyxrQ0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3RTtBQUFBLE1BQ3hFLHVCQUFDLE9BQUUsV0FBVSwrQkFBNkIsK0ZBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFNBQVMsTUFBTW5FLFNBQVMsV0FBVztBQUFBLFVBQ25DLFdBQVU7QUFBQSxVQUE4RztBQUFBO0FBQUEsUUFGMUg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS0E7QUFBQSxTQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FXQTtBQUFBLElBR0NhLGVBQ0MsdUJBQUMsU0FBSSxXQUFVLDJGQUNiLGlDQUFDLFNBQUksV0FBVSx5R0FDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxvRUFDYjtBQUFBLCtCQUFDLFFBQUcsV0FBVSw0REFDWjtBQUFBLGlDQUFDLFVBQUssa0JBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBUTtBQUFBLFVBQU87QUFBQSxhQURqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTLE1BQU1DLGVBQWUsS0FBSztBQUFBLFlBQ25DLFdBQVU7QUFBQSxZQUEyRDtBQUFBO0FBQUEsVUFGdkU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0E7QUFBQSxXQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLHlDQUNaQyx5QkFDQyx1QkFBQyxTQUFJLFdBQVUsMENBQ2IsaUNBQUMsV0FBUSxPQUFNLHdDQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUQsS0FEckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBLElBQ0VFLHFCQUNGLHVCQUFDLFNBQUksV0FBVSxhQUViO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHdGQUNiO0FBQUEsaUNBQUMsU0FDQztBQUFBLG1DQUFDLFVBQUssV0FBVSx1RUFBc0Usa0NBQXRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdHO0FBQUEsWUFDeEcsdUJBQUMsU0FBSSxXQUFVLHNDQUNiO0FBQUEscUNBQUMsVUFBSyxXQUFXLDJCQUNmQSxtQkFBbUJtRCxlQUFlQyxZQUFZcEQsbUJBQW1CbUQsY0FBY0MsWUFBWSxLQUN2RixtQkFDQXBELG1CQUFtQm1ELGVBQWVDLFlBQVlwRCxtQkFBbUJtRCxjQUFjQyxZQUFZLEtBQzNGLG9CQUNBLGNBQWMsSUFFakJwRCw2QkFBbUJtRCxlQUFlQyxZQUFZLEtBUGpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBUUE7QUFBQSxjQUNBLHVCQUFDLFVBQUssV0FBVSx3Q0FBdUMsb0JBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTJEO0FBQUEsaUJBVjdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBV0E7QUFBQSxlQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBY0E7QUFBQSxVQUNBLHVCQUFDLFNBQ0MsaUNBQUMsVUFBSyxXQUFVLDRHQUEwRywyQkFBMUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUE7QUFBQSxhQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBcUJBO0FBQUEsUUFHQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsUUFBRyxXQUFVLGtFQUFpRSx5QkFBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0Y7QUFBQSxVQUN4Rix1QkFBQyxPQUFFLFdBQVUsOERBQ1ZwRCw2QkFBbUJtRCxlQUFlRSxhQUFhLHFDQURsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxRQUdBLHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsa0VBQWlFLDBCQUEvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RjtBQUFBLFVBQ3pGLHVCQUFDLE9BQUUsV0FBVSw4REFDVnJELDZCQUFtQm1ELGVBQWVHLGNBQWMsa0NBRG5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFFBR0EsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFFBQUcsV0FBVSxrRUFBaUUsK0JBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThGO0FBQUEsVUFDOUYsdUJBQUMsT0FBRSxXQUFVLDhEQUNWdEQsNkJBQW1CbUQsZUFBZUksbUJBQW1CLDBCQUR4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxXQS9DRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0RBLElBRUEsdUJBQUMsU0FBSSxXQUFVLGtEQUFnRCwwQ0FBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBLEtBMURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE0REE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxtREFDYjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsU0FBUyxNQUFNMUQsZUFBZSxLQUFLO0FBQUEsVUFDbkMsV0FBVTtBQUFBLFVBQWtJO0FBQUE7QUFBQSxRQUY5STtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFLQSxLQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQTtBQUFBLFNBbEZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FtRkEsS0FwRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXFGQTtBQUFBLE9BcFZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzVkE7QUFFSjtBQUFDZixHQXRidUJELG9CQUFrQjtBQUFBLFVBQ3ZCWCxXQUFXO0FBQUE7QUFBQSxLQUROVztBQUFrQixJQUFBMkU7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJ1c2VOYXZpZ2F0ZSIsInRvYXN0IiwiYXBwcm92ZUNhbmRpZGF0ZUludml0YXRpb24iLCJnZXRDYW5kaWRhdGVJbnZpdGF0aW9ucyIsImdldFByb2dyZXNzIiwiZ2V0SGlzdG9yeSIsImdldFN1Ym1pc3Npb24iLCJjbGVhclRva2VuIiwiQmFkZ2UiLCJCdXR0b24iLCJTcGlubmVyIiwiQ2FuZGlkYXRlRGFzaGJvYXJkIiwiX3MiLCJuYXZpZ2F0ZSIsImludml0YXRpb25zIiwic2V0SW52aXRhdGlvbnMiLCJzb2x2ZWRDb3VudCIsInNldFNvbHZlZENvdW50IiwibGFzdEFjdGl2ZSIsInNldExhc3RBY3RpdmUiLCJwcmFjdGljZUhpc3RvcnkiLCJzZXRQcmFjdGljZUhpc3RvcnkiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsImFwcHJvdmluZ0lkIiwic2V0QXBwcm92aW5nSWQiLCJpc01vZGFsT3BlbiIsInNldElzTW9kYWxPcGVuIiwibW9kYWxMb2FkaW5nIiwic2V0TW9kYWxMb2FkaW5nIiwic2VsZWN0ZWRTdWJtaXNzaW9uIiwic2V0U2VsZWN0ZWRTdWJtaXNzaW9uIiwiZmV0Y2hEYXNoYm9hcmREYXRhIiwiaW52RGF0YSIsInByb2dyZXNzRGF0YSIsInRvdGFsX3NvbHZlZCIsImxhc3RfYWN0aXZlIiwiaGlzdG9yeURhdGEiLCJlcnJvciIsImhhbmRsZUFwcHJvdmUiLCJpbnZpdGF0aW9uSWQiLCJyZXMiLCJzdWNjZXNzIiwicHJldiIsIm1hcCIsIml0ZW0iLCJpbnZpdGF0aW9uX2lkIiwic3RhdHVzIiwidG9rZW4iLCJ0ZXN0X3VybCIsImhhbmRsZUxvZ291dCIsImhhbmRsZVZpZXdBSVJldmlldyIsInN1Ym1pc3Npb25JZCIsInN1YkRhdGEiLCJlcnIiLCJwZW5kaW5nTGlzdCIsImZpbHRlciIsImFjdGl2ZUxpc3QiLCJjb21wbGV0ZWRMaXN0IiwiRGF0ZSIsInRvTG9jYWxlRGF0ZVN0cmluZyIsInllYXIiLCJtb250aCIsImRheSIsImhvdXIiLCJtaW51dGUiLCJsZW5ndGgiLCJ0aXRsZSIsImRlc2NyaXB0aW9uIiwiZGlmZmljdWx0eSIsInRpbWVfbGltaXRfbWlucyIsInNjb3JlIiwiZXhwaXJlc19hdCIsInN1Ym1pc3Npb25faWQiLCJzbGljZSIsImF0dCIsImxhbmd1YWdlIiwiaXNfY29ycmVjdCIsImF0dGVtcHRlZF9hdCIsInRvTG9jYWxlU3RyaW5nIiwiaWQiLCJhaV9ldmFsdWF0aW9uIiwiYWlfc2NvcmUiLCJzdHJlbmd0aHMiLCJ3ZWFrbmVzc2VzIiwicmVjb21tZW5kYXRpb25zIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQ2FuZGlkYXRlRGFzaGJvYXJkLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XG5pbXBvcnQgdG9hc3QgZnJvbSBcInJlYWN0LWhvdC10b2FzdFwiO1xuaW1wb3J0IHsgYXBwcm92ZUNhbmRpZGF0ZUludml0YXRpb24sIGdldENhbmRpZGF0ZUludml0YXRpb25zLCB0eXBlIENhbmRpZGF0ZUludml0YXRpb24gfSBmcm9tIFwiLi4vYXBpL2Fzc2Vzc21lbnRzXCI7XG5pbXBvcnQgeyBnZXRQcm9ncmVzcywgZ2V0SGlzdG9yeSwgdHlwZSBQcmFjdGljZUF0dGVtcHRSZWNvcmQgfSBmcm9tIFwiLi4vYXBpL3ByYWN0aWNlXCI7XG5pbXBvcnQgeyBnZXRTdWJtaXNzaW9uIH0gZnJvbSBcIi4uL2FwaS9zdWJtaXNzaW9uc1wiO1xuaW1wb3J0IHsgY2xlYXJUb2tlbiB9IGZyb20gXCIuLi9hcGkvYXV0aFwiO1xuaW1wb3J0IEJhZGdlIGZyb20gXCIuLi9jb21wb25lbnRzL3VpL0JhZGdlXCI7XG5pbXBvcnQgQnV0dG9uIGZyb20gXCIuLi9jb21wb25lbnRzL3VpL0J1dHRvblwiO1xuaW1wb3J0IFNwaW5uZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvdWkvU3Bpbm5lclwiO1xuXG50eXBlIFN1Ym1pc3Npb25EZXRhaWxzID0ge1xuICBpZDogc3RyaW5nO1xuICBzY29yZTogbnVtYmVyIHwgbnVsbDtcbiAgYWlfZXZhbHVhdGlvbj86IHtcbiAgICBzdHJlbmd0aHM6IHN0cmluZztcbiAgICB3ZWFrbmVzc2VzOiBzdHJpbmc7XG4gICAgcmVjb21tZW5kYXRpb25zOiBzdHJpbmc7XG4gICAgYWlfc2NvcmU6IG51bWJlcjtcbiAgfSB8IG51bGw7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBDYW5kaWRhdGVEYXNoYm9hcmQoKSB7XG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgY29uc3QgW2ludml0YXRpb25zLCBzZXRJbnZpdGF0aW9uc10gPSB1c2VTdGF0ZTxDYW5kaWRhdGVJbnZpdGF0aW9uW10+KFtdKTtcbiAgY29uc3QgW3NvbHZlZENvdW50LCBzZXRTb2x2ZWRDb3VudF0gPSB1c2VTdGF0ZSgwKTtcbiAgY29uc3QgW2xhc3RBY3RpdmUsIHNldExhc3RBY3RpdmVdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtwcmFjdGljZUhpc3RvcnksIHNldFByYWN0aWNlSGlzdG9yeV0gPSB1c2VTdGF0ZTxQcmFjdGljZUF0dGVtcHRSZWNvcmRbXT4oW10pO1xuICBcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSk7XG4gIGNvbnN0IFthcHByb3ZpbmdJZCwgc2V0QXBwcm92aW5nSWRdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG5cbiAgLy8gTW9kYWwgU3RhdGVzIGZvciBBSSBSZXZpZXdcbiAgY29uc3QgW2lzTW9kYWxPcGVuLCBzZXRJc01vZGFsT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFttb2RhbExvYWRpbmcsIHNldE1vZGFsTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtzZWxlY3RlZFN1Ym1pc3Npb24sIHNldFNlbGVjdGVkU3VibWlzc2lvbl0gPSB1c2VTdGF0ZTxTdWJtaXNzaW9uRGV0YWlscyB8IG51bGw+KG51bGwpO1xuXG4gIGNvbnN0IGZldGNoRGFzaGJvYXJkRGF0YSA9IGFzeW5jICgpID0+IHtcbiAgICB0cnkge1xuICAgICAgc2V0TG9hZGluZyh0cnVlKTtcbiAgICAgIC8vIEZldGNoIGludml0YXRpb25zXG4gICAgICBjb25zdCBpbnZEYXRhID0gYXdhaXQgZ2V0Q2FuZGlkYXRlSW52aXRhdGlvbnMoKTtcbiAgICAgIHNldEludml0YXRpb25zKGludkRhdGEpO1xuXG4gICAgICAvLyBGZXRjaCBwcmFjdGljZSBwcm9ncmVzc1xuICAgICAgY29uc3QgcHJvZ3Jlc3NEYXRhID0gYXdhaXQgZ2V0UHJvZ3Jlc3MoKTtcbiAgICAgIHNldFNvbHZlZENvdW50KHByb2dyZXNzRGF0YS50b3RhbF9zb2x2ZWQpO1xuICAgICAgc2V0TGFzdEFjdGl2ZShwcm9ncmVzc0RhdGEubGFzdF9hY3RpdmUpO1xuXG4gICAgICAvLyBGZXRjaCBwcmFjdGljZSBoaXN0b3J5XG4gICAgICBjb25zdCBoaXN0b3J5RGF0YSA9IGF3YWl0IGdldEhpc3RvcnkoKTtcbiAgICAgIHNldFByYWN0aWNlSGlzdG9yeShoaXN0b3J5RGF0YSk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIHRvYXN0LmVycm9yKFwiVW5hYmxlIHRvIGxvYWQgZGFzaGJvYXJkIGRhdGEuXCIpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcbiAgICB9XG4gIH07XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICB2b2lkIGZldGNoRGFzaGJvYXJkRGF0YSgpO1xuICB9LCBbXSk7XG5cbiAgY29uc3QgaGFuZGxlQXBwcm92ZSA9IGFzeW5jIChpbnZpdGF0aW9uSWQ6IHN0cmluZykgPT4ge1xuICAgIHRyeSB7XG4gICAgICBzZXRBcHByb3ZpbmdJZChpbnZpdGF0aW9uSWQpO1xuICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBwcm92ZUNhbmRpZGF0ZUludml0YXRpb24oaW52aXRhdGlvbklkKTtcbiAgICAgIHRvYXN0LnN1Y2Nlc3MoXCJBc3Nlc3NtZW50IGFwcHJvdmVkISBZb3VyIHRlc3QgbGluayBoYXMgYmVlbiBnZW5lcmF0ZWQuXCIpO1xuICAgICAgc2V0SW52aXRhdGlvbnMoKHByZXYpID0+XG4gICAgICAgIHByZXYubWFwKChpdGVtKSA9PlxuICAgICAgICAgIGl0ZW0uaW52aXRhdGlvbl9pZCA9PT0gaW52aXRhdGlvbklkXG4gICAgICAgICAgICA/IHsgLi4uaXRlbSwgc3RhdHVzOiBcImFjdGl2ZVwiLCB0b2tlbjogcmVzLnRva2VuLCB0ZXN0X3VybDogcmVzLnRlc3RfdXJsIH1cbiAgICAgICAgICAgIDogaXRlbVxuICAgICAgICApXG4gICAgICApO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICB0b2FzdC5lcnJvcihcIkZhaWxlZCB0byBhcHByb3ZlIGFzc2Vzc21lbnQuXCIpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRBcHByb3ZpbmdJZChudWxsKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlTG9nb3V0ID0gKCkgPT4ge1xuICAgIGNsZWFyVG9rZW4oKTtcbiAgICBuYXZpZ2F0ZShcIi9hdXRoXCIpO1xuICAgIHRvYXN0LnN1Y2Nlc3MoXCJMb2dnZWQgb3V0IHN1Y2Nlc3NmdWxseS5cIik7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlVmlld0FJUmV2aWV3ID0gYXN5bmMgKHN1Ym1pc3Npb25JZDogc3RyaW5nKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIHNldElzTW9kYWxPcGVuKHRydWUpO1xuICAgICAgc2V0TW9kYWxMb2FkaW5nKHRydWUpO1xuICAgICAgc2V0U2VsZWN0ZWRTdWJtaXNzaW9uKG51bGwpO1xuICAgICAgY29uc3Qgc3ViRGF0YSA9IGF3YWl0IGdldFN1Ym1pc3Npb24oc3VibWlzc2lvbklkKTtcbiAgICAgIHNldFNlbGVjdGVkU3VibWlzc2lvbihzdWJEYXRhKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHRvYXN0LmVycm9yKFwiRmFpbGVkIHRvIGxvYWQgQUkgZXZhbHVhdGlvbiBkZXRhaWxzLlwiKTtcbiAgICAgIHNldElzTW9kYWxPcGVuKGZhbHNlKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0TW9kYWxMb2FkaW5nKGZhbHNlKTtcbiAgICB9XG4gIH07XG5cbiAgaWYgKGxvYWRpbmcpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG1pbi1oLVs2MHZoXSBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctd2hpdGVcIj5cbiAgICAgICAgPFNwaW5uZXIgbGFiZWw9XCJMb2FkaW5nIHdvcmtzcGFjZSBkYXRhLi4uXCIgLz5cbiAgICAgIDwvZGl2PlxuICAgICk7XG4gIH1cblxuICBjb25zdCBwZW5kaW5nTGlzdCA9IGludml0YXRpb25zLmZpbHRlcigoaXRlbSkgPT4gaXRlbS5zdGF0dXMgPT09IFwicGVuZGluZ1wiKTtcbiAgY29uc3QgYWN0aXZlTGlzdCA9IGludml0YXRpb25zLmZpbHRlcigoaXRlbSkgPT4gaXRlbS5zdGF0dXMgPT09IFwiYWN0aXZlXCIpO1xuICBjb25zdCBjb21wbGV0ZWRMaXN0ID0gaW52aXRhdGlvbnMuZmlsdGVyKChpdGVtKSA9PiBpdGVtLnN0YXR1cyA9PT0gXCJjb21wbGV0ZWRcIik7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIG1pbi1oLXNjcmVlbiB0ZXh0LXNsYXRlLTgwMCBwLTYgbWF4LXctNXhsIG14LWF1dG8gc3BhY2UteS04IHNlbGVjdC1ub25lXCI+XG4gICAgICB7LyogVG9wIEJhciAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDAgcGItNCBtYi02XCI+XG4gICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDBcIj5CaXRMYWJzIOKAlCBDYW5kaWRhdGUgRGFzaGJvYXJkPC9oMj5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUxvZ291dH1cbiAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkIGJvcmRlciBib3JkZXItc2xhdGUtMzUwIGJnLXdoaXRlIGhvdmVyOmJnLXNsYXRlLTUwIHRleHQtc2xhdGUtNzAwIHB4LTQgcHktMS41IHRleHQtc20gZm9udC1zZW1pYm9sZCBzaGFkb3ctc20gdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICA+XG4gICAgICAgICAgTG9nb3V0XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBTdGF0cyBSb3cgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ2FwLTYgbWQ6Z3JpZC1jb2xzLTNcIj5cbiAgICAgICAgey8qIENhcmQgMTogUHJvYmxlbXMgU29sdmVkICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgYmctc2xhdGUtNTAgcC02IHNoYWRvdy1zbSBmbGV4IGZsZXgtY29sIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtNTAwIGJsb2NrIG1iLTFcIj5cbiAgICAgICAgICAgICAgUHJvYmxlbXMgU29sdmVkXG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTR4bCBmb250LWV4dHJhYm9sZCB0ZXh0LWJsdWUtNjAwXCI+e3NvbHZlZENvdW50fTwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIG10LTIgYmxvY2tcIj5LZWVwIGNvZGluZyB0byBsZXZlbCB1cCE8L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBDYXJkIDI6IExhc3QgQWN0aXZlICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgYmctc2xhdGUtNTAgcC02IHNoYWRvdy1zbSBmbGV4IGZsZXgtY29sIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtNTAwIGJsb2NrIG1iLTFcIj5cbiAgICAgICAgICAgICAgTGFzdCBBY3RpdmVcbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIGJsb2NrXCI+XG4gICAgICAgICAgICAgIHtsYXN0QWN0aXZlID8gbmV3IERhdGUobGFzdEFjdGl2ZSkudG9Mb2NhbGVEYXRlU3RyaW5nKFwiZW4tVVNcIiwge1xuICAgICAgICAgICAgICAgIHllYXI6IFwibnVtZXJpY1wiLFxuICAgICAgICAgICAgICAgIG1vbnRoOiBcInNob3J0XCIsXG4gICAgICAgICAgICAgICAgZGF5OiBcIm51bWVyaWNcIixcbiAgICAgICAgICAgICAgICBob3VyOiBcIjItZGlnaXRcIixcbiAgICAgICAgICAgICAgICBtaW51dGU6IFwiMi1kaWdpdFwiXG4gICAgICAgICAgICAgIH0pIDogXCJOL0FcIn1cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIG10LTIgYmxvY2tcIj5Zb3VyIGxhc3QgcHJhY3RpY2Ugc2Vzc2lvbjwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIENhcmQgMzogUHJhY3RpY2UgQXJlbmEgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBiZy1zbGF0ZS01MCBwLTYgc2hhZG93LXNtIGZsZXggZmxleC1jb2wganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS01MDAgYmxvY2sgbWItMVwiPlxuICAgICAgICAgICAgICBQcmFjdGljZSBBcmVuYVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXNsYXRlLTYwMCBibG9ja1wiPlNoYXJwZW4geW91ciBjb2RlIHNraWxscyB3aXRoIEFJIGZlZWRiYWNrLjwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZShcIi9wcmFjdGljZVwiKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBtdC00IGJnLWJsdWUtNjAwIGhvdmVyOmJnLWJsdWUtNzAwIHRleHQtd2hpdGUgcm91bmRlZCBweS0yIHRleHQtc20gZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWNvbG9ycyBzaGFkb3ctc21cIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIEdvIFByYWN0aWNlIOKGklxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogUGVuZGluZyBBcHByb3ZhbCBTZWN0aW9uICovfVxuICAgICAge3BlbmRpbmdMaXN0Lmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJzcGFjZS15LTQgcHQtNFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1hbWJlci04MDBcIj5cbiAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwiaC01IHctNSB0ZXh0LWFtYmVyLTUwMFwiIGZpbGw9XCJub25lXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIHN0cm9rZVdpZHRoPXsyfSBzdHJva2U9XCJjdXJyZW50Q29sb3JcIj5cbiAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIGQ9XCJNMTIgOXYzLjc1bTktLjc1YTkgOSAwIDEgMS0xOCAwIDkgOSAwIDAgMSAxOCAwWm0tOSAzLjc1aC4wMDh2LjAwOEgxMnYtLjAwOFpcIiAvPlxuICAgICAgICAgICAgPC9zdmc+XG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDBcIj5cbiAgICAgICAgICAgICAgUGVuZGluZyBBc3Nlc3NtZW50cyAoe3BlbmRpbmdMaXN0Lmxlbmd0aH0pIOKAlCBBY3Rpb24gUmVxdWlyZWRcbiAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ2FwLTRcIj5cbiAgICAgICAgICAgIHtwZW5kaW5nTGlzdC5tYXAoKGl0ZW0pID0+IChcbiAgICAgICAgICAgICAgPGRpdiBrZXk9e2l0ZW0uaW52aXRhdGlvbl9pZH0gY2xhc3NOYW1lPVwicm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWFtYmVyLTIwMCBiZy1hbWJlci01MC82MCBwLTUgc2hhZG93LXNtXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1zdGFydCBqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDBcIj57aXRlbS50aXRsZX08L2g0PlxuICAgICAgICAgICAgICAgICAgICAgIDxCYWRnZSBzdGF0dXM9XCJkcmFmdFwiPnBlbmRpbmcgYXBwcm92YWw8L0JhZGdlPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMS41IHRleHQtc20gdGV4dC1zbGF0ZS03MDBcIj57aXRlbS5kZXNjcmlwdGlvbn08L3A+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMyBmbGV4IGZsZXgtd3JhcCBnYXAtNCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+RGlmZmljdWx0eTogPHN0cm9uZyBjbGFzc05hbWU9XCJjYXBpdGFsaXplIHRleHQtc2xhdGUtODAwXCI+e2l0ZW0uZGlmZmljdWx0eX08L3N0cm9uZz48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+VGltZSBMaW1pdDogPHN0cm9uZyBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTgwMFwiPntpdGVtLnRpbWVfbGltaXRfbWluc30gbWluczwvc3Ryb25nPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2FwcHJvdmluZ0lkID09PSBpdGVtLmludml0YXRpb25faWR9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUFwcHJvdmUoaXRlbS5pbnZpdGF0aW9uX2lkKX1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAge2FwcHJvdmluZ0lkID09PSBpdGVtLmludml0YXRpb25faWQgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgPFNwaW5uZXIgbGFiZWw9XCJBcHByb3ZpbmdcIiAvPlxuICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgIFwiQXBwcm92ZSBBc3Nlc3NtZW50ICYgR2VuZXJhdGUgTGlua1wiXG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9zZWN0aW9uPlxuICAgICAgKX1cblxuICAgICAgey8qIEFjdGl2ZSBBc3Nlc3NtZW50cyBTZWN0aW9uICovfVxuICAgICAge2FjdGl2ZUxpc3QubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInNwYWNlLXktNCBwdC00XCI+XG4gICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwXCI+QWN0aXZlIEFzc2Vzc21lbnRzPC9oMz5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ2FwLTRcIj5cbiAgICAgICAgICAgIHthY3RpdmVMaXN0Lm1hcCgoaXRlbSkgPT4gKFxuICAgICAgICAgICAgICA8ZGl2IGtleT17aXRlbS5pbnZpdGF0aW9uX2lkfSBjbGFzc05hbWU9XCJyb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZW1lcmFsZC0yMDAgYmctZW1lcmFsZC01MC81MCBwLTUgc2hhZG93LXNtXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00XCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwXCI+e2l0ZW0udGl0bGV9PC9oND5cbiAgICAgICAgICAgICAgICAgICAgICA8QmFkZ2Ugc3RhdHVzPVwiYWN0aXZlXCI+cmVhZHkgdG8gdGFrZTwvQmFkZ2U+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1zbGF0ZS03MDBcIj57aXRlbS5kZXNjcmlwdGlvbn08L3A+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMyBmbGV4IGZsZXgtd3JhcCBnYXAtNCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+RGlmZmljdWx0eTogPHN0cm9uZyBjbGFzc05hbWU9XCJjYXBpdGFsaXplIHRleHQtc2xhdGUtODAwXCI+e2l0ZW0uZGlmZmljdWx0eX08L3N0cm9uZz48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+VGltZSBMaW1pdDogPHN0cm9uZyBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTgwMFwiPntpdGVtLnRpbWVfbGltaXRfbWluc30gbWluczwvc3Ryb25nPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgPEJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoYC9hc3Nlc3NtZW50LyR7aXRlbS50b2tlbn1gKX0+XG4gICAgICAgICAgICAgICAgICAgIFN0YXJ0IEFzc2Vzc21lbnQg4oaSXG4gICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9zZWN0aW9uPlxuICAgICAgKX1cblxuICAgICAgey8qIEFTU0VTU01FTlQgSElTVE9SWSAoQ29tcGxldGVkIEFzc2Vzc21lbnRzKSAqL31cbiAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInNwYWNlLXktNCBwdC00XCI+XG4gICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMFwiPk15IEFzc2Vzc21lbnRzPC9oMz5cbiAgICAgICAge2NvbXBsZXRlZExpc3QubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBiZy1zbGF0ZS01MCBwLTYgdGV4dC1jZW50ZXIgdGV4dC1zbSB0ZXh0LXNsYXRlLTUwMCBpdGFsaWNcIj5cbiAgICAgICAgICAgIE5vIGFzc2Vzc21lbnRzIHRha2VuIHlldC5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKSA6IChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LXgtYXV0byByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGJnLXdoaXRlIHNoYWRvdy1zbVwiPlxuICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cIm1pbi13LWZ1bGwgZGl2aWRlLXkgZGl2aWRlLXNsYXRlLTIwMCB0ZXh0LWxlZnQgdGV4dC1zbVwiPlxuICAgICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwiYmctc2xhdGUtNTAgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCB0ZXh0LXhzIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxuICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC02IHB5LTNcIj5Bc3Nlc3NtZW50PC90aD5cbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC02IHB5LTNcIj5TY29yZTwvdGg+XG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNiBweS0zXCI+U3RhdHVzPC90aD5cbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC02IHB5LTNcIj5EYXRlPC90aD5cbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC02IHB5LTNcIj5BSSBSZXZpZXc8L3RoPlxuICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtc2xhdGUtMjAwIHRleHQtc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgICAge2NvbXBsZXRlZExpc3QubWFwKChpdGVtKSA9PiAoXG4gICAgICAgICAgICAgICAgICA8dHIga2V5PXtpdGVtLmludml0YXRpb25faWR9IGNsYXNzTmFtZT1cImhvdmVyOmJnLXNsYXRlLTUwLzUwXCI+XG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC02IHB5LTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS05MDBcIj57aXRlbS50aXRsZX08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgY2FwaXRhbGl6ZVwiPntpdGVtLmRpZmZpY3VsdHl9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC02IHB5LTQgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAge2l0ZW0uc2NvcmUgIT09IG51bGwgPyBgJHtpdGVtLnNjb3JlfSAvIDEwMGAgOiBcIlBlbmRpbmdcIn1cbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTYgcHktNFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IHJvdW5kZWQtZnVsbCBiZy1zbGF0ZS0xMDAgcHgtMiBweS0wLjUgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgU3VibWl0dGVkXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNiBweS00IHRleHQteHMgdGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7bmV3IERhdGUoaXRlbS5leHBpcmVzX2F0KS50b0xvY2FsZURhdGVTdHJpbmcoKX1cbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTYgcHktNFwiPlxuICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnN1Ym1pc3Npb25faWQgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVZpZXdBSVJldmlldyhpdGVtLnN1Ym1pc3Npb25faWQhKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctYmx1ZS01MCBob3ZlcjpiZy1ibHVlLTEwMCB0ZXh0LWJsdWUtNjAwIHJvdW5kZWQgcHgtMyBweS0xLjUgdGV4dC14cyBmb250LXNlbWlib2xkIHRyYW5zaXRpb24tY29sb3JzIGJvcmRlciBib3JkZXItYmx1ZS0yMDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICBWaWV3IFJldmlld1xuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDBcIj5VbmF2YWlsYWJsZTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG4gICAgICA8L3NlY3Rpb24+XG5cbiAgICAgIHsvKiBSRUNFTlQgQUNUSVZJVFkgKFByYWN0aWNlIEFjdGl2aXR5KSAqL31cbiAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInNwYWNlLXktNCBwdC00XCI+XG4gICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMFwiPlByYWN0aWNlIEFjdGl2aXR5PC9oMz5cbiAgICAgICAge3ByYWN0aWNlSGlzdG9yeS5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGJnLXNsYXRlLTUwIHAtNiB0ZXh0LWNlbnRlciB0ZXh0LXNtIHRleHQtc2xhdGUtNTAwIGl0YWxpY1wiPlxuICAgICAgICAgICAgU3RhcnQgcHJhY3RpY2luZyB0byBzZWUgeW91ciBoaXN0b3J5IGhlcmUuXG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICkgOiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy14LWF1dG8gcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBiZy13aGl0ZSBzaGFkb3ctc21cIj5cbiAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJtaW4tdy1mdWxsIGRpdmlkZS15IGRpdmlkZS1zbGF0ZS0yMDAgdGV4dC1sZWZ0IHRleHQtc21cIj5cbiAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLXNsYXRlLTUwIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgdGV4dC14cyB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cbiAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNiBweS0zXCI+TGFuZ3VhZ2U8L3RoPlxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTYgcHktM1wiPlJlc3VsdDwvdGg+XG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNiBweS0zXCI+RGF0ZTwvdGg+XG4gICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImRpdmlkZS15IGRpdmlkZS1zbGF0ZS0yMDAgdGV4dC1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgICB7cHJhY3RpY2VIaXN0b3J5LnNsaWNlKDAsIDIwKS5tYXAoKGF0dCkgPT4gKFxuICAgICAgICAgICAgICAgICAgPHRyIGtleT17YXR0LmlkfSBjbGFzc05hbWU9XCJob3ZlcjpiZy1zbGF0ZS01MC81MFwiPlxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNiBweS00IGZvbnQtbW9ubyBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTcwMCBjYXBpdGFsaXplXCI+XG4gICAgICAgICAgICAgICAgICAgICAge2F0dC5sYW5ndWFnZX1cbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTYgcHktNFwiPlxuICAgICAgICAgICAgICAgICAgICAgIHthdHQuaXNfY29ycmVjdCA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSByb3VuZGVkIGJnLWdyZWVuLTUwIGJvcmRlciBib3JkZXItZ3JlZW4tMjAwIHB4LTIgcHktMC41IHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyZWVuLTcwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICDinJMgQ29ycmVjdFxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgcm91bmRlZCBiZy1yb3NlLTUwIGJvcmRlciBib3JkZXItcm9zZS0yMDAgcHgtMiBweS0wLjUgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtcm9zZS03MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAg4pyXIE5lZWRzIFdvcmtcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNiBweS00IHRleHQteHMgdGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7bmV3IERhdGUoYXR0LmF0dGVtcHRlZF9hdCkudG9Mb2NhbGVTdHJpbmcoKX1cbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuICAgICAgPC9zZWN0aW9uPlxuXG4gICAgICB7LyogQm90dG9tIENUQSAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgYmctc2xhdGUtNTAgcC04IHRleHQtY2VudGVyIHNoYWRvdy1zbSBtYXgtdy14bCBteC1hdXRvIG10LTZcIj5cbiAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIG1iLTJcIj5SZWFkeSB0byBwcmFjdGljZT88L2g0PlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTYwMCB0ZXh0LXNtIG1iLTVcIj5cbiAgICAgICAgICBBY2Nlc3MgdGhlIG9wZW4gY29kaW5nIHBsYXlncm91bmQgYW5kIHRlc3QgeW91ciBjb2RlIGFnYWluc3Qgc2FuZGJveCBleGVjdXRpb24uXG4gICAgICAgIDwvcD5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKFwiL3ByYWN0aWNlXCIpfVxuICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWJsdWUtNjAwIGhvdmVyOmJnLWJsdWUtNzAwIHRleHQtd2hpdGUgcm91bmRlZCBweC02IHB5LTIgdGV4dC1zbSBmb250LXNlbWlib2xkIHRyYW5zaXRpb24tY29sb3JzIHNoYWRvdy1tZFwiXG4gICAgICAgID5cbiAgICAgICAgICBPcGVuIFByYWN0aWNlIEFyZW5hXG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBBSSBSRVZJRVcgTU9EQUwgKi99XG4gICAgICB7aXNNb2RhbE9wZW4gJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBiZy1zbGF0ZS05NTAvNTAgcC00IGFuaW1hdGUtZmFkZS1pblwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIG1heC13LTJ4bCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGJnLXdoaXRlIHAtNiBzaGFkb3cteGwgZmxleCBmbGV4LWNvbCBtYXgtaC1bOTB2aF1cIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDAgcGItM1wiPlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8c3Bhbj7wn6SWPC9zcGFuPiBBSSBFdmFsdWF0aW9uIFN1bW1hcnlcbiAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldElzTW9kYWxPcGVuKGZhbHNlKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXNsYXRlLTYwMCB0ZXh0LXNtIGZvbnQtYm9sZCBwLTFcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAg4pyVXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG92ZXJmbG93LXktYXV0byBweS00IHNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICB7bW9kYWxMb2FkaW5nID8gKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktMTIgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgIDxTcGlubmVyIGxhYmVsPVwiQUkgaXMgbG9hZGluZyBldmFsdWF0aW9uIGRldGFpbC4uLlwiIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICkgOiBzZWxlY3RlZFN1Ym1pc3Npb24gPyAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICAgIHsvKiBTY29yZSBiYW5uZXIgKi99XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwLTQgYmctc2xhdGUtNTAgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgYmxvY2tcIj5BSSBFdmFsdWF0ZWQgU2NvcmU8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWJhc2VsaW5lIGdhcC0wLjUgbXQtMC41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2B0ZXh0LTR4bCBmb250LWV4dHJhYm9sZCAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZFN1Ym1pc3Npb24uYWlfZXZhbHVhdGlvbj8uYWlfc2NvcmUgJiYgc2VsZWN0ZWRTdWJtaXNzaW9uLmFpX2V2YWx1YXRpb24uYWlfc2NvcmUgPj0gNzBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwidGV4dC1ncmVlbi02MDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogc2VsZWN0ZWRTdWJtaXNzaW9uLmFpX2V2YWx1YXRpb24/LmFpX3Njb3JlICYmIHNlbGVjdGVkU3VibWlzc2lvbi5haV9ldmFsdWF0aW9uLmFpX3Njb3JlID49IDQwXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcInRleHQteWVsbG93LTYwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcInRleHQtcmVkLTYwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICB9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZFN1Ym1pc3Npb24uYWlfZXZhbHVhdGlvbj8uYWlfc2NvcmUgPz8gMH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIHRleHQteHMgZm9udC1zZW1pYm9sZFwiPi8xMDA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IHJvdW5kZWQtZnVsbCBiZy1ibHVlLTUwIGJvcmRlciBib3JkZXItYmx1ZS0yMDAgcHgtMyBweS0xIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWJsdWUtNzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBSZXZpZXcgRG9uZVxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgey8qIFN0cmVuZ3RocyAqL31cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxoNSBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgbWItMVwiPlN0cmVuZ3RoczwvaDU+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNjAwIHRleHQtc20gbGVhZGluZy1yZWxheGVkIHdoaXRlc3BhY2UtcHJlLXdyYXBcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRTdWJtaXNzaW9uLmFpX2V2YWx1YXRpb24/LnN0cmVuZ3RocyB8fCBcIk5vIHNwZWNpZmljIGZlZWRiYWNrIGdlbmVyYXRlZC5cIn1cbiAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIHsvKiBXZWFrbmVzc2VzICovfVxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGg1IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBtYi0xXCI+V2Vha25lc3NlczwvaDU+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNjAwIHRleHQtc20gbGVhZGluZy1yZWxheGVkIHdoaXRlc3BhY2UtcHJlLXdyYXBcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRTdWJtaXNzaW9uLmFpX2V2YWx1YXRpb24/LndlYWtuZXNzZXMgfHwgXCJObyBjcml0aWNhbCBpc3N1ZXMgZGV0ZWN0ZWQuXCJ9XG4gICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICB7LyogUmVjb21tZW5kYXRpb25zICovfVxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGg1IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBtYi0xXCI+UmVjb21tZW5kYXRpb25zPC9oNT5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS02MDAgdGV4dC1zbSBsZWFkaW5nLXJlbGF4ZWQgd2hpdGVzcGFjZS1wcmUtd3JhcFwiPlxuICAgICAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZFN1Ym1pc3Npb24uYWlfZXZhbHVhdGlvbj8ucmVjb21tZW5kYXRpb25zIHx8IFwiQ29udGludWUgcHJhY3RpY2luZyFcIn1cbiAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciB0ZXh0LXNsYXRlLTUwMCBweS04IHRleHQtc20gaXRhbGljXCI+XG4gICAgICAgICAgICAgICAgICBDb3VsZCBub3QgbG9hZCBldmFsdWF0aW9uLlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTIwMCBwdC0zIGZsZXgganVzdGlmeS1lbmRcIj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldElzTW9kYWxPcGVuKGZhbHNlKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1zbGF0ZS0xMDAgaG92ZXI6Ymctc2xhdGUtMjAwIHRleHQtc2xhdGUtODAwIGZvbnQtc2VtaWJvbGQgcHgtNCBweS0yIHJvdW5kZWQgdGV4dC1zbSB0cmFuc2l0aW9uLWNvbG9ycyBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMFwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBDbG9zZVxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6IkM6L1VzZXJzL1lhc3dhbnRoIFJhaHVsL0Rvd25sb2Fkcy9CaXRMYWJzLUNvZGluZy1MYWIvZnJvbnRlbmQvc3JjL3JvdXRlcy9DYW5kaWRhdGVEYXNoYm9hcmQudHN4In0=