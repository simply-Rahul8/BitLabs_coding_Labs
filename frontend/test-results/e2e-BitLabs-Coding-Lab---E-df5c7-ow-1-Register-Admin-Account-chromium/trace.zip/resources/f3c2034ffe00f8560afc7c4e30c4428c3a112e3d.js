import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/RecruiterDashboard.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1cbb189e"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=1cbb189e"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=1cbb189e";
import toast from "/node_modules/.vite/deps/react-hot-toast.js?v=1cbb189e";
import { getAssessments, getResults, inviteCandidate } from "/src/api/assessments.ts";
import Badge from "/src/components/ui/Badge.tsx";
import Button from "/src/components/ui/Button.tsx";
import Spinner from "/src/components/ui/Spinner.tsx";
export default function RecruiterDashboard() {
  _s();
  const navigate = useNavigate();
  const [assessments, setAssessments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [resultsOpen, setResultsOpen] = useState(false);
  const [inviteOpen, setInviteOpen] = useState(false);
  const [selectedAssessment, setSelectedAssessment] = useState(null);
  const [results, setResults] = useState([]);
  const [resultsLoading, setResultsLoading] = useState(false);
  const [candidateEmail, setCandidateEmail] = useState("");
  const [expiresHours, setExpiresHours] = useState(48);
  const [inviteSubmitting, setInviteSubmitting] = useState(false);
  const [inviteLink, setInviteLink] = useState(null);
  const fetchAssessments = async () => {
    try {
      setLoading(true);
      const data = await getAssessments();
      setAssessments(data);
    } catch (error) {
      toast.error("Unable to load assessments.");
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    void fetchAssessments();
  }, []);
  const openResults = async (assessment) => {
    setSelectedAssessment(assessment);
    setResultsOpen(true);
    setResultsLoading(true);
    try {
      const data = await getResults(assessment.id);
      setResults(data);
    } catch (error) {
      toast.error("Unable to load candidate results.");
      setResults([]);
    } finally {
      setResultsLoading(false);
    }
  };
  const handleInvite = async () => {
    if (!selectedAssessment) return;
    if (!candidateEmail.trim()) {
      toast.error("Please enter a candidate email.");
      return;
    }
    try {
      setInviteSubmitting(true);
      const response = await inviteCandidate(selectedAssessment.id, {
        candidate_email: candidateEmail.trim(),
        expires_hours: expiresHours
      });
      const fullUrl = `http://localhost:5173/assessment/${response.token}`;
      setInviteLink(fullUrl);
      toast.success("Invitation created successfully.");
    } catch (error) {
      toast.error(error?.response?.data?.detail || "Failed to send invitation.");
    } finally {
      setInviteSubmitting(false);
    }
  };
  return /* @__PURE__ */ jsxDEV("section", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center justify-between gap-3", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-semibold text-slate-950", children: "BitLabs — Recruiter Dashboard" }, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
          lineNumber: 101,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-slate-600", children: "Review assessments, candidate results, and invitations." }, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
          lineNumber: 102,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
        lineNumber: 100,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { type: "button", onClick: () => navigate("/recruiter/assessments/new"), children: "New Assessment" }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
        lineNumber: 104,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
      lineNumber: 99,
      columnNumber: 7
    }, this),
    loading ? /* @__PURE__ */ jsxDEV("div", { className: "rounded-lg border border-slate-200 bg-white p-8 shadow-sm", children: /* @__PURE__ */ jsxDEV(Spinner, { label: "Loading assessments" }, void 0, false, {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
      lineNumber: 109,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
      lineNumber: 108,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm", children: /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full text-left text-sm text-slate-700", children: [
      /* @__PURE__ */ jsxDEV("thead", { className: "bg-slate-50 text-xs uppercase tracking-wide text-slate-600", children: /* @__PURE__ */ jsxDEV("tr", { children: [
        /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 font-semibold", children: "Title" }, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
          lineNumber: 117,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 font-semibold", children: "Difficulty" }, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
          lineNumber: 118,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 font-semibold", children: "Time Limit" }, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
          lineNumber: 119,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 font-semibold", children: "Languages" }, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
          lineNumber: 120,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 font-semibold", children: "Created" }, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
          lineNumber: 121,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 font-semibold", children: "Actions" }, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
          lineNumber: 122,
          columnNumber: 19
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
        lineNumber: 116,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
        lineNumber: 115,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("tbody", { children: assessments.map(
        (assessment) => /* @__PURE__ */ jsxDEV("tr", { className: "border-t border-slate-200", children: [
          /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-4 font-medium text-slate-900", children: assessment.title }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
            lineNumber: 128,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-4", children: /* @__PURE__ */ jsxDEV(Badge, { status: assessment.difficulty === "hard" ? "completed" : assessment.difficulty === "medium" ? "active" : "draft", children: assessment.difficulty }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
            lineNumber: 130,
            columnNumber: 23
          }, this) }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
            lineNumber: 129,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-4", children: [
            assessment.time_limit_mins,
            " min"
          ] }, void 0, true, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
            lineNumber: 132,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-4", children: assessment.language_support.join(", ") || "—" }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
            lineNumber: 133,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-4", children: new Date(assessment.created_at).toLocaleDateString() }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
            lineNumber: 134,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-4", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2", children: [
            /* @__PURE__ */ jsxDEV(Button, { type: "button", variant: "secondary", onClick: () => openResults(assessment), children: "View Results" }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
              lineNumber: 137,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                type: "button",
                variant: "secondary",
                onClick: () => {
                  setSelectedAssessment(assessment);
                  setInviteOpen(true);
                  setInviteLink(null);
                },
                children: "Invite Candidate"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
                lineNumber: 140,
                columnNumber: 25
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
            lineNumber: 136,
            columnNumber: 23
          }, this) }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
            lineNumber: 135,
            columnNumber: 21
          }, this)
        ] }, assessment.id, true, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
          lineNumber: 127,
          columnNumber: 15
        }, this)
      ) }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
        lineNumber: 125,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
      lineNumber: 114,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
      lineNumber: 113,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
      lineNumber: 112,
      columnNumber: 7
    }, this),
    resultsOpen && selectedAssessment && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-50 flex items-center justify-center bg-slate-900/30 p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "w-full max-w-3xl rounded-xl border border-slate-200 bg-white shadow-xl", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between border-b border-slate-200 px-5 py-4", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-slate-900", children: [
          selectedAssessment.title,
          " — Results"
        ] }, void 0, true, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
          lineNumber: 165,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { type: "button", variant: "secondary", onClick: () => setResultsOpen(false), children: "Close" }, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
          lineNumber: 166,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
        lineNumber: 164,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "max-h-[70vh] overflow-auto p-5", children: resultsLoading ? /* @__PURE__ */ jsxDEV(Spinner, { label: "Loading results" }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
        lineNumber: 170,
        columnNumber: 13
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "overflow-hidden rounded-lg border border-slate-200", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full text-left text-sm", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-slate-50 text-slate-600", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 font-semibold", children: "Candidate ID" }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
            lineNumber: 176,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 font-semibold", children: "Score" }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
            lineNumber: 177,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 font-semibold", children: "Status" }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
            lineNumber: 178,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 font-semibold", children: "Submitted At" }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
            lineNumber: 179,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
          lineNumber: 175,
          columnNumber: 23
        }, this) }, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
          lineNumber: 174,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { children: results.length === 0 ? /* @__PURE__ */ jsxDEV("tr", { children: /* @__PURE__ */ jsxDEV("td", { colSpan: 4, className: "px-3 py-4 text-center text-slate-500", children: "No candidate submissions yet." }, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
          lineNumber: 185,
          columnNumber: 27
        }, this) }, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
          lineNumber: 184,
          columnNumber: 19
        }, this) : results.map(
          (result, index) => /* @__PURE__ */ jsxDEV("tr", { className: "border-t border-slate-200", children: [
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-3 text-slate-800", children: result.candidate_email }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
              lineNumber: 190,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-3", children: result.score !== null && result.score !== void 0 ? `${result.score} / 100` : "Pending" }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
              lineNumber: 191,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-3", children: result.score !== null && result.score !== void 0 ? "Submitted" : "Pending" }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
              lineNumber: 192,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-3", children: result.submitted_at ? new Date(result.submitted_at).toLocaleString() : "Pending" }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
              lineNumber: 193,
              columnNumber: 29
            }, this)
          ] }, `${result.candidate_email}-${index}`, true, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
            lineNumber: 189,
            columnNumber: 19
          }, this)
        ) }, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
          lineNumber: 182,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
        lineNumber: 173,
        columnNumber: 19
      }, this) }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
        lineNumber: 172,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
        lineNumber: 168,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
      lineNumber: 163,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
      lineNumber: 162,
      columnNumber: 7
    }, this),
    inviteOpen && selectedAssessment && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-50 flex items-center justify-center bg-slate-900/30 p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "w-full max-w-lg rounded-xl border border-slate-200 bg-white p-5 shadow-xl", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-slate-900", children: "Invite Candidate" }, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
          lineNumber: 210,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { type: "button", variant: "secondary", onClick: () => setInviteOpen(false), children: "Close" }, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
          lineNumber: 211,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
        lineNumber: 209,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-4 space-y-4", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "mb-1 block text-sm font-medium text-slate-700", children: "Candidate email" }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
            lineNumber: 216,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              value: candidateEmail,
              onChange: (event) => setCandidateEmail(event.target.value),
              className: "w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-slate-900 outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-100",
              placeholder: "candidate@example.com"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
              lineNumber: 217,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
          lineNumber: 215,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "mb-1 block text-sm font-medium text-slate-700", children: "Expires in (hours)" }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
            lineNumber: 226,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "number",
              min: 1,
              value: expiresHours,
              onChange: (event) => setExpiresHours(Number(event.target.value || 48)),
              className: "w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-slate-900 outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-100"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
              lineNumber: 227,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
          lineNumber: 225,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { type: "button", className: "w-full", disabled: inviteSubmitting, onClick: handleInvite, children: inviteSubmitting ? /* @__PURE__ */ jsxDEV(Spinner, { label: "Creating invite" }, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
          lineNumber: 237,
          columnNumber: 37
        }, this) : "Send Invite" }, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
          lineNumber: 236,
          columnNumber: 15
        }, this),
        inviteLink && /* @__PURE__ */ jsxDEV("div", { className: "rounded-lg border border-emerald-200 bg-emerald-50 p-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "mb-2 text-sm font-medium text-emerald-800", children: "Invite URL" }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
            lineNumber: 242,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "break-all text-sm text-emerald-700", children: inviteLink }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
            lineNumber: 243,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mt-3", children: /* @__PURE__ */ jsxDEV(
            Button,
            {
              type: "button",
              variant: "secondary",
              className: "w-full",
              onClick: async () => {
                await navigator.clipboard.writeText(inviteLink);
                toast.success("Invite link copied.");
              },
              children: "Copy link"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
              lineNumber: 245,
              columnNumber: 21
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
            lineNumber: 244,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
          lineNumber: 241,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
        lineNumber: 214,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
      lineNumber: 208,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
      lineNumber: 207,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx",
    lineNumber: 98,
    columnNumber: 5
  }, this);
}
_s(RecruiterDashboard, "UO+5W6JXhW+3hpwHHdPZw5ngD1k=", false, function() {
  return [useNavigate];
});
_c = RecruiterDashboard;
var _c;
$RefreshReg$(_c, "RecruiterDashboard");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/RecruiterDashboard.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUZVOzs7Ozs7Ozs7Ozs7Ozs7OztBQWpGVixTQUFTQSxXQUFXQyxnQkFBZ0I7QUFDcEMsU0FBU0MsbUJBQW1CO0FBQzVCLE9BQU9DLFdBQVc7QUFDbEIsU0FBU0MsZ0JBQWdCQyxZQUFZQyx1QkFBOEM7QUFDbkYsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGFBQWE7QUFFcEIsd0JBQXdCQyxxQkFBcUI7QUFBQUMsS0FBQTtBQUMzQyxRQUFNQyxXQUFXVixZQUFZO0FBQzdCLFFBQU0sQ0FBQ1csYUFBYUMsY0FBYyxJQUFJYixTQUE2QixFQUFFO0FBQ3JFLFFBQU0sQ0FBQ2MsU0FBU0MsVUFBVSxJQUFJZixTQUFTLElBQUk7QUFDM0MsUUFBTSxDQUFDZ0IsYUFBYUMsY0FBYyxJQUFJakIsU0FBUyxLQUFLO0FBQ3BELFFBQU0sQ0FBQ2tCLFlBQVlDLGFBQWEsSUFBSW5CLFNBQVMsS0FBSztBQUNsRCxRQUFNLENBQUNvQixvQkFBb0JDLHFCQUFxQixJQUFJckIsU0FBa0MsSUFBSTtBQUMxRixRQUFNLENBQUNzQixTQUFTQyxVQUFVLElBQUl2QixTQUFpSCxFQUFFO0FBQ2pKLFFBQU0sQ0FBQ3dCLGdCQUFnQkMsaUJBQWlCLElBQUl6QixTQUFTLEtBQUs7QUFDMUQsUUFBTSxDQUFDMEIsZ0JBQWdCQyxpQkFBaUIsSUFBSTNCLFNBQVMsRUFBRTtBQUN2RCxRQUFNLENBQUM0QixjQUFjQyxlQUFlLElBQUk3QixTQUFTLEVBQUU7QUFDbkQsUUFBTSxDQUFDOEIsa0JBQWtCQyxtQkFBbUIsSUFBSS9CLFNBQVMsS0FBSztBQUM5RCxRQUFNLENBQUNnQyxZQUFZQyxhQUFhLElBQUlqQyxTQUF3QixJQUFJO0FBRWhFLFFBQU1rQyxtQkFBbUIsWUFBWTtBQUNuQyxRQUFJO0FBQ0ZuQixpQkFBVyxJQUFJO0FBQ2YsWUFBTW9CLE9BQU8sTUFBTWhDLGVBQWU7QUFDbENVLHFCQUFlc0IsSUFBSTtBQUFBLElBQ3JCLFNBQVNDLE9BQU87QUFDZGxDLFlBQU1rQyxNQUFNLDZCQUE2QjtBQUFBLElBQzNDLFVBQUM7QUFDQ3JCLGlCQUFXLEtBQUs7QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFFQWhCLFlBQVUsTUFBTTtBQUNkLFNBQUttQyxpQkFBaUI7QUFBQSxFQUN4QixHQUFHLEVBQUU7QUFFTCxRQUFNRyxjQUFjLE9BQU9DLGVBQWlDO0FBQzFEakIsMEJBQXNCaUIsVUFBVTtBQUNoQ3JCLG1CQUFlLElBQUk7QUFDbkJRLHNCQUFrQixJQUFJO0FBQ3RCLFFBQUk7QUFDRixZQUFNVSxPQUFPLE1BQU0vQixXQUFXa0MsV0FBV0MsRUFBRTtBQUMzQ2hCLGlCQUFXWSxJQUFJO0FBQUEsSUFDakIsU0FBU0MsT0FBTztBQUNkbEMsWUFBTWtDLE1BQU0sbUNBQW1DO0FBQy9DYixpQkFBVyxFQUFFO0FBQUEsSUFDZixVQUFDO0FBQ0NFLHdCQUFrQixLQUFLO0FBQUEsSUFDekI7QUFBQSxFQUNGO0FBRUEsUUFBTWUsZUFBZSxZQUFZO0FBQy9CLFFBQUksQ0FBQ3BCLG1CQUFvQjtBQUV6QixRQUFJLENBQUNNLGVBQWVlLEtBQUssR0FBRztBQUMxQnZDLFlBQU1rQyxNQUFNLGlDQUFpQztBQUM3QztBQUFBLElBQ0Y7QUFFQSxRQUFJO0FBQ0ZMLDBCQUFvQixJQUFJO0FBQ3hCLFlBQU1XLFdBQVcsTUFBTXJDLGdCQUFnQmUsbUJBQW1CbUIsSUFBSTtBQUFBLFFBQzVESSxpQkFBaUJqQixlQUFlZSxLQUFLO0FBQUEsUUFDckNHLGVBQWVoQjtBQUFBQSxNQUNqQixDQUFDO0FBQ0QsWUFBTWlCLFVBQVUsb0NBQW9DSCxTQUFTSSxLQUFLO0FBQ2xFYixvQkFBY1ksT0FBTztBQUNyQjNDLFlBQU02QyxRQUFRLGtDQUFrQztBQUFBLElBQ2xELFNBQVNYLE9BQVk7QUFDbkJsQyxZQUFNa0MsTUFBTUEsT0FBT00sVUFBVVAsTUFBTWEsVUFBVSw0QkFBNEI7QUFBQSxJQUMzRSxVQUFDO0FBQ0NqQiwwQkFBb0IsS0FBSztBQUFBLElBQzNCO0FBQUEsRUFDRjtBQUVBLFNBQ0UsdUJBQUMsYUFBUSxXQUFVLGFBQ2pCO0FBQUEsMkJBQUMsU0FBSSxXQUFVLHFEQUNiO0FBQUEsNkJBQUMsU0FDQztBQUFBLCtCQUFDLFFBQUcsV0FBVSx5Q0FBd0MsNkNBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUY7QUFBQSxRQUNuRix1QkFBQyxPQUFFLFdBQVUsK0JBQThCLHVFQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtHO0FBQUEsV0FGcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxVQUFPLE1BQUssVUFBUyxTQUFTLE1BQU1wQixTQUFTLDRCQUE0QixHQUFHLDhCQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJGO0FBQUEsU0FMN0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1BO0FBQUEsSUFFQ0csVUFDQyx1QkFBQyxTQUFJLFdBQVUsNkRBQ2IsaUNBQUMsV0FBUSxPQUFNLHlCQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb0MsS0FEdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBLElBRUEsdUJBQUMsU0FBSSxXQUFVLHlFQUNiLGlDQUFDLFNBQUksV0FBVSxtQkFDYixpQ0FBQyxXQUFNLFdBQVUsK0NBQ2Y7QUFBQSw2QkFBQyxXQUFNLFdBQVUsOERBQ2YsaUNBQUMsUUFDQztBQUFBLCtCQUFDLFFBQUcsV0FBVSwyQkFBMEIscUJBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkM7QUFBQSxRQUM3Qyx1QkFBQyxRQUFHLFdBQVUsMkJBQTBCLDBCQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtEO0FBQUEsUUFDbEQsdUJBQUMsUUFBRyxXQUFVLDJCQUEwQiwwQkFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRDtBQUFBLFFBQ2xELHVCQUFDLFFBQUcsV0FBVSwyQkFBMEIseUJBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUQ7QUFBQSxRQUNqRCx1QkFBQyxRQUFHLFdBQVUsMkJBQTBCLHVCQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStDO0FBQUEsUUFDL0MsdUJBQUMsUUFBRyxXQUFVLDJCQUEwQix1QkFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErQztBQUFBLFdBTmpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQSxLQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLE1BQ0EsdUJBQUMsV0FDRUYsc0JBQVlxQztBQUFBQSxRQUFJLENBQUNYLGVBQ2hCLHVCQUFDLFFBQXVCLFdBQVUsNkJBQ2hDO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHdDQUF3Q0EscUJBQVdZLFNBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVFO0FBQUEsVUFDdkUsdUJBQUMsUUFBRyxXQUFVLGFBQ1osaUNBQUMsU0FBTSxRQUFRWixXQUFXYSxlQUFlLFNBQVMsY0FBY2IsV0FBV2EsZUFBZSxXQUFXLFdBQVcsU0FBVWIscUJBQVdhLGNBQXJJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdKLEtBRGxKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFFBQUcsV0FBVSxhQUFhYjtBQUFBQSx1QkFBV2M7QUFBQUEsWUFBZ0I7QUFBQSxlQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwRDtBQUFBLFVBQzFELHVCQUFDLFFBQUcsV0FBVSxhQUFhZCxxQkFBV2UsaUJBQWlCQyxLQUFLLElBQUksS0FBSyxPQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RTtBQUFBLFVBQ3pFLHVCQUFDLFFBQUcsV0FBVSxhQUFhLGNBQUlDLEtBQUtqQixXQUFXa0IsVUFBVSxFQUFFQyxtQkFBbUIsS0FBOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0Y7QUFBQSxVQUNoRix1QkFBQyxRQUFHLFdBQVUsYUFDWixpQ0FBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSxtQ0FBQyxVQUFPLE1BQUssVUFBUyxTQUFRLGFBQVksU0FBUyxNQUFNcEIsWUFBWUMsVUFBVSxHQUFFLDRCQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFRO0FBQUEsZ0JBQ1IsU0FBUyxNQUFNO0FBQ2JqQix3Q0FBc0JpQixVQUFVO0FBQ2hDbkIsZ0NBQWMsSUFBSTtBQUNsQmMsZ0NBQWMsSUFBSTtBQUFBLGdCQUNwQjtBQUFBLGdCQUFFO0FBQUE7QUFBQSxjQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVVBO0FBQUEsZUFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWVBLEtBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaUJBO0FBQUEsYUF6Qk9LLFdBQVdDLElBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEwQkE7QUFBQSxNQUNELEtBN0JIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE4QkE7QUFBQSxTQXpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMENBLEtBM0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E0Q0EsS0E3Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQThDQTtBQUFBLElBR0R2QixlQUFlSSxzQkFDZCx1QkFBQyxTQUFJLFdBQVUsMkVBQ2IsaUNBQUMsU0FBSSxXQUFVLDBFQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHlFQUNiO0FBQUEsK0JBQUMsUUFBRyxXQUFVLHdDQUF3Q0E7QUFBQUEsNkJBQW1COEI7QUFBQUEsVUFBTTtBQUFBLGFBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUY7QUFBQSxRQUN6Rix1QkFBQyxVQUFPLE1BQUssVUFBUyxTQUFRLGFBQVksU0FBUyxNQUFNakMsZUFBZSxLQUFLLEdBQUcscUJBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUY7QUFBQSxXQUZ2RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxrQ0FDWk8sMkJBQ0MsdUJBQUMsV0FBUSxPQUFNLHFCQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0MsSUFFaEMsdUJBQUMsU0FBSSxXQUFVLHNEQUNiLGlDQUFDLFdBQU0sV0FBVSxnQ0FDZjtBQUFBLCtCQUFDLFdBQU0sV0FBVSw4QkFDZixpQ0FBQyxRQUNDO0FBQUEsaUNBQUMsUUFBRyxXQUFVLDJCQUEwQiw0QkFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0Q7QUFBQSxVQUNwRCx1QkFBQyxRQUFHLFdBQVUsMkJBQTBCLHFCQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2QztBQUFBLFVBQzdDLHVCQUFDLFFBQUcsV0FBVSwyQkFBMEIsc0JBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThDO0FBQUEsVUFDOUMsdUJBQUMsUUFBRyxXQUFVLDJCQUEwQiw0QkFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0Q7QUFBQSxhQUp0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUNBLHVCQUFDLFdBQ0VGLGtCQUFRb0MsV0FBVyxJQUNsQix1QkFBQyxRQUNDLGlDQUFDLFFBQUcsU0FBUyxHQUFHLFdBQVUsd0NBQXVDLDZDQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThGLEtBRGhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQSxJQUVBcEMsUUFBUTJCO0FBQUFBLFVBQUksQ0FBQ1UsUUFBUUMsVUFDbkIsdUJBQUMsUUFBOEMsV0FBVSw2QkFDdkQ7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsNEJBQTRCRCxpQkFBT2hCLG1CQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpRTtBQUFBLFlBQ2pFLHVCQUFDLFFBQUcsV0FBVSxhQUFhZ0IsaUJBQU9FLFVBQVUsUUFBUUYsT0FBT0UsVUFBVUMsU0FBWSxHQUFHSCxPQUFPRSxLQUFLLFdBQVcsYUFBM0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUg7QUFBQSxZQUNySCx1QkFBQyxRQUFHLFdBQVUsYUFBYUYsaUJBQU9FLFVBQVUsUUFBUUYsT0FBT0UsVUFBVUMsU0FBWSxjQUFjLGFBQS9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlHO0FBQUEsWUFDekcsdUJBQUMsUUFBRyxXQUFVLGFBQWFILGlCQUFPSSxlQUFlLElBQUlSLEtBQUtJLE9BQU9JLFlBQVksRUFBRUMsZUFBZSxJQUFJLGFBQWxHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRHO0FBQUEsZUFKckcsR0FBR0wsT0FBT2hCLGVBQWUsSUFBSWlCLEtBQUssSUFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLFFBQ0QsS0FiTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZUE7QUFBQSxXQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBeUJBLEtBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEyQkEsS0EvQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWlDQTtBQUFBLFNBdENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1Q0EsS0F4Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXlDQTtBQUFBLElBR0QxQyxjQUFjRSxzQkFDYix1QkFBQyxTQUFJLFdBQVUsMkVBQ2IsaUNBQUMsU0FBSSxXQUFVLDZFQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsK0JBQUMsUUFBRyxXQUFVLHdDQUF1QyxnQ0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRTtBQUFBLFFBQ3JFLHVCQUFDLFVBQU8sTUFBSyxVQUFTLFNBQVEsYUFBWSxTQUFTLE1BQU1ELGNBQWMsS0FBSyxHQUFHLHFCQUEvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9GO0FBQUEsV0FGdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSwrQkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLGlEQUFnRCwrQkFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0Y7QUFBQSxVQUNoRjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBT087QUFBQUEsY0FDUCxVQUFVLENBQUN1QyxVQUFVdEMsa0JBQWtCc0MsTUFBTUMsT0FBT0MsS0FBSztBQUFBLGNBQ3pELFdBQVU7QUFBQSxjQUNWLGFBQVk7QUFBQTtBQUFBLFlBSmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBSXFDO0FBQUEsYUFOdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsUUFFQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLGlEQUFnRCxrQ0FBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUY7QUFBQSxVQUNuRjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsS0FBSztBQUFBLGNBQ0wsT0FBT3ZDO0FBQUFBLGNBQ1AsVUFBVSxDQUFDcUMsVUFBVXBDLGdCQUFnQnVDLE9BQU9ILE1BQU1DLE9BQU9DLFNBQVMsRUFBRSxDQUFDO0FBQUEsY0FDckUsV0FBVTtBQUFBO0FBQUEsWUFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLK0o7QUFBQSxhQVBqSztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxRQUVBLHVCQUFDLFVBQU8sTUFBSyxVQUFTLFdBQVUsVUFBUyxVQUFVckMsa0JBQWtCLFNBQVNVLGNBQzNFViw2QkFBbUIsdUJBQUMsV0FBUSxPQUFNLHFCQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0MsSUFBTSxpQkFENUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFFQ0UsY0FDQyx1QkFBQyxTQUFJLFdBQVUsMERBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsNkNBQTRDLDBCQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxRTtBQUFBLFVBQ3JFLHVCQUFDLFNBQUksV0FBVSxzQ0FBc0NBLHdCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnRTtBQUFBLFVBQ2hFLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxTQUFRO0FBQUEsY0FDUixXQUFVO0FBQUEsY0FDVixTQUFTLFlBQVk7QUFDbkIsc0JBQU1xQyxVQUFVQyxVQUFVQyxVQUFVdkMsVUFBVTtBQUM5QzlCLHNCQUFNNkMsUUFBUSxxQkFBcUI7QUFBQSxjQUNyQztBQUFBLGNBQUU7QUFBQTtBQUFBLFlBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBVUEsS0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVlBO0FBQUEsYUFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0JBO0FBQUEsV0EzQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTZDQTtBQUFBLFNBbkRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvREEsS0FyREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXNEQTtBQUFBLE9BbktKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FxS0E7QUFFSjtBQUFDckMsR0E3T3VCRCxvQkFBa0I7QUFBQSxVQUN2QlIsV0FBVztBQUFBO0FBQUEsS0FETlE7QUFBa0IsSUFBQStEO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVN0YXRlIiwidXNlTmF2aWdhdGUiLCJ0b2FzdCIsImdldEFzc2Vzc21lbnRzIiwiZ2V0UmVzdWx0cyIsImludml0ZUNhbmRpZGF0ZSIsIkJhZGdlIiwiQnV0dG9uIiwiU3Bpbm5lciIsIlJlY3J1aXRlckRhc2hib2FyZCIsIl9zIiwibmF2aWdhdGUiLCJhc3Nlc3NtZW50cyIsInNldEFzc2Vzc21lbnRzIiwibG9hZGluZyIsInNldExvYWRpbmciLCJyZXN1bHRzT3BlbiIsInNldFJlc3VsdHNPcGVuIiwiaW52aXRlT3BlbiIsInNldEludml0ZU9wZW4iLCJzZWxlY3RlZEFzc2Vzc21lbnQiLCJzZXRTZWxlY3RlZEFzc2Vzc21lbnQiLCJyZXN1bHRzIiwic2V0UmVzdWx0cyIsInJlc3VsdHNMb2FkaW5nIiwic2V0UmVzdWx0c0xvYWRpbmciLCJjYW5kaWRhdGVFbWFpbCIsInNldENhbmRpZGF0ZUVtYWlsIiwiZXhwaXJlc0hvdXJzIiwic2V0RXhwaXJlc0hvdXJzIiwiaW52aXRlU3VibWl0dGluZyIsInNldEludml0ZVN1Ym1pdHRpbmciLCJpbnZpdGVMaW5rIiwic2V0SW52aXRlTGluayIsImZldGNoQXNzZXNzbWVudHMiLCJkYXRhIiwiZXJyb3IiLCJvcGVuUmVzdWx0cyIsImFzc2Vzc21lbnQiLCJpZCIsImhhbmRsZUludml0ZSIsInRyaW0iLCJyZXNwb25zZSIsImNhbmRpZGF0ZV9lbWFpbCIsImV4cGlyZXNfaG91cnMiLCJmdWxsVXJsIiwidG9rZW4iLCJzdWNjZXNzIiwiZGV0YWlsIiwibWFwIiwidGl0bGUiLCJkaWZmaWN1bHR5IiwidGltZV9saW1pdF9taW5zIiwibGFuZ3VhZ2Vfc3VwcG9ydCIsImpvaW4iLCJEYXRlIiwiY3JlYXRlZF9hdCIsInRvTG9jYWxlRGF0ZVN0cmluZyIsImxlbmd0aCIsInJlc3VsdCIsImluZGV4Iiwic2NvcmUiLCJ1bmRlZmluZWQiLCJzdWJtaXR0ZWRfYXQiLCJ0b0xvY2FsZVN0cmluZyIsImV2ZW50IiwidGFyZ2V0IiwidmFsdWUiLCJOdW1iZXIiLCJuYXZpZ2F0b3IiLCJjbGlwYm9hcmQiLCJ3cml0ZVRleHQiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJSZWNydWl0ZXJEYXNoYm9hcmQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcbmltcG9ydCB0b2FzdCBmcm9tIFwicmVhY3QtaG90LXRvYXN0XCI7XG5pbXBvcnQgeyBnZXRBc3Nlc3NtZW50cywgZ2V0UmVzdWx0cywgaW52aXRlQ2FuZGlkYXRlLCB0eXBlIEFzc2Vzc21lbnRSZWNvcmQgfSBmcm9tIFwiLi4vYXBpL2Fzc2Vzc21lbnRzXCI7XG5pbXBvcnQgQmFkZ2UgZnJvbSBcIi4uL2NvbXBvbmVudHMvdWkvQmFkZ2VcIjtcbmltcG9ydCBCdXR0b24gZnJvbSBcIi4uL2NvbXBvbmVudHMvdWkvQnV0dG9uXCI7XG5pbXBvcnQgU3Bpbm5lciBmcm9tIFwiLi4vY29tcG9uZW50cy91aS9TcGlubmVyXCI7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFJlY3J1aXRlckRhc2hib2FyZCgpIHtcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuICBjb25zdCBbYXNzZXNzbWVudHMsIHNldEFzc2Vzc21lbnRzXSA9IHVzZVN0YXRlPEFzc2Vzc21lbnRSZWNvcmRbXT4oW10pO1xuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKTtcbiAgY29uc3QgW3Jlc3VsdHNPcGVuLCBzZXRSZXN1bHRzT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtpbnZpdGVPcGVuLCBzZXRJbnZpdGVPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3NlbGVjdGVkQXNzZXNzbWVudCwgc2V0U2VsZWN0ZWRBc3Nlc3NtZW50XSA9IHVzZVN0YXRlPEFzc2Vzc21lbnRSZWNvcmQgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW3Jlc3VsdHMsIHNldFJlc3VsdHNdID0gdXNlU3RhdGU8QXJyYXk8eyBjYW5kaWRhdGVfZW1haWw6IHN0cmluZzsgc2NvcmU6IG51bWJlciB8IG51bGw7IHN0YXR1czogc3RyaW5nOyBzdWJtaXR0ZWRfYXQ/OiBzdHJpbmcgfCBudWxsIH0+PihbXSk7XG4gIGNvbnN0IFtyZXN1bHRzTG9hZGluZywgc2V0UmVzdWx0c0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbY2FuZGlkYXRlRW1haWwsIHNldENhbmRpZGF0ZUVtYWlsXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbZXhwaXJlc0hvdXJzLCBzZXRFeHBpcmVzSG91cnNdID0gdXNlU3RhdGUoNDgpO1xuICBjb25zdCBbaW52aXRlU3VibWl0dGluZywgc2V0SW52aXRlU3VibWl0dGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtpbnZpdGVMaW5rLCBzZXRJbnZpdGVMaW5rXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuXG4gIGNvbnN0IGZldGNoQXNzZXNzbWVudHMgPSBhc3luYyAoKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIHNldExvYWRpbmcodHJ1ZSk7XG4gICAgICBjb25zdCBkYXRhID0gYXdhaXQgZ2V0QXNzZXNzbWVudHMoKTtcbiAgICAgIHNldEFzc2Vzc21lbnRzKGRhdGEpO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICB0b2FzdC5lcnJvcihcIlVuYWJsZSB0byBsb2FkIGFzc2Vzc21lbnRzLlwiKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgfVxuICB9O1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgdm9pZCBmZXRjaEFzc2Vzc21lbnRzKCk7XG4gIH0sIFtdKTtcblxuICBjb25zdCBvcGVuUmVzdWx0cyA9IGFzeW5jIChhc3Nlc3NtZW50OiBBc3Nlc3NtZW50UmVjb3JkKSA9PiB7XG4gICAgc2V0U2VsZWN0ZWRBc3Nlc3NtZW50KGFzc2Vzc21lbnQpO1xuICAgIHNldFJlc3VsdHNPcGVuKHRydWUpO1xuICAgIHNldFJlc3VsdHNMb2FkaW5nKHRydWUpO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBkYXRhID0gYXdhaXQgZ2V0UmVzdWx0cyhhc3Nlc3NtZW50LmlkKTtcbiAgICAgIHNldFJlc3VsdHMoZGF0YSk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIHRvYXN0LmVycm9yKFwiVW5hYmxlIHRvIGxvYWQgY2FuZGlkYXRlIHJlc3VsdHMuXCIpO1xuICAgICAgc2V0UmVzdWx0cyhbXSk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldFJlc3VsdHNMb2FkaW5nKGZhbHNlKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlSW52aXRlID0gYXN5bmMgKCkgPT4ge1xuICAgIGlmICghc2VsZWN0ZWRBc3Nlc3NtZW50KSByZXR1cm47XG5cbiAgICBpZiAoIWNhbmRpZGF0ZUVtYWlsLnRyaW0oKSkge1xuICAgICAgdG9hc3QuZXJyb3IoXCJQbGVhc2UgZW50ZXIgYSBjYW5kaWRhdGUgZW1haWwuXCIpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIHRyeSB7XG4gICAgICBzZXRJbnZpdGVTdWJtaXR0aW5nKHRydWUpO1xuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBpbnZpdGVDYW5kaWRhdGUoc2VsZWN0ZWRBc3Nlc3NtZW50LmlkLCB7XG4gICAgICAgIGNhbmRpZGF0ZV9lbWFpbDogY2FuZGlkYXRlRW1haWwudHJpbSgpLFxuICAgICAgICBleHBpcmVzX2hvdXJzOiBleHBpcmVzSG91cnNcbiAgICAgIH0pO1xuICAgICAgY29uc3QgZnVsbFVybCA9IGBodHRwOi8vbG9jYWxob3N0OjUxNzMvYXNzZXNzbWVudC8ke3Jlc3BvbnNlLnRva2VufWA7XG4gICAgICBzZXRJbnZpdGVMaW5rKGZ1bGxVcmwpO1xuICAgICAgdG9hc3Quc3VjY2VzcyhcIkludml0YXRpb24gY3JlYXRlZCBzdWNjZXNzZnVsbHkuXCIpO1xuICAgIH0gY2F0Y2ggKGVycm9yOiBhbnkpIHtcbiAgICAgIHRvYXN0LmVycm9yKGVycm9yPy5yZXNwb25zZT8uZGF0YT8uZGV0YWlsIHx8IFwiRmFpbGVkIHRvIHNlbmQgaW52aXRhdGlvbi5cIik7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldEludml0ZVN1Ym1pdHRpbmcoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zXCI+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS05NTBcIj5CaXRMYWJzIOKAlCBSZWNydWl0ZXIgRGFzaGJvYXJkPC9oMj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1zbGF0ZS02MDBcIj5SZXZpZXcgYXNzZXNzbWVudHMsIGNhbmRpZGF0ZSByZXN1bHRzLCBhbmQgaW52aXRhdGlvbnMuPC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPEJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoXCIvcmVjcnVpdGVyL2Fzc2Vzc21lbnRzL25ld1wiKX0+TmV3IEFzc2Vzc21lbnQ8L0J1dHRvbj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7bG9hZGluZyA/IChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLWxnIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGJnLXdoaXRlIHAtOCBzaGFkb3ctc21cIj5cbiAgICAgICAgICA8U3Bpbm5lciBsYWJlbD1cIkxvYWRpbmcgYXNzZXNzbWVudHNcIiAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICkgOiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgYmctd2hpdGUgc2hhZG93LXNtXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy14LWF1dG9cIj5cbiAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJtaW4tdy1mdWxsIHRleHQtbGVmdCB0ZXh0LXNtIHRleHQtc2xhdGUtNzAwXCI+XG4gICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1zbGF0ZS01MCB0ZXh0LXhzIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIHRleHQtc2xhdGUtNjAwXCI+XG4gICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTQgcHktMyBmb250LXNlbWlib2xkXCI+VGl0bGU8L3RoPlxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTQgcHktMyBmb250LXNlbWlib2xkXCI+RGlmZmljdWx0eTwvdGg+XG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNCBweS0zIGZvbnQtc2VtaWJvbGRcIj5UaW1lIExpbWl0PC90aD5cbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC00IHB5LTMgZm9udC1zZW1pYm9sZFwiPkxhbmd1YWdlczwvdGg+XG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNCBweS0zIGZvbnQtc2VtaWJvbGRcIj5DcmVhdGVkPC90aD5cbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC00IHB5LTMgZm9udC1zZW1pYm9sZFwiPkFjdGlvbnM8L3RoPlxuICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgIDx0Ym9keT5cbiAgICAgICAgICAgICAgICB7YXNzZXNzbWVudHMubWFwKChhc3Nlc3NtZW50KSA9PiAoXG4gICAgICAgICAgICAgICAgICA8dHIga2V5PXthc3Nlc3NtZW50LmlkfSBjbGFzc05hbWU9XCJib3JkZXItdCBib3JkZXItc2xhdGUtMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTQgZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS05MDBcIj57YXNzZXNzbWVudC50aXRsZX08L3RkPlxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNCBweS00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgPEJhZGdlIHN0YXR1cz17YXNzZXNzbWVudC5kaWZmaWN1bHR5ID09PSBcImhhcmRcIiA/IFwiY29tcGxldGVkXCIgOiBhc3Nlc3NtZW50LmRpZmZpY3VsdHkgPT09IFwibWVkaXVtXCIgPyBcImFjdGl2ZVwiIDogXCJkcmFmdFwifT57YXNzZXNzbWVudC5kaWZmaWN1bHR5fTwvQmFkZ2U+XG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTRcIj57YXNzZXNzbWVudC50aW1lX2xpbWl0X21pbnN9IG1pbjwvdGQ+XG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTRcIj57YXNzZXNzbWVudC5sYW5ndWFnZV9zdXBwb3J0LmpvaW4oXCIsIFwiKSB8fCBcIuKAlFwifTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTRcIj57bmV3IERhdGUoYXNzZXNzbWVudC5jcmVhdGVkX2F0KS50b0xvY2FsZURhdGVTdHJpbmcoKX08L3RkPlxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNCBweS00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgdmFyaWFudD1cInNlY29uZGFyeVwiIG9uQ2xpY2s9eygpID0+IG9wZW5SZXN1bHRzKGFzc2Vzc21lbnQpfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgVmlldyBSZXN1bHRzXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRBc3Nlc3NtZW50KGFzc2Vzc21lbnQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEludml0ZU9wZW4odHJ1ZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0SW52aXRlTGluayhudWxsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgSW52aXRlIENhbmRpZGF0ZVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7cmVzdWx0c09wZW4gJiYgc2VsZWN0ZWRBc3Nlc3NtZW50ICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctc2xhdGUtOTAwLzMwIHAtNFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIG1heC13LTN4bCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGJnLXdoaXRlIHNoYWRvdy14bFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTIwMCBweC01IHB5LTRcIj5cbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTkwMFwiPntzZWxlY3RlZEFzc2Vzc21lbnQudGl0bGV9IOKAlCBSZXN1bHRzPC9oMz5cbiAgICAgICAgICAgICAgPEJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgdmFyaWFudD1cInNlY29uZGFyeVwiIG9uQ2xpY2s9eygpID0+IHNldFJlc3VsdHNPcGVuKGZhbHNlKX0+Q2xvc2U8L0J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtaC1bNzB2aF0gb3ZlcmZsb3ctYXV0byBwLTVcIj5cbiAgICAgICAgICAgICAge3Jlc3VsdHNMb2FkaW5nID8gKFxuICAgICAgICAgICAgICAgIDxTcGlubmVyIGxhYmVsPVwiTG9hZGluZyByZXN1bHRzXCIgLz5cbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LWhpZGRlbiByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItc2xhdGUtMjAwXCI+XG4gICAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwibWluLXctZnVsbCB0ZXh0LWxlZnQgdGV4dC1zbVwiPlxuICAgICAgICAgICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwiYmctc2xhdGUtNTAgdGV4dC1zbGF0ZS02MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0yIGZvbnQtc2VtaWJvbGRcIj5DYW5kaWRhdGUgSUQ8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMiBmb250LXNlbWlib2xkXCI+U2NvcmU8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMiBmb250LXNlbWlib2xkXCI+U3RhdHVzPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTIgZm9udC1zZW1pYm9sZFwiPlN1Ym1pdHRlZCBBdDwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgICAgICAgICAgPHRib2R5PlxuICAgICAgICAgICAgICAgICAgICAgIHtyZXN1bHRzLmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNvbFNwYW49ezR9IGNsYXNzTmFtZT1cInB4LTMgcHktNCB0ZXh0LWNlbnRlciB0ZXh0LXNsYXRlLTUwMFwiPk5vIGNhbmRpZGF0ZSBzdWJtaXNzaW9ucyB5ZXQuPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdHMubWFwKChyZXN1bHQsIGluZGV4KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e2Ake3Jlc3VsdC5jYW5kaWRhdGVfZW1haWx9LSR7aW5kZXh9YH0gY2xhc3NOYW1lPVwiYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTMgdGV4dC1zbGF0ZS04MDBcIj57cmVzdWx0LmNhbmRpZGF0ZV9lbWFpbH08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTNcIj57cmVzdWx0LnNjb3JlICE9PSBudWxsICYmIHJlc3VsdC5zY29yZSAhPT0gdW5kZWZpbmVkID8gYCR7cmVzdWx0LnNjb3JlfSAvIDEwMGAgOiBcIlBlbmRpbmdcIn08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTNcIj57cmVzdWx0LnNjb3JlICE9PSBudWxsICYmIHJlc3VsdC5zY29yZSAhPT0gdW5kZWZpbmVkID8gXCJTdWJtaXR0ZWRcIiA6IFwiUGVuZGluZ1wifTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktM1wiPntyZXN1bHQuc3VibWl0dGVkX2F0ID8gbmV3IERhdGUocmVzdWx0LnN1Ym1pdHRlZF9hdCkudG9Mb2NhbGVTdHJpbmcoKSA6IFwiUGVuZGluZ1wifTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICApKVxuICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAge2ludml0ZU9wZW4gJiYgc2VsZWN0ZWRBc3Nlc3NtZW50ICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctc2xhdGUtOTAwLzMwIHAtNFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIG1heC13LWxnIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgYmctd2hpdGUgcC01IHNoYWRvdy14bFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTkwMFwiPkludml0ZSBDYW5kaWRhdGU8L2gzPlxuICAgICAgICAgICAgICA8QnV0dG9uIHR5cGU9XCJidXR0b25cIiB2YXJpYW50PVwic2Vjb25kYXJ5XCIgb25DbGljaz17KCkgPT4gc2V0SW52aXRlT3BlbihmYWxzZSl9PkNsb3NlPC9CdXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IHNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJtYi0xIGJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS03MDBcIj5DYW5kaWRhdGUgZW1haWw8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2NhbmRpZGF0ZUVtYWlsfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0Q2FuZGlkYXRlRW1haWwoZXZlbnQudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItc2xhdGUtMzAwIGJnLXdoaXRlIHB4LTMgcHktMiB0ZXh0LXNsYXRlLTkwMCBvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLWJyYW5kLTUwMCBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1icmFuZC0xMDBcIlxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJjYW5kaWRhdGVAZXhhbXBsZS5jb21cIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cIm1iLTEgYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTcwMFwiPkV4cGlyZXMgaW4gKGhvdXJzKTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcbiAgICAgICAgICAgICAgICAgIG1pbj17MX1cbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtleHBpcmVzSG91cnN9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXRFeHBpcmVzSG91cnMoTnVtYmVyKGV2ZW50LnRhcmdldC52YWx1ZSB8fCA0OCkpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1zbGF0ZS0zMDAgYmctd2hpdGUgcHgtMyBweS0yIHRleHQtc2xhdGUtOTAwIG91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItYnJhbmQtNTAwIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJyYW5kLTEwMFwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPEJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwidy1mdWxsXCIgZGlzYWJsZWQ9e2ludml0ZVN1Ym1pdHRpbmd9IG9uQ2xpY2s9e2hhbmRsZUludml0ZX0+XG4gICAgICAgICAgICAgICAge2ludml0ZVN1Ym1pdHRpbmcgPyA8U3Bpbm5lciBsYWJlbD1cIkNyZWF0aW5nIGludml0ZVwiIC8+IDogXCJTZW5kIEludml0ZVwifVxuICAgICAgICAgICAgICA8L0J1dHRvbj5cblxuICAgICAgICAgICAgICB7aW52aXRlTGluayAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZW1lcmFsZC0yMDAgYmctZW1lcmFsZC01MCBwLTNcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZW1lcmFsZC04MDBcIj5JbnZpdGUgVVJMPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJyZWFrLWFsbCB0ZXh0LXNtIHRleHQtZW1lcmFsZC03MDBcIj57aW52aXRlTGlua308L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtM1wiPlxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgdmFyaWFudD1cInNlY29uZGFyeVwiXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsXCJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXthc3luYyAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBhd2FpdCBuYXZpZ2F0b3IuY2xpcGJvYXJkLndyaXRlVGV4dChpbnZpdGVMaW5rKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRvYXN0LnN1Y2Nlc3MoXCJJbnZpdGUgbGluayBjb3BpZWQuXCIpO1xuICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICBDb3B5IGxpbmtcbiAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG4gICAgPC9zZWN0aW9uPlxuICApO1xufVxuIl0sImZpbGUiOiJDOi9Vc2Vycy9ZYXN3YW50aCBSYWh1bC9Eb3dubG9hZHMvQml0TGFicy1Db2RpbmctTGFiL2Zyb250ZW5kL3NyYy9yb3V0ZXMvUmVjcnVpdGVyRGFzaGJvYXJkLnRzeCJ9