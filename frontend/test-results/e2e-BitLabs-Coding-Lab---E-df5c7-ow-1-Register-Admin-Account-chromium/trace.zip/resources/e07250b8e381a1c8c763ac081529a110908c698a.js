export const languageLabels = {
  python: "Python",
  c: "C",
  cpp: "C++",
  java: "Java",
  javascript: "JavaScript"
};
export const languageTemplates = {
  python: 'print("Hello, World!")\n',
  c: '#include <stdio.h>\n\nint main(void) {\n    printf("Hello, World!\\n");\n    return 0;\n}\n',
  cpp: '#include <iostream>\n\nint main() {\n    std::cout << "Hello, World!" << std::endl;\n    return 0;\n}\n',
  java: 'public class Main {\n    public static void main(String[] args) {\n        System.out.println("Hello, World!");\n    }\n}\n',
  javascript: 'console.log("Hello, World!");\n'
};

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRlbXBsYXRlcy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgdHlwZSBTdXBwb3J0ZWRMYW5ndWFnZSA9IFwicHl0aG9uXCIgfCBcImNcIiB8IFwiY3BwXCIgfCBcImphdmFcIiB8IFwiamF2YXNjcmlwdFwiO1xuXG5leHBvcnQgY29uc3QgbGFuZ3VhZ2VMYWJlbHM6IFJlY29yZDxTdXBwb3J0ZWRMYW5ndWFnZSwgc3RyaW5nPiA9IHtcbiAgcHl0aG9uOiBcIlB5dGhvblwiLFxuICBjOiBcIkNcIixcbiAgY3BwOiBcIkMrK1wiLFxuICBqYXZhOiBcIkphdmFcIixcbiAgamF2YXNjcmlwdDogXCJKYXZhU2NyaXB0XCJcbn07XG5cbmV4cG9ydCBjb25zdCBsYW5ndWFnZVRlbXBsYXRlczogUmVjb3JkPFN1cHBvcnRlZExhbmd1YWdlLCBzdHJpbmc+ID0ge1xuICBweXRob246ICdwcmludChcIkhlbGxvLCBXb3JsZCFcIilcXG4nLFxuICBjOiAnI2luY2x1ZGUgPHN0ZGlvLmg+XFxuXFxuaW50IG1haW4odm9pZCkge1xcbiAgICBwcmludGYoXCJIZWxsbywgV29ybGQhXFxcXG5cIik7XFxuICAgIHJldHVybiAwO1xcbn1cXG4nLFxuICBjcHA6ICcjaW5jbHVkZSA8aW9zdHJlYW0+XFxuXFxuaW50IG1haW4oKSB7XFxuICAgIHN0ZDo6Y291dCA8PCBcIkhlbGxvLCBXb3JsZCFcIiA8PCBzdGQ6OmVuZGw7XFxuICAgIHJldHVybiAwO1xcbn1cXG4nLFxuICBqYXZhOiAncHVibGljIGNsYXNzIE1haW4ge1xcbiAgICBwdWJsaWMgc3RhdGljIHZvaWQgbWFpbihTdHJpbmdbXSBhcmdzKSB7XFxuICAgICAgICBTeXN0ZW0ub3V0LnByaW50bG4oXCJIZWxsbywgV29ybGQhXCIpO1xcbiAgICB9XFxufVxcbicsXG4gIGphdmFzY3JpcHQ6ICdjb25zb2xlLmxvZyhcIkhlbGxvLCBXb3JsZCFcIik7XFxuJ1xufTtcbiJdLCJtYXBwaW5ncyI6IkFBRU8sYUFBTSxpQkFBb0Q7QUFBQSxFQUMvRCxRQUFRO0FBQUEsRUFDUixHQUFHO0FBQUEsRUFDSCxLQUFLO0FBQUEsRUFDTCxNQUFNO0FBQUEsRUFDTixZQUFZO0FBQ2Q7QUFFTyxhQUFNLG9CQUF1RDtBQUFBLEVBQ2xFLFFBQVE7QUFBQSxFQUNSLEdBQUc7QUFBQSxFQUNILEtBQUs7QUFBQSxFQUNMLE1BQU07QUFBQSxFQUNOLFlBQVk7QUFDZDsiLCJuYW1lcyI6W119