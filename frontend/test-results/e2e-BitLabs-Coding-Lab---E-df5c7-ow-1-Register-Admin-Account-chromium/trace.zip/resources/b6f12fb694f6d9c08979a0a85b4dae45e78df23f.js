import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/editor/CodeEditor.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1cbb189e"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/components/editor/CodeEditor.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import Editor from "/node_modules/.vite/deps/@monaco-editor_react.js?v=1cbb189e";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=1cbb189e"; const useEffect = __vite__cjsImport4_react["useEffect"]; const useRef = __vite__cjsImport4_react["useRef"];
import { languageTemplates } from "/src/constants/templates.ts";
export default function CodeEditor({ language, value, onChange, readOnly = false, heightClass = "h-[520px]" }) {
  _s();
  const previousLanguage = useRef(language);
  useEffect(() => {
    if (previousLanguage.current === language) {
      return;
    }
    const prevTemplate = languageTemplates[previousLanguage.current];
    const nextTemplate = languageTemplates[language];
    if (value === prevTemplate) {
      onChange(nextTemplate);
    } else if (value !== nextTemplate) {
      const shouldReplace = window.confirm(
        `Replace the current code with the ${language} starter template?`
      );
      if (shouldReplace) {
        onChange(nextTemplate);
      }
    }
    previousLanguage.current = language;
  }, [language, onChange, value]);
  const handleChange = (nextValue) => {
    onChange(nextValue ?? "");
  };
  return /* @__PURE__ */ jsxDEV("div", { className: `${heightClass} overflow-hidden rounded-lg border border-slate-800 bg-slate-950`, children: /* @__PURE__ */ jsxDEV(
    Editor,
    {
      height: "100%",
      language: language === "cpp" ? "cpp" : language,
      value,
      theme: "vs-dark",
      onChange: handleChange,
      options: {
        fontSize: 14,
        lineNumbers: "on",
        scrollBeyondLastLine: false,
        minimap: { enabled: false },
        quickSuggestions: false,
        suggestOnTriggerCharacters: false,
        wordBasedSuggestions: "off",
        parameterHints: { enabled: false },
        snippetSuggestions: "none",
        readOnly
      }
    },
    void 0,
    false,
    {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/components/editor/CodeEditor.tsx",
      lineNumber: 62,
      columnNumber: 7
    },
    this
  ) }, void 0, false, {
    fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/components/editor/CodeEditor.tsx",
    lineNumber: 61,
    columnNumber: 5
  }, this);
}
_s(CodeEditor, "QgFxnmCYSY0+IZjs2GJNPVKTxMk=");
_c = CodeEditor;
var _c;
$RefreshReg$(_c, "CodeEditor");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/components/editor/CodeEditor.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/components/editor/CodeEditor.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMENNOzs7Ozs7Ozs7Ozs7Ozs7OztBQTFDTixPQUFPQSxZQUEwQjtBQUNqQyxTQUFTQyxXQUFXQyxjQUFjO0FBQ2xDLFNBQVNDLHlCQUE0QztBQVVyRCx3QkFBd0JDLFdBQVcsRUFBRUMsVUFBVUMsT0FBT0MsVUFBVUMsV0FBVyxPQUFPQyxjQUFjLFlBQTZCLEdBQUc7QUFBQUMsS0FBQTtBQUM5SCxRQUFNQyxtQkFBbUJULE9BQU9HLFFBQVE7QUFFeENKLFlBQVUsTUFBTTtBQUNkLFFBQUlVLGlCQUFpQkMsWUFBWVAsVUFBVTtBQUN6QztBQUFBLElBQ0Y7QUFFQSxVQUFNUSxlQUFlVixrQkFBa0JRLGlCQUFpQkMsT0FBTztBQUMvRCxVQUFNRSxlQUFlWCxrQkFBa0JFLFFBQVE7QUFDL0MsUUFBSUMsVUFBVU8sY0FBYztBQUMxQk4sZUFBU08sWUFBWTtBQUFBLElBQ3ZCLFdBQVdSLFVBQVVRLGNBQWM7QUFDakMsWUFBTUMsZ0JBQWdCQyxPQUFPQztBQUFBQSxRQUMzQixxQ0FBcUNaLFFBQVE7QUFBQSxNQUMvQztBQUNBLFVBQUlVLGVBQWU7QUFDakJSLGlCQUFTTyxZQUFZO0FBQUEsTUFDdkI7QUFBQSxJQUNGO0FBRUFILHFCQUFpQkMsVUFBVVA7QUFBQUEsRUFDN0IsR0FBRyxDQUFDQSxVQUFVRSxVQUFVRCxLQUFLLENBQUM7QUFFOUIsUUFBTVksZUFBeUJBLENBQUNDLGNBQWM7QUFDNUNaLGFBQVNZLGFBQWEsRUFBRTtBQUFBLEVBQzFCO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVcsR0FBR1YsV0FBVyxvRUFDNUI7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLFFBQU87QUFBQSxNQUNQLFVBQVVKLGFBQWEsUUFBUSxRQUFRQTtBQUFBQSxNQUN2QztBQUFBLE1BQ0EsT0FBTTtBQUFBLE1BQ04sVUFBVWE7QUFBQUEsTUFDVixTQUFTO0FBQUEsUUFDUEUsVUFBVTtBQUFBLFFBQ1ZDLGFBQWE7QUFBQSxRQUNiQyxzQkFBc0I7QUFBQSxRQUN0QkMsU0FBUyxFQUFFQyxTQUFTLE1BQU07QUFBQSxRQUMxQkMsa0JBQWtCO0FBQUEsUUFDbEJDLDRCQUE0QjtBQUFBLFFBQzVCQyxzQkFBc0I7QUFBQSxRQUN0QkMsZ0JBQWdCLEVBQUVKLFNBQVMsTUFBTTtBQUFBLFFBQ2pDSyxvQkFBb0I7QUFBQSxRQUNwQnJCO0FBQUFBLE1BQ0Y7QUFBQTtBQUFBLElBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQWlCSSxLQWxCTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBb0JBO0FBRUo7QUFBQ0UsR0FuRHVCTixZQUFVO0FBQUEsS0FBVkE7QUFBVSxJQUFBMEI7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiRWRpdG9yIiwidXNlRWZmZWN0IiwidXNlUmVmIiwibGFuZ3VhZ2VUZW1wbGF0ZXMiLCJDb2RlRWRpdG9yIiwibGFuZ3VhZ2UiLCJ2YWx1ZSIsIm9uQ2hhbmdlIiwicmVhZE9ubHkiLCJoZWlnaHRDbGFzcyIsIl9zIiwicHJldmlvdXNMYW5ndWFnZSIsImN1cnJlbnQiLCJwcmV2VGVtcGxhdGUiLCJuZXh0VGVtcGxhdGUiLCJzaG91bGRSZXBsYWNlIiwid2luZG93IiwiY29uZmlybSIsImhhbmRsZUNoYW5nZSIsIm5leHRWYWx1ZSIsImZvbnRTaXplIiwibGluZU51bWJlcnMiLCJzY3JvbGxCZXlvbmRMYXN0TGluZSIsIm1pbmltYXAiLCJlbmFibGVkIiwicXVpY2tTdWdnZXN0aW9ucyIsInN1Z2dlc3RPblRyaWdnZXJDaGFyYWN0ZXJzIiwid29yZEJhc2VkU3VnZ2VzdGlvbnMiLCJwYXJhbWV0ZXJIaW50cyIsInNuaXBwZXRTdWdnZXN0aW9ucyIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkNvZGVFZGl0b3IudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBFZGl0b3IsIHsgT25DaGFuZ2UgfSBmcm9tIFwiQG1vbmFjby1lZGl0b3IvcmVhY3RcIjtcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlUmVmIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBsYW5ndWFnZVRlbXBsYXRlcywgU3VwcG9ydGVkTGFuZ3VhZ2UgfSBmcm9tIFwiLi4vLi4vY29uc3RhbnRzL3RlbXBsYXRlc1wiO1xuXG50eXBlIENvZGVFZGl0b3JQcm9wcyA9IHtcbiAgbGFuZ3VhZ2U6IFN1cHBvcnRlZExhbmd1YWdlO1xuICB2YWx1ZTogc3RyaW5nO1xuICBvbkNoYW5nZTogKHZhbHVlOiBzdHJpbmcpID0+IHZvaWQ7XG4gIHJlYWRPbmx5PzogYm9vbGVhbjtcbiAgaGVpZ2h0Q2xhc3M/OiBzdHJpbmc7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBDb2RlRWRpdG9yKHsgbGFuZ3VhZ2UsIHZhbHVlLCBvbkNoYW5nZSwgcmVhZE9ubHkgPSBmYWxzZSwgaGVpZ2h0Q2xhc3MgPSBcImgtWzUyMHB4XVwiIH06IENvZGVFZGl0b3JQcm9wcykge1xuICBjb25zdCBwcmV2aW91c0xhbmd1YWdlID0gdXNlUmVmKGxhbmd1YWdlKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChwcmV2aW91c0xhbmd1YWdlLmN1cnJlbnQgPT09IGxhbmd1YWdlKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc3QgcHJldlRlbXBsYXRlID0gbGFuZ3VhZ2VUZW1wbGF0ZXNbcHJldmlvdXNMYW5ndWFnZS5jdXJyZW50XTtcbiAgICBjb25zdCBuZXh0VGVtcGxhdGUgPSBsYW5ndWFnZVRlbXBsYXRlc1tsYW5ndWFnZV07XG4gICAgaWYgKHZhbHVlID09PSBwcmV2VGVtcGxhdGUpIHtcbiAgICAgIG9uQ2hhbmdlKG5leHRUZW1wbGF0ZSk7XG4gICAgfSBlbHNlIGlmICh2YWx1ZSAhPT0gbmV4dFRlbXBsYXRlKSB7XG4gICAgICBjb25zdCBzaG91bGRSZXBsYWNlID0gd2luZG93LmNvbmZpcm0oXG4gICAgICAgIGBSZXBsYWNlIHRoZSBjdXJyZW50IGNvZGUgd2l0aCB0aGUgJHtsYW5ndWFnZX0gc3RhcnRlciB0ZW1wbGF0ZT9gXG4gICAgICApO1xuICAgICAgaWYgKHNob3VsZFJlcGxhY2UpIHtcbiAgICAgICAgb25DaGFuZ2UobmV4dFRlbXBsYXRlKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBwcmV2aW91c0xhbmd1YWdlLmN1cnJlbnQgPSBsYW5ndWFnZTtcbiAgfSwgW2xhbmd1YWdlLCBvbkNoYW5nZSwgdmFsdWVdKTtcblxuICBjb25zdCBoYW5kbGVDaGFuZ2U6IE9uQ2hhbmdlID0gKG5leHRWYWx1ZSkgPT4ge1xuICAgIG9uQ2hhbmdlKG5leHRWYWx1ZSA/PyBcIlwiKTtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPXtgJHtoZWlnaHRDbGFzc30gb3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgYmctc2xhdGUtOTUwYH0+XG4gICAgICA8RWRpdG9yXG4gICAgICAgIGhlaWdodD1cIjEwMCVcIlxuICAgICAgICBsYW5ndWFnZT17bGFuZ3VhZ2UgPT09IFwiY3BwXCIgPyBcImNwcFwiIDogbGFuZ3VhZ2V9XG4gICAgICAgIHZhbHVlPXt2YWx1ZX1cbiAgICAgICAgdGhlbWU9XCJ2cy1kYXJrXCJcbiAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cbiAgICAgICAgb3B0aW9ucz17e1xuICAgICAgICAgIGZvbnRTaXplOiAxNCxcbiAgICAgICAgICBsaW5lTnVtYmVyczogXCJvblwiLFxuICAgICAgICAgIHNjcm9sbEJleW9uZExhc3RMaW5lOiBmYWxzZSxcbiAgICAgICAgICBtaW5pbWFwOiB7IGVuYWJsZWQ6IGZhbHNlIH0sXG4gICAgICAgICAgcXVpY2tTdWdnZXN0aW9uczogZmFsc2UsXG4gICAgICAgICAgc3VnZ2VzdE9uVHJpZ2dlckNoYXJhY3RlcnM6IGZhbHNlLFxuICAgICAgICAgIHdvcmRCYXNlZFN1Z2dlc3Rpb25zOiBcIm9mZlwiLFxuICAgICAgICAgIHBhcmFtZXRlckhpbnRzOiB7IGVuYWJsZWQ6IGZhbHNlIH0sXG4gICAgICAgICAgc25pcHBldFN1Z2dlc3Rpb25zOiBcIm5vbmVcIixcbiAgICAgICAgICByZWFkT25seVxuICAgICAgICB9fVxuICAgICAgLz5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiQzovVXNlcnMvWWFzd2FudGggUmFodWwvRG93bmxvYWRzL0JpdExhYnMtQ29kaW5nLUxhYi9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9lZGl0b3IvQ29kZUVkaXRvci50c3gifQ==