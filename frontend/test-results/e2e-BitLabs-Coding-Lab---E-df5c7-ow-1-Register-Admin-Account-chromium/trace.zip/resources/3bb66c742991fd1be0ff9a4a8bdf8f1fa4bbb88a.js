import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "development", "PROD": false, "SSR": false};import axios from "/node_modules/.vite/deps/axios.js?v=1cbb189e";
const apiClient = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL ?? "http://localhost:8000/api/v1"
});
apiClient.interceptors.request.use((config) => {
  const token = window.localStorage.getItem("access_token") ?? window.localStorage.getItem("bitlabs_token");
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});
export default apiClient;

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNsaWVudC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgYXhpb3MgZnJvbSBcImF4aW9zXCI7XG5cbmNvbnN0IGFwaUNsaWVudCA9IGF4aW9zLmNyZWF0ZSh7XG4gIGJhc2VVUkw6IGltcG9ydC5tZXRhLmVudi5WSVRFX0FQSV9CQVNFX1VSTCA/PyBcImh0dHA6Ly9sb2NhbGhvc3Q6ODAwMC9hcGkvdjFcIlxufSk7XG5cbmFwaUNsaWVudC5pbnRlcmNlcHRvcnMucmVxdWVzdC51c2UoKGNvbmZpZykgPT4ge1xuICBjb25zdCB0b2tlbiA9XG4gICAgd2luZG93LmxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiYWNjZXNzX3Rva2VuXCIpID8/IHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImJpdGxhYnNfdG9rZW5cIik7XG5cbiAgaWYgKHRva2VuKSB7XG4gICAgY29uZmlnLmhlYWRlcnMuQXV0aG9yaXphdGlvbiA9IGBCZWFyZXIgJHt0b2tlbn1gO1xuICB9XG4gIHJldHVybiBjb25maWc7XG59KTtcblxuZXhwb3J0IGRlZmF1bHQgYXBpQ2xpZW50O1xuIl0sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLFdBQVc7QUFFbEIsTUFBTSxZQUFZLE1BQU0sT0FBTztBQUFBLEVBQzdCLFNBQVMsWUFBWSxJQUFJLHFCQUFxQjtBQUNoRCxDQUFDO0FBRUQsVUFBVSxhQUFhLFFBQVEsSUFBSSxDQUFDLFdBQVc7QUFDN0MsUUFBTSxRQUNKLE9BQU8sYUFBYSxRQUFRLGNBQWMsS0FBSyxPQUFPLGFBQWEsUUFBUSxlQUFlO0FBRTVGLE1BQUksT0FBTztBQUNULFdBQU8sUUFBUSxnQkFBZ0IsVUFBVSxLQUFLO0FBQUEsRUFDaEQ7QUFDQSxTQUFPO0FBQ1QsQ0FBQztBQUVELGVBQWU7IiwibmFtZXMiOltdfQ==