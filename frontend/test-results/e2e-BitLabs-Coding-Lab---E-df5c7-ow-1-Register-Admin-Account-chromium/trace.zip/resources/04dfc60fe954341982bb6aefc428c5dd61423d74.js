import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/AuthPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1cbb189e"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AuthPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=1cbb189e"; const useState = __vite__cjsImport3_react["useState"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=1cbb189e";
import toast from "/node_modules/.vite/deps/react-hot-toast.js?v=1cbb189e";
import { login, register, saveToken, getCurrentUser } from "/src/api/auth.ts";
import Button from "/src/components/ui/Button.tsx";
import Spinner from "/src/components/ui/Spinner.tsx";
export default function AuthPage() {
  _s();
  const navigate = useNavigate();
  const [mode, setMode] = useState("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [role, setRole] = useState("recruiter");
  const [loading, setLoading] = useState(false);
  const switchMode = () => {
    setMode((current) => current === "login" ? "register" : "login");
    setConfirmPassword("");
  };
  const handleSubmit = async (event) => {
    event.preventDefault();
    if (!email.trim() || !password.trim()) {
      toast.error("Email and password are required.");
      return;
    }
    if (mode === "register" && password !== confirmPassword) {
      toast.error("Passwords do not match.");
      return;
    }
    try {
      setLoading(true);
      if (mode === "register") {
        await register({ email: email.trim(), password, role });
        toast.success("Account created! Logging you in…");
      }
      const tokenResponse = await login(email.trim(), password);
      saveToken(tokenResponse.access_token);
      const profile = await getCurrentUser();
      toast.success("Signed in successfully.");
      if (profile.role.toLowerCase() === "candidate") {
        navigate("/candidate/dashboard");
      } else {
        navigate("/recruiter/dashboard");
      }
    } catch (error) {
      if (mode === "register") {
        toast.error("Registration failed — email may already be taken.");
      } else {
        toast.error("Invalid email or password.");
      }
    } finally {
      setLoading(false);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-screen items-center justify-center bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50", children: /* @__PURE__ */ jsxDEV("div", { className: "w-full max-w-md", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "mb-8 text-center", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-brand-600 to-indigo-600 shadow-lg shadow-brand-600/25", children: /* @__PURE__ */ jsxDEV("svg", { className: "h-7 w-7 text-white", fill: "none", viewBox: "0 0 24 24", strokeWidth: 2, stroke: "currentColor", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", d: "M17.25 6.75 22.5 12l-5.25 5.25m-10.5 0L1.5 12l5.25-5.25m7.5-3-4.5 16.5" }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AuthPage.tsx",
        lineNumber: 93,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AuthPage.tsx",
        lineNumber: 92,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AuthPage.tsx",
        lineNumber: 91,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold tracking-tight text-slate-900", children: "BitLabs Coding Lab" }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AuthPage.tsx",
        lineNumber: 96,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-slate-500", children: mode === "login" ? "Sign in to your account" : "Create a new account" }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AuthPage.tsx",
        lineNumber: 97,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AuthPage.tsx",
      lineNumber: 90,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "rounded-2xl border border-slate-200/80 bg-white p-8 shadow-xl shadow-slate-200/50", children: [
      /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, className: "space-y-5", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { htmlFor: "auth-email", className: "mb-1.5 block text-sm font-medium text-slate-700", children: "Email address" }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AuthPage.tsx",
            lineNumber: 107,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              id: "auth-email",
              type: "email",
              autoComplete: "email",
              value: email,
              onChange: (event) => setEmail(event.target.value),
              className: "w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-brand-500 focus:ring-2 focus:ring-brand-100",
              placeholder: "you@example.com",
              required: true
            },
            void 0,
            false,
            {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AuthPage.tsx",
              lineNumber: 110,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AuthPage.tsx",
          lineNumber: 106,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { htmlFor: "auth-password", className: "mb-1.5 block text-sm font-medium text-slate-700", children: "Password" }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AuthPage.tsx",
            lineNumber: 124,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              id: "auth-password",
              type: "password",
              autoComplete: mode === "login" ? "current-password" : "new-password",
              value: password,
              onChange: (event) => setPassword(event.target.value),
              className: "w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-brand-500 focus:ring-2 focus:ring-brand-100",
              placeholder: "••••••••",
              required: true
            },
            void 0,
            false,
            {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AuthPage.tsx",
              lineNumber: 127,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AuthPage.tsx",
          lineNumber: 123,
          columnNumber: 13
        }, this),
        mode === "register" && /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { htmlFor: "auth-confirm-password", className: "mb-1.5 block text-sm font-medium text-slate-700", children: "Confirm password" }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AuthPage.tsx",
              lineNumber: 143,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                id: "auth-confirm-password",
                type: "password",
                autoComplete: "new-password",
                value: confirmPassword,
                onChange: (event) => setConfirmPassword(event.target.value),
                className: "w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-brand-500 focus:ring-2 focus:ring-brand-100",
                placeholder: "••••••••",
                required: true
              },
              void 0,
              false,
              {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AuthPage.tsx",
                lineNumber: 146,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AuthPage.tsx",
            lineNumber: 142,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "mb-2 block text-sm font-medium text-slate-700", children: "I am a" }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AuthPage.tsx",
              lineNumber: 160,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-3", children: [
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: () => setRole("recruiter"),
                  className: `flex flex-col items-center gap-1.5 rounded-xl border-2 px-4 py-3.5 text-sm font-medium transition ${role === "recruiter" ? "border-brand-500 bg-brand-50 text-brand-700 shadow-sm" : "border-slate-200 bg-white text-slate-600 hover:border-slate-300"}`,
                  children: [
                    /* @__PURE__ */ jsxDEV("svg", { className: "h-5 w-5", fill: "none", viewBox: "0 0 24 24", strokeWidth: 1.5, stroke: "currentColor", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", d: "M20.25 14.15v4.25c0 1.094-.787 2.036-1.872 2.18-2.087.277-4.216.42-6.378.42s-4.291-.143-6.378-.42c-1.085-.144-1.872-1.086-1.872-2.18v-4.25m16.5 0a2.18 2.18 0 0 0 .75-1.661V8.706c0-1.081-.768-2.015-1.837-2.175a48.114 48.114 0 0 0-3.413-.387m4.5 8.006c-.194.165-.42.295-.673.38A23.978 23.978 0 0 1 12 15.75c-2.648 0-5.195-.429-7.577-1.22a2.016 2.016 0 0 1-.673-.38m0 0A2.18 2.18 0 0 1 3 12.489V8.706c0-1.081.768-2.015 1.837-2.175a48.111 48.111 0 0 1 3.413-.387m7.5 0V5.25A2.25 2.25 0 0 0 13.5 3h-3a2.25 2.25 0 0 0-2.25 2.25v.894m7.5 0a48.667 48.667 0 0 0-7.5 0" }, void 0, false, {
                      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AuthPage.tsx",
                      lineNumber: 172,
                      columnNumber: 25
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AuthPage.tsx",
                      lineNumber: 171,
                      columnNumber: 23
                    }, this),
                    "Recruiter"
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AuthPage.tsx",
                  lineNumber: 162,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: () => setRole("candidate"),
                  className: `flex flex-col items-center gap-1.5 rounded-xl border-2 px-4 py-3.5 text-sm font-medium transition ${role === "candidate" ? "border-brand-500 bg-brand-50 text-brand-700 shadow-sm" : "border-slate-200 bg-white text-slate-600 hover:border-slate-300"}`,
                  children: [
                    /* @__PURE__ */ jsxDEV("svg", { className: "h-5 w-5", fill: "none", viewBox: "0 0 24 24", strokeWidth: 1.5, stroke: "currentColor", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", d: "M4.26 10.147a60.438 60.438 0 0 0-.491 6.347A48.62 48.62 0 0 1 12 20.904a48.62 48.62 0 0 1 8.232-4.41 60.46 60.46 0 0 0-.491-6.347m-15.482 0a23.838 23.838 0 0 0-1.012 5.434 25.477 25.477 0 0 0 6.492-1.401m-5.48-4.033a23.88 23.88 0 0 1 3.135-6.397 4.495 4.495 0 0 1 3.01-2.008c1.558-.27 3.14-.27 4.698 0a4.495 4.495 0 0 1 3.01 2.008 23.88 23.88 0 0 1 3.135 6.397M12 3v.75" }, void 0, false, {
                      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AuthPage.tsx",
                      lineNumber: 186,
                      columnNumber: 25
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AuthPage.tsx",
                      lineNumber: 185,
                      columnNumber: 23
                    }, this),
                    "Candidate"
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AuthPage.tsx",
                  lineNumber: 176,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AuthPage.tsx",
              lineNumber: 161,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AuthPage.tsx",
            lineNumber: 159,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AuthPage.tsx",
          lineNumber: 141,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { type: "submit", className: "w-full py-2.5", disabled: loading, children: loading ? /* @__PURE__ */ jsxDEV(Spinner, { label: mode === "login" ? "Signing in" : "Creating account" }, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AuthPage.tsx",
          lineNumber: 198,
          columnNumber: 15
        }, this) : mode === "login" ? "Sign in" : "Create account" }, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AuthPage.tsx",
          lineNumber: 196,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AuthPage.tsx",
        lineNumber: 104,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-6 border-t border-slate-100 pt-5 text-center text-sm text-slate-500", children: [
        mode === "login" ? "Don't have an account?" : "Already have an account?",
        " ",
        /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: switchMode, className: "font-semibold text-brand-600 hover:text-brand-700 transition", children: mode === "login" ? "Create one" : "Sign in" }, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AuthPage.tsx",
          lineNumber: 210,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AuthPage.tsx",
        lineNumber: 208,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AuthPage.tsx",
      lineNumber: 103,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AuthPage.tsx",
    lineNumber: 88,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AuthPage.tsx",
    lineNumber: 87,
    columnNumber: 5
  }, this);
}
_s(AuthPage, "9xekDESlaXDO5iW1Cawhg+KlkRU=", false, function() {
  return [useNavigate];
});
_c = AuthPage;
var _c;
$RefreshReg$(_c, "AuthPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AuthPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/AuthPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUVjLFNBZ0RBLFVBaERBOzs7Ozs7Ozs7Ozs7Ozs7OztBQXpFZCxTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsbUJBQW1CO0FBQzVCLE9BQU9DLFdBQVc7QUFDbEIsU0FBU0MsT0FBT0MsVUFBVUMsV0FBV0Msc0JBQXNCO0FBQzNELE9BQU9DLFlBQVk7QUFDbkIsT0FBT0MsYUFBYTtBQUlwQix3QkFBd0JDLFdBQVc7QUFBQUMsS0FBQTtBQUNqQyxRQUFNQyxXQUFXVixZQUFZO0FBQzdCLFFBQU0sQ0FBQ1csTUFBTUMsT0FBTyxJQUFJYixTQUFtQixPQUFPO0FBQ2xELFFBQU0sQ0FBQ2MsT0FBT0MsUUFBUSxJQUFJZixTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDZ0IsVUFBVUMsV0FBVyxJQUFJakIsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQ2tCLGlCQUFpQkMsa0JBQWtCLElBQUluQixTQUFTLEVBQUU7QUFDekQsUUFBTSxDQUFDb0IsTUFBTUMsT0FBTyxJQUFJckIsU0FBb0MsV0FBVztBQUN2RSxRQUFNLENBQUNzQixTQUFTQyxVQUFVLElBQUl2QixTQUFTLEtBQUs7QUFFNUMsUUFBTXdCLGFBQWFBLE1BQU07QUFDdkJYLFlBQVEsQ0FBQ1ksWUFBYUEsWUFBWSxVQUFVLGFBQWEsT0FBUTtBQUNqRU4sdUJBQW1CLEVBQUU7QUFBQSxFQUN2QjtBQUVBLFFBQU1PLGVBQWUsT0FBT0MsVUFBMkI7QUFDckRBLFVBQU1DLGVBQWU7QUFFckIsUUFBSSxDQUFDZCxNQUFNZSxLQUFLLEtBQUssQ0FBQ2IsU0FBU2EsS0FBSyxHQUFHO0FBQ3JDM0IsWUFBTTRCLE1BQU0sa0NBQWtDO0FBQzlDO0FBQUEsSUFDRjtBQUVBLFFBQUlsQixTQUFTLGNBQWNJLGFBQWFFLGlCQUFpQjtBQUN2RGhCLFlBQU00QixNQUFNLHlCQUF5QjtBQUNyQztBQUFBLElBQ0Y7QUFFQSxRQUFJO0FBQ0ZQLGlCQUFXLElBQUk7QUFFZixVQUFJWCxTQUFTLFlBQVk7QUFDdkIsY0FBTVIsU0FBUyxFQUFFVSxPQUFPQSxNQUFNZSxLQUFLLEdBQUdiLFVBQVVJLEtBQUssQ0FBQztBQUN0RGxCLGNBQU02QixRQUFRLGtDQUFrQztBQUFBLE1BQ2xEO0FBRUEsWUFBTUMsZ0JBQWdCLE1BQU03QixNQUFNVyxNQUFNZSxLQUFLLEdBQUdiLFFBQVE7QUFDeERYLGdCQUFVMkIsY0FBY0MsWUFBWTtBQUVwQyxZQUFNQyxVQUFVLE1BQU01QixlQUFlO0FBQ3JDSixZQUFNNkIsUUFBUSx5QkFBeUI7QUFFdkMsVUFBSUcsUUFBUWQsS0FBS2UsWUFBWSxNQUFNLGFBQWE7QUFDOUN4QixpQkFBUyxzQkFBc0I7QUFBQSxNQUNqQyxPQUFPO0FBQ0xBLGlCQUFTLHNCQUFzQjtBQUFBLE1BQ2pDO0FBQUEsSUFDRixTQUFTbUIsT0FBTztBQUNkLFVBQUlsQixTQUFTLFlBQVk7QUFDdkJWLGNBQU00QixNQUFNLG1EQUFtRDtBQUFBLE1BQ2pFLE9BQU87QUFDTDVCLGNBQU00QixNQUFNLDRCQUE0QjtBQUFBLE1BQzFDO0FBQUEsSUFDRixVQUFDO0FBQ0NQLGlCQUFXLEtBQUs7QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSwwR0FDYixpQ0FBQyxTQUFJLFdBQVUsbUJBRWI7QUFBQSwyQkFBQyxTQUFJLFdBQVUsb0JBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsb0pBQ2IsaUNBQUMsU0FBSSxXQUFVLHNCQUFxQixNQUFLLFFBQU8sU0FBUSxhQUFZLGFBQWEsR0FBRyxRQUFPLGdCQUN6RixpQ0FBQyxVQUFLLGVBQWMsU0FBUSxnQkFBZSxTQUFRLEdBQUUsNEVBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkgsS0FEL0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlBO0FBQUEsTUFDQSx1QkFBQyxRQUFHLFdBQVUsb0RBQW1ELGtDQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1GO0FBQUEsTUFDbkYsdUJBQUMsT0FBRSxXQUFVLCtCQUNWWCxtQkFBUyxVQUFVLDRCQUE0QiwwQkFEbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBVUE7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSxxRkFDYjtBQUFBLDZCQUFDLFVBQUssVUFBVWMsY0FBYyxXQUFVLGFBRXRDO0FBQUEsK0JBQUMsU0FDQztBQUFBLGlDQUFDLFdBQU0sU0FBUSxjQUFhLFdBQVUsbURBQWlELDZCQUF2RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsSUFBRztBQUFBLGNBQ0gsTUFBSztBQUFBLGNBQ0wsY0FBYTtBQUFBLGNBQ2IsT0FBT1o7QUFBQUEsY0FDUCxVQUFVLENBQUNhLFVBQVVaLFNBQVNZLE1BQU1TLE9BQU9DLEtBQUs7QUFBQSxjQUNoRCxXQUFVO0FBQUEsY0FDVixhQUFZO0FBQUEsY0FDWixVQUFRO0FBQUE7QUFBQSxZQVJWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVFVO0FBQUEsYUFaWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBY0E7QUFBQSxRQUdBLHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxXQUFNLFNBQVEsaUJBQWdCLFdBQVUsbURBQWlELHdCQUExRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsSUFBRztBQUFBLGNBQ0gsTUFBSztBQUFBLGNBQ0wsY0FBY3pCLFNBQVMsVUFBVSxxQkFBcUI7QUFBQSxjQUN0RCxPQUFPSTtBQUFBQSxjQUNQLFVBQVUsQ0FBQ1csVUFBVVYsWUFBWVUsTUFBTVMsT0FBT0MsS0FBSztBQUFBLGNBQ25ELFdBQVU7QUFBQSxjQUNWLGFBQVk7QUFBQSxjQUNaLFVBQVE7QUFBQTtBQUFBLFlBUlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUVU7QUFBQSxhQVpaO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFjQTtBQUFBLFFBR0N6QixTQUFTLGNBQ1IsbUNBQ0U7QUFBQSxpQ0FBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxTQUFRLHlCQUF3QixXQUFVLG1EQUFpRCxnQ0FBbEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxJQUFHO0FBQUEsZ0JBQ0gsTUFBSztBQUFBLGdCQUNMLGNBQWE7QUFBQSxnQkFDYixPQUFPTTtBQUFBQSxnQkFDUCxVQUFVLENBQUNTLFVBQVVSLG1CQUFtQlEsTUFBTVMsT0FBT0MsS0FBSztBQUFBLGdCQUMxRCxXQUFVO0FBQUEsZ0JBQ1YsYUFBWTtBQUFBLGdCQUNaLFVBQVE7QUFBQTtBQUFBLGNBUlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUVU7QUFBQSxlQVpaO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBY0E7QUFBQSxVQUdBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsaURBQWdELHNCQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RTtBQUFBLFlBQ3ZFLHVCQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxTQUFTLE1BQU1oQixRQUFRLFdBQVc7QUFBQSxrQkFDbEMsV0FBVyxxR0FDVEQsU0FBUyxjQUNMLDBEQUNBLGlFQUFpRTtBQUFBLGtCQUd2RTtBQUFBLDJDQUFDLFNBQUksV0FBVSxXQUFVLE1BQUssUUFBTyxTQUFRLGFBQVksYUFBYSxLQUFLLFFBQU8sZ0JBQ2hGLGlDQUFDLFVBQUssZUFBYyxTQUFRLGdCQUFlLFNBQVEsR0FBRSxvakJBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXFtQixLQUR2bUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUFLO0FBQUE7QUFBQTtBQUFBLGdCQVhQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWFBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsU0FBUyxNQUFNQyxRQUFRLFdBQVc7QUFBQSxrQkFDbEMsV0FBVyxxR0FDVEQsU0FBUyxjQUNMLDBEQUNBLGlFQUFpRTtBQUFBLGtCQUd2RTtBQUFBLDJDQUFDLFNBQUksV0FBVSxXQUFVLE1BQUssUUFBTyxTQUFRLGFBQVksYUFBYSxLQUFLLFFBQU8sZ0JBQ2hGLGlDQUFDLFVBQUssZUFBYyxTQUFRLGdCQUFlLFNBQVEsR0FBRSx1WEFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBd2EsS0FEMWE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUFLO0FBQUE7QUFBQTtBQUFBLGdCQVhQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWFBO0FBQUEsaUJBNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNkJBO0FBQUEsZUEvQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnQ0E7QUFBQSxhQWxERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBbURBO0FBQUEsUUFJRix1QkFBQyxVQUFPLE1BQUssVUFBUyxXQUFVLGlCQUFnQixVQUFVRSxTQUN2REEsb0JBQ0MsdUJBQUMsV0FBUSxPQUFPVixTQUFTLFVBQVUsZUFBZSxzQkFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRSxJQUNuRUEsU0FBUyxVQUNYLFlBRUEsb0JBTko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsV0FwR0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXFHQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLDBFQUNaQTtBQUFBQSxpQkFBUyxVQUFVLDJCQUEyQjtBQUFBLFFBQTRCO0FBQUEsUUFDM0UsdUJBQUMsWUFBTyxNQUFLLFVBQVMsU0FBU1ksWUFBWSxXQUFVLGdFQUNsRFosbUJBQVMsVUFBVSxlQUFlLGFBRHJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsU0E5R0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQStHQTtBQUFBLE9BOUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0ErSEEsS0FoSUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWlJQTtBQUVKO0FBQUNGLEdBN0x1QkQsVUFBUTtBQUFBLFVBQ2JSLFdBQVc7QUFBQTtBQUFBLEtBRE5RO0FBQVEsSUFBQTZCO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlTmF2aWdhdGUiLCJ0b2FzdCIsImxvZ2luIiwicmVnaXN0ZXIiLCJzYXZlVG9rZW4iLCJnZXRDdXJyZW50VXNlciIsIkJ1dHRvbiIsIlNwaW5uZXIiLCJBdXRoUGFnZSIsIl9zIiwibmF2aWdhdGUiLCJtb2RlIiwic2V0TW9kZSIsImVtYWlsIiwic2V0RW1haWwiLCJwYXNzd29yZCIsInNldFBhc3N3b3JkIiwiY29uZmlybVBhc3N3b3JkIiwic2V0Q29uZmlybVBhc3N3b3JkIiwicm9sZSIsInNldFJvbGUiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsInN3aXRjaE1vZGUiLCJjdXJyZW50IiwiaGFuZGxlU3VibWl0IiwiZXZlbnQiLCJwcmV2ZW50RGVmYXVsdCIsInRyaW0iLCJlcnJvciIsInN1Y2Nlc3MiLCJ0b2tlblJlc3BvbnNlIiwiYWNjZXNzX3Rva2VuIiwicHJvZmlsZSIsInRvTG93ZXJDYXNlIiwidGFyZ2V0IiwidmFsdWUiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBdXRoUGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcbmltcG9ydCB0b2FzdCBmcm9tIFwicmVhY3QtaG90LXRvYXN0XCI7XG5pbXBvcnQgeyBsb2dpbiwgcmVnaXN0ZXIsIHNhdmVUb2tlbiwgZ2V0Q3VycmVudFVzZXIgfSBmcm9tIFwiLi4vYXBpL2F1dGhcIjtcbmltcG9ydCBCdXR0b24gZnJvbSBcIi4uL2NvbXBvbmVudHMvdWkvQnV0dG9uXCI7XG5pbXBvcnQgU3Bpbm5lciBmcm9tIFwiLi4vY29tcG9uZW50cy91aS9TcGlubmVyXCI7XG5cbnR5cGUgQXV0aE1vZGUgPSBcImxvZ2luXCIgfCBcInJlZ2lzdGVyXCI7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEF1dGhQYWdlKCkge1xuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gIGNvbnN0IFttb2RlLCBzZXRNb2RlXSA9IHVzZVN0YXRlPEF1dGhNb2RlPihcImxvZ2luXCIpO1xuICBjb25zdCBbZW1haWwsIHNldEVtYWlsXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbcGFzc3dvcmQsIHNldFBhc3N3b3JkXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbY29uZmlybVBhc3N3b3JkLCBzZXRDb25maXJtUGFzc3dvcmRdID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFtyb2xlLCBzZXRSb2xlXSA9IHVzZVN0YXRlPFwicmVjcnVpdGVyXCIgfCBcImNhbmRpZGF0ZVwiPihcInJlY3J1aXRlclwiKTtcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gIGNvbnN0IHN3aXRjaE1vZGUgPSAoKSA9PiB7XG4gICAgc2V0TW9kZSgoY3VycmVudCkgPT4gKGN1cnJlbnQgPT09IFwibG9naW5cIiA/IFwicmVnaXN0ZXJcIiA6IFwibG9naW5cIikpO1xuICAgIHNldENvbmZpcm1QYXNzd29yZChcIlwiKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVTdWJtaXQgPSBhc3luYyAoZXZlbnQ6IFJlYWN0LkZvcm1FdmVudCkgPT4ge1xuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG5cbiAgICBpZiAoIWVtYWlsLnRyaW0oKSB8fCAhcGFzc3dvcmQudHJpbSgpKSB7XG4gICAgICB0b2FzdC5lcnJvcihcIkVtYWlsIGFuZCBwYXNzd29yZCBhcmUgcmVxdWlyZWQuXCIpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGlmIChtb2RlID09PSBcInJlZ2lzdGVyXCIgJiYgcGFzc3dvcmQgIT09IGNvbmZpcm1QYXNzd29yZCkge1xuICAgICAgdG9hc3QuZXJyb3IoXCJQYXNzd29yZHMgZG8gbm90IG1hdGNoLlwiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICB0cnkge1xuICAgICAgc2V0TG9hZGluZyh0cnVlKTtcblxuICAgICAgaWYgKG1vZGUgPT09IFwicmVnaXN0ZXJcIikge1xuICAgICAgICBhd2FpdCByZWdpc3Rlcih7IGVtYWlsOiBlbWFpbC50cmltKCksIHBhc3N3b3JkLCByb2xlIH0pO1xuICAgICAgICB0b2FzdC5zdWNjZXNzKFwiQWNjb3VudCBjcmVhdGVkISBMb2dnaW5nIHlvdSBpbuKAplwiKTtcbiAgICAgIH1cblxuICAgICAgY29uc3QgdG9rZW5SZXNwb25zZSA9IGF3YWl0IGxvZ2luKGVtYWlsLnRyaW0oKSwgcGFzc3dvcmQpO1xuICAgICAgc2F2ZVRva2VuKHRva2VuUmVzcG9uc2UuYWNjZXNzX3Rva2VuKTtcbiAgICAgIFxuICAgICAgY29uc3QgcHJvZmlsZSA9IGF3YWl0IGdldEN1cnJlbnRVc2VyKCk7XG4gICAgICB0b2FzdC5zdWNjZXNzKFwiU2lnbmVkIGluIHN1Y2Nlc3NmdWxseS5cIik7XG5cbiAgICAgIGlmIChwcm9maWxlLnJvbGUudG9Mb3dlckNhc2UoKSA9PT0gXCJjYW5kaWRhdGVcIikge1xuICAgICAgICBuYXZpZ2F0ZShcIi9jYW5kaWRhdGUvZGFzaGJvYXJkXCIpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgbmF2aWdhdGUoXCIvcmVjcnVpdGVyL2Rhc2hib2FyZFwiKTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgaWYgKG1vZGUgPT09IFwicmVnaXN0ZXJcIikge1xuICAgICAgICB0b2FzdC5lcnJvcihcIlJlZ2lzdHJhdGlvbiBmYWlsZWQg4oCUIGVtYWlsIG1heSBhbHJlYWR5IGJlIHRha2VuLlwiKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRvYXN0LmVycm9yKFwiSW52YWxpZCBlbWFpbCBvciBwYXNzd29yZC5cIik7XG4gICAgICB9XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtaW4taC1zY3JlZW4gaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJnLWdyYWRpZW50LXRvLWJyIGZyb20tc2xhdGUtNTAgdmlhLWJsdWUtNTAgdG8taW5kaWdvLTUwXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBtYXgtdy1tZFwiPlxuICAgICAgICB7LyogTG9nbyAvIEJyYW5kaW5nICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTggdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm14LWF1dG8gbWItNCBmbGV4IGgtMTQgdy0xNCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC0yeGwgYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1icmFuZC02MDAgdG8taW5kaWdvLTYwMCBzaGFkb3ctbGcgc2hhZG93LWJyYW5kLTYwMC8yNVwiPlxuICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJoLTcgdy03IHRleHQtd2hpdGVcIiBmaWxsPVwibm9uZVwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBzdHJva2VXaWR0aD17Mn0gc3Ryb2tlPVwiY3VycmVudENvbG9yXCI+XG4gICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBkPVwiTTE3LjI1IDYuNzUgMjIuNSAxMmwtNS4yNSA1LjI1bS0xMC41IDBMMS41IDEybDUuMjUtNS4yNW03LjUtMy00LjUgMTYuNVwiIC8+XG4gICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtc2xhdGUtOTAwXCI+Qml0TGFicyBDb2RpbmcgTGFiPC9oMT5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgICAgIHttb2RlID09PSBcImxvZ2luXCIgPyBcIlNpZ24gaW4gdG8geW91ciBhY2NvdW50XCIgOiBcIkNyZWF0ZSBhIG5ldyBhY2NvdW50XCJ9XG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogQ2FyZCAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMC84MCBiZy13aGl0ZSBwLTggc2hhZG93LXhsIHNoYWRvdy1zbGF0ZS0yMDAvNTBcIj5cbiAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0fSBjbGFzc05hbWU9XCJzcGFjZS15LTVcIj5cbiAgICAgICAgICAgIHsvKiBFbWFpbCAqL31cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwiYXV0aC1lbWFpbFwiIGNsYXNzTmFtZT1cIm1iLTEuNSBibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNzAwXCI+XG4gICAgICAgICAgICAgICAgRW1haWwgYWRkcmVzc1xuICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICBpZD1cImF1dGgtZW1haWxcIlxuICAgICAgICAgICAgICAgIHR5cGU9XCJlbWFpbFwiXG4gICAgICAgICAgICAgICAgYXV0b0NvbXBsZXRlPVwiZW1haWxcIlxuICAgICAgICAgICAgICAgIHZhbHVlPXtlbWFpbH1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXRFbWFpbChldmVudC50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItc2xhdGUtMzAwIGJnLXdoaXRlIHB4LTMuNSBweS0yLjUgdGV4dC1zbSB0ZXh0LXNsYXRlLTkwMCBvdXRsaW5lLW5vbmUgdHJhbnNpdGlvbiBwbGFjZWhvbGRlcjp0ZXh0LXNsYXRlLTQwMCBmb2N1czpib3JkZXItYnJhbmQtNTAwIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJyYW5kLTEwMFwiXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJ5b3VAZXhhbXBsZS5jb21cIlxuICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIFBhc3N3b3JkICovfVxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJhdXRoLXBhc3N3b3JkXCIgY2xhc3NOYW1lPVwibWItMS41IGJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS03MDBcIj5cbiAgICAgICAgICAgICAgICBQYXNzd29yZFxuICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICBpZD1cImF1dGgtcGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgIHR5cGU9XCJwYXNzd29yZFwiXG4gICAgICAgICAgICAgICAgYXV0b0NvbXBsZXRlPXttb2RlID09PSBcImxvZ2luXCIgPyBcImN1cnJlbnQtcGFzc3dvcmRcIiA6IFwibmV3LXBhc3N3b3JkXCJ9XG4gICAgICAgICAgICAgICAgdmFsdWU9e3Bhc3N3b3JkfVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldFBhc3N3b3JkKGV2ZW50LnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS0zMDAgYmctd2hpdGUgcHgtMy41IHB5LTIuNSB0ZXh0LXNtIHRleHQtc2xhdGUtOTAwIG91dGxpbmUtbm9uZSB0cmFuc2l0aW9uIHBsYWNlaG9sZGVyOnRleHQtc2xhdGUtNDAwIGZvY3VzOmJvcmRlci1icmFuZC01MDAgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYnJhbmQtMTAwXCJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIuKAouKAouKAouKAouKAouKAouKAouKAolwiXG4gICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogQ29uZmlybSBQYXNzd29yZCAocmVnaXN0ZXIgb25seSkgKi99XG4gICAgICAgICAgICB7bW9kZSA9PT0gXCJyZWdpc3RlclwiICYmIChcbiAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJhdXRoLWNvbmZpcm0tcGFzc3dvcmRcIiBjbGFzc05hbWU9XCJtYi0xLjUgYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTcwMFwiPlxuICAgICAgICAgICAgICAgICAgICBDb25maXJtIHBhc3N3b3JkXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIGlkPVwiYXV0aC1jb25maXJtLXBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgICAgICAgYXV0b0NvbXBsZXRlPVwibmV3LXBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2NvbmZpcm1QYXNzd29yZH1cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0Q29uZmlybVBhc3N3b3JkKGV2ZW50LnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItc2xhdGUtMzAwIGJnLXdoaXRlIHB4LTMuNSBweS0yLjUgdGV4dC1zbSB0ZXh0LXNsYXRlLTkwMCBvdXRsaW5lLW5vbmUgdHJhbnNpdGlvbiBwbGFjZWhvbGRlcjp0ZXh0LXNsYXRlLTQwMCBmb2N1czpib3JkZXItYnJhbmQtNTAwIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJyYW5kLTEwMFwiXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwi4oCi4oCi4oCi4oCi4oCi4oCi4oCi4oCiXCJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICB7LyogUm9sZSAqL31cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cIm1iLTIgYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTcwMFwiPkkgYW0gYTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFJvbGUoXCJyZWNydWl0ZXJcIil9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSByb3VuZGVkLXhsIGJvcmRlci0yIHB4LTQgcHktMy41IHRleHQtc20gZm9udC1tZWRpdW0gdHJhbnNpdGlvbiAke1xuICAgICAgICAgICAgICAgICAgICAgICAgcm9sZSA9PT0gXCJyZWNydWl0ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiYm9yZGVyLWJyYW5kLTUwMCBiZy1icmFuZC01MCB0ZXh0LWJyYW5kLTcwMCBzaGFkb3ctc21cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiYm9yZGVyLXNsYXRlLTIwMCBiZy13aGl0ZSB0ZXh0LXNsYXRlLTYwMCBob3Zlcjpib3JkZXItc2xhdGUtMzAwXCJcbiAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwiaC01IHctNVwiIGZpbGw9XCJub25lXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIHN0cm9rZVdpZHRoPXsxLjV9IHN0cm9rZT1cImN1cnJlbnRDb2xvclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIGQ9XCJNMjAuMjUgMTQuMTV2NC4yNWMwIDEuMDk0LS43ODcgMi4wMzYtMS44NzIgMi4xOC0yLjA4Ny4yNzctNC4yMTYuNDItNi4zNzguNDJzLTQuMjkxLS4xNDMtNi4zNzgtLjQyYy0xLjA4NS0uMTQ0LTEuODcyLTEuMDg2LTEuODcyLTIuMTh2LTQuMjVtMTYuNSAwYTIuMTggMi4xOCAwIDAgMCAuNzUtMS42NjFWOC43MDZjMC0xLjA4MS0uNzY4LTIuMDE1LTEuODM3LTIuMTc1YTQ4LjExNCA0OC4xMTQgMCAwIDAtMy40MTMtLjM4N200LjUgOC4wMDZjLS4xOTQuMTY1LS40Mi4yOTUtLjY3My4zOEEyMy45NzggMjMuOTc4IDAgMCAxIDEyIDE1Ljc1Yy0yLjY0OCAwLTUuMTk1LS40MjktNy41NzctMS4yMmEyLjAxNiAyLjAxNiAwIDAgMS0uNjczLS4zOG0wIDBBMi4xOCAyLjE4IDAgMCAxIDMgMTIuNDg5VjguNzA2YzAtMS4wODEuNzY4LTIuMDE1IDEuODM3LTIuMTc1YTQ4LjExMSA0OC4xMTEgMCAwIDEgMy40MTMtLjM4N203LjUgMFY1LjI1QTIuMjUgMi4yNSAwIDAgMCAxMy41IDNoLTNhMi4yNSAyLjI1IDAgMCAwLTIuMjUgMi4yNXYuODk0bTcuNSAwYTQ4LjY2NyA0OC42NjcgMCAwIDAtNy41IDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDwvc3ZnPlxuICAgICAgICAgICAgICAgICAgICAgIFJlY3J1aXRlclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFJvbGUoXCJjYW5kaWRhdGVcIil9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSByb3VuZGVkLXhsIGJvcmRlci0yIHB4LTQgcHktMy41IHRleHQtc20gZm9udC1tZWRpdW0gdHJhbnNpdGlvbiAke1xuICAgICAgICAgICAgICAgICAgICAgICAgcm9sZSA9PT0gXCJjYW5kaWRhdGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiYm9yZGVyLWJyYW5kLTUwMCBiZy1icmFuZC01MCB0ZXh0LWJyYW5kLTcwMCBzaGFkb3ctc21cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiYm9yZGVyLXNsYXRlLTIwMCBiZy13aGl0ZSB0ZXh0LXNsYXRlLTYwMCBob3Zlcjpib3JkZXItc2xhdGUtMzAwXCJcbiAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwiaC01IHctNVwiIGZpbGw9XCJub25lXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIHN0cm9rZVdpZHRoPXsxLjV9IHN0cm9rZT1cImN1cnJlbnRDb2xvclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIGQ9XCJNNC4yNiAxMC4xNDdhNjAuNDM4IDYwLjQzOCAwIDAgMC0uNDkxIDYuMzQ3QTQ4LjYyIDQ4LjYyIDAgMCAxIDEyIDIwLjkwNGE0OC42MiA0OC42MiAwIDAgMSA4LjIzMi00LjQxIDYwLjQ2IDYwLjQ2IDAgMCAwLS40OTEtNi4zNDdtLTE1LjQ4MiAwYTIzLjgzOCAyMy44MzggMCAwIDAtMS4wMTIgNS40MzQgMjUuNDc3IDI1LjQ3NyAwIDAgMCA2LjQ5Mi0xLjQwMW0tNS40OC00LjAzM2EyMy44OCAyMy44OCAwIDAgMSAzLjEzNS02LjM5NyA0LjQ5NSA0LjQ5NSAwIDAgMSAzLjAxLTIuMDA4YzEuNTU4LS4yNyAzLjE0LS4yNyA0LjY5OCAwYTQuNDk1IDQuNDk1IDAgMCAxIDMuMDEgMi4wMDggMjMuODggMjMuODggMCAwIDEgMy4xMzUgNi4zOTdNMTIgM3YuNzVcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDwvc3ZnPlxuICAgICAgICAgICAgICAgICAgICAgIENhbmRpZGF0ZVxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIHsvKiBTdWJtaXQgKi99XG4gICAgICAgICAgICA8QnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBjbGFzc05hbWU9XCJ3LWZ1bGwgcHktMi41XCIgZGlzYWJsZWQ9e2xvYWRpbmd9PlxuICAgICAgICAgICAgICB7bG9hZGluZyA/IChcbiAgICAgICAgICAgICAgICA8U3Bpbm5lciBsYWJlbD17bW9kZSA9PT0gXCJsb2dpblwiID8gXCJTaWduaW5nIGluXCIgOiBcIkNyZWF0aW5nIGFjY291bnRcIn0gLz5cbiAgICAgICAgICAgICAgKSA6IG1vZGUgPT09IFwibG9naW5cIiA/IChcbiAgICAgICAgICAgICAgICBcIlNpZ24gaW5cIlxuICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgIFwiQ3JlYXRlIGFjY291bnRcIlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgPC9mb3JtPlxuXG4gICAgICAgICAgey8qIFRvZ2dsZSAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTEwMCBwdC01IHRleHQtY2VudGVyIHRleHQtc20gdGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgICAgIHttb2RlID09PSBcImxvZ2luXCIgPyBcIkRvbid0IGhhdmUgYW4gYWNjb3VudD9cIiA6IFwiQWxyZWFkeSBoYXZlIGFuIGFjY291bnQ/XCJ9e1wiIFwifVxuICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17c3dpdGNoTW9kZX0gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWJyYW5kLTYwMCBob3Zlcjp0ZXh0LWJyYW5kLTcwMCB0cmFuc2l0aW9uXCI+XG4gICAgICAgICAgICAgIHttb2RlID09PSBcImxvZ2luXCIgPyBcIkNyZWF0ZSBvbmVcIiA6IFwiU2lnbiBpblwifVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6IkM6L1VzZXJzL1lhc3dhbnRoIFJhaHVsL0Rvd25sb2Fkcy9CaXRMYWJzLUNvZGluZy1MYWIvZnJvbnRlbmQvc3JjL3JvdXRlcy9BdXRoUGFnZS50c3gifQ==