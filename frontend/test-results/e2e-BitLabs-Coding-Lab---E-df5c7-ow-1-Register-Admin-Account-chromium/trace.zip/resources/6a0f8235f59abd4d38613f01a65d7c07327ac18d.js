import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/editor/LanguageSelector.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1cbb189e"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/components/editor/LanguageSelector.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { languageLabels } from "/src/constants/templates.ts";
const languages = Object.keys(languageLabels).filter((l) => l !== "swift");
export default function LanguageSelector({ value, onChange }) {
  return /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 text-sm font-medium text-slate-700", children: [
    "Language",
    /* @__PURE__ */ jsxDEV(
      "select",
      {
        className: "rounded-md border border-indigo-700 bg-indigo-800 text-white px-3 py-2 text-sm shadow-sm outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100",
        value,
        onChange: (event) => onChange(event.target.value),
        children: languages.map(
          (language) => /* @__PURE__ */ jsxDEV("option", { value: language, children: languageLabels[language] }, language, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/components/editor/LanguageSelector.tsx",
            lineNumber: 40,
            columnNumber: 9
          }, this)
        )
      },
      void 0,
      false,
      {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/components/editor/LanguageSelector.tsx",
        lineNumber: 34,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/components/editor/LanguageSelector.tsx",
    lineNumber: 32,
    columnNumber: 5
  }, this);
}
_c = LanguageSelector;
var _c;
$RefreshReg$(_c, "LanguageSelector");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/components/editor/LanguageSelector.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/components/editor/LanguageSelector.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0JVOzs7Ozs7Ozs7Ozs7Ozs7O0FBcEJWLFNBQVNBLHNCQUF5QztBQU9sRCxNQUFNQyxZQUFZQyxPQUFPQyxLQUFLSCxjQUFjLEVBQUVJLE9BQU8sQ0FBQUMsTUFBS0EsTUFBTSxPQUFPO0FBR3ZFLHdCQUF3QkMsaUJBQWlCLEVBQUVDLE9BQU9DLFNBQWdDLEdBQUc7QUFDbkYsU0FDRSx1QkFBQyxXQUFNLFdBQVUsOERBQTREO0FBQUE7QUFBQSxJQUUzRTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBVTtBQUFBLFFBQ1Y7QUFBQSxRQUNBLFVBQVUsQ0FBQ0MsVUFBVUQsU0FBU0MsTUFBTUMsT0FBT0gsS0FBMEI7QUFBQSxRQUVwRU4sb0JBQVVVO0FBQUFBLFVBQUksQ0FBQ0MsYUFDZCx1QkFBQyxZQUFzQixPQUFPQSxVQUMzQloseUJBQWVZLFFBQVEsS0FEYkEsVUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsUUFDRDtBQUFBO0FBQUEsTUFUSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFVQTtBQUFBLE9BWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWFBO0FBRUo7QUFBQ0MsS0FqQnVCUDtBQUFnQixJQUFBTztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJsYW5ndWFnZUxhYmVscyIsImxhbmd1YWdlcyIsIk9iamVjdCIsImtleXMiLCJmaWx0ZXIiLCJsIiwiTGFuZ3VhZ2VTZWxlY3RvciIsInZhbHVlIiwib25DaGFuZ2UiLCJldmVudCIsInRhcmdldCIsIm1hcCIsImxhbmd1YWdlIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTGFuZ3VhZ2VTZWxlY3Rvci50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgbGFuZ3VhZ2VMYWJlbHMsIFN1cHBvcnRlZExhbmd1YWdlIH0gZnJvbSBcIi4uLy4uL2NvbnN0YW50cy90ZW1wbGF0ZXNcIjtcblxudHlwZSBMYW5ndWFnZVNlbGVjdG9yUHJvcHMgPSB7XG4gIHZhbHVlOiBTdXBwb3J0ZWRMYW5ndWFnZTtcbiAgb25DaGFuZ2U6IChsYW5ndWFnZTogU3VwcG9ydGVkTGFuZ3VhZ2UpID0+IHZvaWQ7XG59O1xuXG5jb25zdCBsYW5ndWFnZXMgPSBPYmplY3Qua2V5cyhsYW5ndWFnZUxhYmVscykuZmlsdGVyKGwgPT4gbCAhPT0gXCJzd2lmdFwiKSBhcyBTdXBwb3J0ZWRMYW5ndWFnZVtdO1xuXG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIExhbmd1YWdlU2VsZWN0b3IoeyB2YWx1ZSwgb25DaGFuZ2UgfTogTGFuZ3VhZ2VTZWxlY3RvclByb3BzKSB7XG4gIHJldHVybiAoXG4gICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS03MDBcIj5cbiAgICAgIExhbmd1YWdlXG4gICAgICA8c2VsZWN0XG4gICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1pbmRpZ28tNzAwIGJnLWluZGlnby04MDAgdGV4dC13aGl0ZSBweC0zIHB5LTIgdGV4dC1zbSBzaGFkb3ctc20gb3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1pbmRpZ28tNTAwIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWluZGlnby0xMDBcIlxuICAgICAgICB2YWx1ZT17dmFsdWV9XG4gICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+IG9uQ2hhbmdlKGV2ZW50LnRhcmdldC52YWx1ZSBhcyBTdXBwb3J0ZWRMYW5ndWFnZSl9XG4gICAgICA+XG4gICAgICAgIHtsYW5ndWFnZXMubWFwKChsYW5ndWFnZSkgPT4gKFxuICAgICAgICAgIDxvcHRpb24ga2V5PXtsYW5ndWFnZX0gdmFsdWU9e2xhbmd1YWdlfT5cbiAgICAgICAgICAgIHtsYW5ndWFnZUxhYmVsc1tsYW5ndWFnZV19XG4gICAgICAgICAgPC9vcHRpb24+XG4gICAgICAgICkpfVxuICAgICAgPC9zZWxlY3Q+XG4gICAgPC9sYWJlbD5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiQzovVXNlcnMvWWFzd2FudGggUmFodWwvRG93bmxvYWRzL0JpdExhYnMtQ29kaW5nLUxhYi9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9lZGl0b3IvTGFuZ3VhZ2VTZWxlY3Rvci50c3gifQ==