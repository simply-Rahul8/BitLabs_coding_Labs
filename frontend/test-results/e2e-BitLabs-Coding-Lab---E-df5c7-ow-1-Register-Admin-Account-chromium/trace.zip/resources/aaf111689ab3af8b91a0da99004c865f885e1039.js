import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1cbb189e"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/App.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=1cbb189e"; const useCallback = __vite__cjsImport3_react["useCallback"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { Navigate, Route, Routes, useLocation, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=1cbb189e";
import { clearToken, getCurrentUser, getStoredToken } from "/src/api/auth.ts";
import Navbar from "/src/components/layout/Navbar.tsx";
import Sidebar from "/src/components/layout/Sidebar.tsx";
import Spinner from "/src/components/ui/Spinner.tsx";
import AssessmentBuilder from "/src/routes/AssessmentBuilder.tsx";
import AuthPage from "/src/routes/AuthPage.tsx";
import CandidateDashboard from "/src/routes/CandidateDashboard.tsx";
import PracticeArena from "/src/routes/PracticeArena.tsx";
import RecruiterDashboard from "/src/routes/RecruiterDashboard.tsx";
import TakeAssessment from "/src/routes/TakeAssessment.tsx?t=1786684172893";
export default function App() {
  _s();
  const location = useLocation();
  const navigate = useNavigate();
  const isTakeAssessment = location.pathname.startsWith("/assessment/");
  const [token, setToken] = useState(getStoredToken());
  const [user, setUser] = useState(null);
  const [loadingProfile, setLoadingProfile] = useState(!!getStoredToken());
  const syncAuth = useCallback(() => {
    const currentToken = getStoredToken();
    setToken(currentToken);
    if (currentToken) {
      setLoadingProfile(true);
      getCurrentUser().then((userData) => {
        setUser(userData);
      }).catch(() => {
        clearToken();
        setToken(null);
        setUser(null);
      }).finally(() => setLoadingProfile(false));
    } else {
      setUser(null);
      setLoadingProfile(false);
    }
  }, []);
  useEffect(() => {
    syncAuth();
  }, [location.pathname, syncAuth]);
  const handleLogout = useCallback(() => {
    clearToken();
    setToken(null);
    setUser(null);
    navigate("/auth");
  }, [navigate]);
  if (isTakeAssessment) {
    return /* @__PURE__ */ jsxDEV(Routes, { children: /* @__PURE__ */ jsxDEV(Route, { path: "/assessment/:token", element: /* @__PURE__ */ jsxDEV(TakeAssessment, {}, void 0, false, {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/App.tsx",
      lineNumber: 79,
      columnNumber: 51
    }, this) }, void 0, false, {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/App.tsx",
      lineNumber: 79,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/App.tsx",
      lineNumber: 78,
      columnNumber: 7
    }, this);
  }
  if (!token) {
    return /* @__PURE__ */ jsxDEV(Routes, { children: [
      /* @__PURE__ */ jsxDEV(Route, { path: "/auth", element: /* @__PURE__ */ jsxDEV(AuthPage, {}, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/App.tsx",
        lineNumber: 88,
        columnNumber: 38
      }, this) }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/App.tsx",
        lineNumber: 88,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "*", element: /* @__PURE__ */ jsxDEV(Navigate, { to: "/auth", replace: true }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/App.tsx",
        lineNumber: 89,
        columnNumber: 34
      }, this) }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/App.tsx",
        lineNumber: 89,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/App.tsx",
      lineNumber: 87,
      columnNumber: 7
    }, this);
  }
  if (loadingProfile) {
    return /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-screen items-center justify-center bg-slate-50", children: /* @__PURE__ */ jsxDEV(Spinner, { label: "Loading workspace..." }, void 0, false, {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/App.tsx",
      lineNumber: 98,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/App.tsx",
      lineNumber: 97,
      columnNumber: 7
    }, this);
  }
  const role = (user?.role || "candidate").toLowerCase();
  return /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen bg-slate-50", children: [
    /* @__PURE__ */ jsxDEV(Navbar, { role, email: user?.email, onLogout: handleLogout }, void 0, false, {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/App.tsx",
      lineNumber: 108,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex", children: [
      /* @__PURE__ */ jsxDEV(Sidebar, { role }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/App.tsx",
        lineNumber: 110,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("main", { className: "min-w-0 flex-1 px-6 py-6", children: /* @__PURE__ */ jsxDEV(Routes, { children: role === "candidate" ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(Route, { path: "/candidate/dashboard", element: /* @__PURE__ */ jsxDEV(CandidateDashboard, {}, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/App.tsx",
          lineNumber: 115,
          columnNumber: 61
        }, this) }, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/App.tsx",
          lineNumber: 115,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(Route, { path: "/practice", element: /* @__PURE__ */ jsxDEV(PracticeArena, {}, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/App.tsx",
          lineNumber: 116,
          columnNumber: 50
        }, this) }, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/App.tsx",
          lineNumber: 116,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(Route, { path: "*", element: /* @__PURE__ */ jsxDEV(Navigate, { to: "/candidate/dashboard", replace: true }, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/App.tsx",
          lineNumber: 117,
          columnNumber: 42
        }, this) }, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/App.tsx",
          lineNumber: 117,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/App.tsx",
        lineNumber: 114,
        columnNumber: 13
      }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(Route, { path: "/recruiter/dashboard", element: /* @__PURE__ */ jsxDEV(RecruiterDashboard, {}, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/App.tsx",
          lineNumber: 121,
          columnNumber: 61
        }, this) }, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/App.tsx",
          lineNumber: 121,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(Route, { path: "/recruiter/assessments/new", element: /* @__PURE__ */ jsxDEV(AssessmentBuilder, {}, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/App.tsx",
          lineNumber: 122,
          columnNumber: 67
        }, this) }, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/App.tsx",
          lineNumber: 122,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(Route, { path: "/practice", element: /* @__PURE__ */ jsxDEV(PracticeArena, {}, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/App.tsx",
          lineNumber: 123,
          columnNumber: 50
        }, this) }, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/App.tsx",
          lineNumber: 123,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(Route, { path: "/candidate/dashboard", element: /* @__PURE__ */ jsxDEV(CandidateDashboard, {}, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/App.tsx",
          lineNumber: 124,
          columnNumber: 61
        }, this) }, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/App.tsx",
          lineNumber: 124,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(Route, { path: "*", element: /* @__PURE__ */ jsxDEV(Navigate, { to: "/recruiter/dashboard", replace: true }, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/App.tsx",
          lineNumber: 125,
          columnNumber: 42
        }, this) }, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/App.tsx",
          lineNumber: 125,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/App.tsx",
        lineNumber: 120,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/App.tsx",
        lineNumber: 112,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/App.tsx",
        lineNumber: 111,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/App.tsx",
      lineNumber: 109,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/App.tsx",
    lineNumber: 107,
    columnNumber: 5
  }, this);
}
_s(App, "9rzsQaMitN1ns12azXRbUnB7FhE=", false, function() {
  return [useLocation, useNavigate];
});
_c = App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/App.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkRrRCxTQW1DcEMsVUFuQ29DOzs7Ozs7Ozs7Ozs7Ozs7OztBQTNEbEQsU0FBU0EsYUFBYUMsV0FBV0MsZ0JBQWdCO0FBQ2pELFNBQVNDLFVBQVVDLE9BQU9DLFFBQVFDLGFBQWFDLG1CQUFtQjtBQUNsRSxTQUFTQyxZQUFZQyxnQkFBZ0JDLHNCQUFvQztBQUN6RSxPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsYUFBYTtBQUNwQixPQUFPQyx1QkFBdUI7QUFDOUIsT0FBT0MsY0FBYztBQUNyQixPQUFPQyx3QkFBd0I7QUFDL0IsT0FBT0MsbUJBQW1CO0FBQzFCLE9BQU9DLHdCQUF3QjtBQUMvQixPQUFPQyxvQkFBb0I7QUFFM0Isd0JBQXdCQyxNQUFNO0FBQUFDLEtBQUE7QUFDNUIsUUFBTUMsV0FBV2hCLFlBQVk7QUFDN0IsUUFBTWlCLFdBQVdoQixZQUFZO0FBQzdCLFFBQU1pQixtQkFBbUJGLFNBQVNHLFNBQVNDLFdBQVcsY0FBYztBQUVwRSxRQUFNLENBQUNDLE9BQU9DLFFBQVEsSUFBSTFCLFNBQXdCUSxlQUFlLENBQUM7QUFDbEUsUUFBTSxDQUFDbUIsTUFBTUMsT0FBTyxJQUFJNUIsU0FBeUIsSUFBSTtBQUNyRCxRQUFNLENBQUM2QixnQkFBZ0JDLGlCQUFpQixJQUFJOUIsU0FBa0IsQ0FBQyxDQUFDUSxlQUFlLENBQUM7QUFHaEYsUUFBTXVCLFdBQVdqQyxZQUFZLE1BQU07QUFDakMsVUFBTWtDLGVBQWV4QixlQUFlO0FBQ3BDa0IsYUFBU00sWUFBWTtBQUNyQixRQUFJQSxjQUFjO0FBQ2hCRix3QkFBa0IsSUFBSTtBQUN0QnZCLHFCQUFlLEVBQ1owQixLQUFLLENBQUNDLGFBQWE7QUFDbEJOLGdCQUFRTSxRQUFRO0FBQUEsTUFDbEIsQ0FBQyxFQUNBQyxNQUFNLE1BQU07QUFDWDdCLG1CQUFXO0FBQ1hvQixpQkFBUyxJQUFJO0FBQ2JFLGdCQUFRLElBQUk7QUFBQSxNQUNkLENBQUMsRUFDQVEsUUFBUSxNQUFNTixrQkFBa0IsS0FBSyxDQUFDO0FBQUEsSUFDM0MsT0FBTztBQUNMRixjQUFRLElBQUk7QUFDWkUsd0JBQWtCLEtBQUs7QUFBQSxJQUN6QjtBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBRUwvQixZQUFVLE1BQU07QUFDZGdDLGFBQVM7QUFBQSxFQUNYLEdBQUcsQ0FBQ1gsU0FBU0csVUFBVVEsUUFBUSxDQUFDO0FBRWhDLFFBQU1NLGVBQWV2QyxZQUFZLE1BQU07QUFDckNRLGVBQVc7QUFDWG9CLGFBQVMsSUFBSTtBQUNiRSxZQUFRLElBQUk7QUFDWlAsYUFBUyxPQUFPO0FBQUEsRUFDbEIsR0FBRyxDQUFDQSxRQUFRLENBQUM7QUFHYixNQUFJQyxrQkFBa0I7QUFDcEIsV0FDRSx1QkFBQyxVQUNDLGlDQUFDLFNBQU0sTUFBSyxzQkFBcUIsU0FBUyx1QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWUsS0FBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2RCxLQUQvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBR0EsTUFBSSxDQUFDRyxPQUFPO0FBQ1YsV0FDRSx1QkFBQyxVQUNDO0FBQUEsNkJBQUMsU0FBTSxNQUFLLFNBQVEsU0FBUyx1QkFBQyxjQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBUyxLQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBDO0FBQUEsTUFDMUMsdUJBQUMsU0FBTSxNQUFLLEtBQUksU0FBUyx1QkFBQyxZQUFTLElBQUcsU0FBUSxTQUFPLFFBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEIsS0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5RDtBQUFBLFNBRjNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLEVBRUo7QUFHQSxNQUFJSSxnQkFBZ0I7QUFDbEIsV0FDRSx1QkFBQyxTQUFJLFdBQVUsNkRBQ2IsaUNBQUMsV0FBUSxPQUFNLDBCQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBcUMsS0FEdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFSjtBQUVBLFFBQU1TLFFBQVFYLE1BQU1XLFFBQVEsYUFBYUMsWUFBWTtBQUdyRCxTQUNFLHVCQUFDLFNBQUksV0FBVSw0QkFDYjtBQUFBLDJCQUFDLFVBQU8sTUFBWSxPQUFPWixNQUFNYSxPQUFPLFVBQVVILGdCQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQStEO0FBQUEsSUFDL0QsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSw2QkFBQyxXQUFRLFFBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvQjtBQUFBLE1BQ3BCLHVCQUFDLFVBQUssV0FBVSw0QkFDZCxpQ0FBQyxVQUNFQyxtQkFBUyxjQUNSLG1DQUNFO0FBQUEsK0JBQUMsU0FBTSxNQUFLLHdCQUF1QixTQUFTLHVCQUFDLHdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUIsS0FBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtRTtBQUFBLFFBQ25FLHVCQUFDLFNBQU0sTUFBSyxhQUFZLFNBQVMsdUJBQUMsbUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFjLEtBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUQ7QUFBQSxRQUNuRCx1QkFBQyxTQUFNLE1BQUssS0FBSSxTQUFTLHVCQUFDLFlBQVMsSUFBRyx3QkFBdUIsU0FBTyxRQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJDLEtBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0U7QUFBQSxXQUgxRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUEsSUFFQSxtQ0FDRTtBQUFBLCtCQUFDLFNBQU0sTUFBSyx3QkFBdUIsU0FBUyx1QkFBQyx3QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1CLEtBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUU7QUFBQSxRQUNuRSx1QkFBQyxTQUFNLE1BQUssOEJBQTZCLFNBQVMsdUJBQUMsdUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrQixLQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdFO0FBQUEsUUFDeEUsdUJBQUMsU0FBTSxNQUFLLGFBQVksU0FBUyx1QkFBQyxtQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWMsS0FBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtRDtBQUFBLFFBQ25ELHVCQUFDLFNBQU0sTUFBSyx3QkFBdUIsU0FBUyx1QkFBQyx3QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1CLEtBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUU7QUFBQSxRQUNuRSx1QkFBQyxTQUFNLE1BQUssS0FBSSxTQUFTLHVCQUFDLFlBQVMsSUFBRyx3QkFBdUIsU0FBTyxRQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJDLEtBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0U7QUFBQSxXQUwxRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTUEsS0FkSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0JBLEtBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFrQkE7QUFBQSxTQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcUJBO0FBQUEsT0F2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXdCQTtBQUVKO0FBQUNuQixHQXBHdUJELEtBQUc7QUFBQSxVQUNSZCxhQUNBQyxXQUFXO0FBQUE7QUFBQSxLQUZOYTtBQUFHLElBQUF1QjtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VDYWxsYmFjayIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiTmF2aWdhdGUiLCJSb3V0ZSIsIlJvdXRlcyIsInVzZUxvY2F0aW9uIiwidXNlTmF2aWdhdGUiLCJjbGVhclRva2VuIiwiZ2V0Q3VycmVudFVzZXIiLCJnZXRTdG9yZWRUb2tlbiIsIk5hdmJhciIsIlNpZGViYXIiLCJTcGlubmVyIiwiQXNzZXNzbWVudEJ1aWxkZXIiLCJBdXRoUGFnZSIsIkNhbmRpZGF0ZURhc2hib2FyZCIsIlByYWN0aWNlQXJlbmEiLCJSZWNydWl0ZXJEYXNoYm9hcmQiLCJUYWtlQXNzZXNzbWVudCIsIkFwcCIsIl9zIiwibG9jYXRpb24iLCJuYXZpZ2F0ZSIsImlzVGFrZUFzc2Vzc21lbnQiLCJwYXRobmFtZSIsInN0YXJ0c1dpdGgiLCJ0b2tlbiIsInNldFRva2VuIiwidXNlciIsInNldFVzZXIiLCJsb2FkaW5nUHJvZmlsZSIsInNldExvYWRpbmdQcm9maWxlIiwic3luY0F1dGgiLCJjdXJyZW50VG9rZW4iLCJ0aGVuIiwidXNlckRhdGEiLCJjYXRjaCIsImZpbmFsbHkiLCJoYW5kbGVMb2dvdXQiLCJyb2xlIiwidG9Mb3dlckNhc2UiLCJlbWFpbCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkFwcC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlQ2FsbGJhY2ssIHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IE5hdmlnYXRlLCBSb3V0ZSwgUm91dGVzLCB1c2VMb2NhdGlvbiwgdXNlTmF2aWdhdGUgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xuaW1wb3J0IHsgY2xlYXJUb2tlbiwgZ2V0Q3VycmVudFVzZXIsIGdldFN0b3JlZFRva2VuLCB0eXBlIFVzZXJPdXQgfSBmcm9tIFwiLi9hcGkvYXV0aFwiO1xuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi9jb21wb25lbnRzL2xheW91dC9OYXZiYXJcIjtcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuL2NvbXBvbmVudHMvbGF5b3V0L1NpZGViYXJcIjtcbmltcG9ydCBTcGlubmVyIGZyb20gXCIuL2NvbXBvbmVudHMvdWkvU3Bpbm5lclwiO1xuaW1wb3J0IEFzc2Vzc21lbnRCdWlsZGVyIGZyb20gXCIuL3JvdXRlcy9Bc3Nlc3NtZW50QnVpbGRlclwiO1xuaW1wb3J0IEF1dGhQYWdlIGZyb20gXCIuL3JvdXRlcy9BdXRoUGFnZVwiO1xuaW1wb3J0IENhbmRpZGF0ZURhc2hib2FyZCBmcm9tIFwiLi9yb3V0ZXMvQ2FuZGlkYXRlRGFzaGJvYXJkXCI7XG5pbXBvcnQgUHJhY3RpY2VBcmVuYSBmcm9tIFwiLi9yb3V0ZXMvUHJhY3RpY2VBcmVuYVwiO1xuaW1wb3J0IFJlY3J1aXRlckRhc2hib2FyZCBmcm9tIFwiLi9yb3V0ZXMvUmVjcnVpdGVyRGFzaGJvYXJkXCI7XG5pbXBvcnQgVGFrZUFzc2Vzc21lbnQgZnJvbSBcIi4vcm91dGVzL1Rha2VBc3Nlc3NtZW50XCI7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEFwcCgpIHtcbiAgY29uc3QgbG9jYXRpb24gPSB1c2VMb2NhdGlvbigpO1xuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gIGNvbnN0IGlzVGFrZUFzc2Vzc21lbnQgPSBsb2NhdGlvbi5wYXRobmFtZS5zdGFydHNXaXRoKFwiL2Fzc2Vzc21lbnQvXCIpO1xuXG4gIGNvbnN0IFt0b2tlbiwgc2V0VG9rZW5dID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4oZ2V0U3RvcmVkVG9rZW4oKSk7XG4gIGNvbnN0IFt1c2VyLCBzZXRVc2VyXSA9IHVzZVN0YXRlPFVzZXJPdXQgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW2xvYWRpbmdQcm9maWxlLCBzZXRMb2FkaW5nUHJvZmlsZV0gPSB1c2VTdGF0ZTxib29sZWFuPighIWdldFN0b3JlZFRva2VuKCkpO1xuXG4gIC8vIExpc3RlbiB0byB0b2tlbiBjaGFuZ2VzIGluIGxvY2FsU3RvcmFnZSBvciBzdGF0ZVxuICBjb25zdCBzeW5jQXV0aCA9IHVzZUNhbGxiYWNrKCgpID0+IHtcbiAgICBjb25zdCBjdXJyZW50VG9rZW4gPSBnZXRTdG9yZWRUb2tlbigpO1xuICAgIHNldFRva2VuKGN1cnJlbnRUb2tlbik7XG4gICAgaWYgKGN1cnJlbnRUb2tlbikge1xuICAgICAgc2V0TG9hZGluZ1Byb2ZpbGUodHJ1ZSk7XG4gICAgICBnZXRDdXJyZW50VXNlcigpXG4gICAgICAgIC50aGVuKCh1c2VyRGF0YSkgPT4ge1xuICAgICAgICAgIHNldFVzZXIodXNlckRhdGEpO1xuICAgICAgICB9KVxuICAgICAgICAuY2F0Y2goKCkgPT4ge1xuICAgICAgICAgIGNsZWFyVG9rZW4oKTtcbiAgICAgICAgICBzZXRUb2tlbihudWxsKTtcbiAgICAgICAgICBzZXRVc2VyKG51bGwpO1xuICAgICAgICB9KVxuICAgICAgICAuZmluYWxseSgoKSA9PiBzZXRMb2FkaW5nUHJvZmlsZShmYWxzZSkpO1xuICAgIH0gZWxzZSB7XG4gICAgICBzZXRVc2VyKG51bGwpO1xuICAgICAgc2V0TG9hZGluZ1Byb2ZpbGUoZmFsc2UpO1xuICAgIH1cbiAgfSwgW10pO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgc3luY0F1dGgoKTtcbiAgfSwgW2xvY2F0aW9uLnBhdGhuYW1lLCBzeW5jQXV0aF0pO1xuXG4gIGNvbnN0IGhhbmRsZUxvZ291dCA9IHVzZUNhbGxiYWNrKCgpID0+IHtcbiAgICBjbGVhclRva2VuKCk7XG4gICAgc2V0VG9rZW4obnVsbCk7XG4gICAgc2V0VXNlcihudWxsKTtcbiAgICBuYXZpZ2F0ZShcIi9hdXRoXCIpO1xuICB9LCBbbmF2aWdhdGVdKTtcblxuICAvLyAxLiBBc3Nlc3NtZW50IHRha2luZyBVUkwgKHB1YmxpYyBjYW5kaWRhdGUgYWNjZXNzIHZpYSB0b2tlbilcbiAgaWYgKGlzVGFrZUFzc2Vzc21lbnQpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPFJvdXRlcz5cbiAgICAgICAgPFJvdXRlIHBhdGg9XCIvYXNzZXNzbWVudC86dG9rZW5cIiBlbGVtZW50PXs8VGFrZUFzc2Vzc21lbnQgLz59IC8+XG4gICAgICA8L1JvdXRlcz5cbiAgICApO1xuICB9XG5cbiAgLy8gMi4gTm90IGxvZ2dlZCBpbiBvciB0b2tlbiBpbnZhbGlkXG4gIGlmICghdG9rZW4pIHtcbiAgICByZXR1cm4gKFxuICAgICAgPFJvdXRlcz5cbiAgICAgICAgPFJvdXRlIHBhdGg9XCIvYXV0aFwiIGVsZW1lbnQ9ezxBdXRoUGFnZSAvPn0gLz5cbiAgICAgICAgPFJvdXRlIHBhdGg9XCIqXCIgZWxlbWVudD17PE5hdmlnYXRlIHRvPVwiL2F1dGhcIiByZXBsYWNlIC8+fSAvPlxuICAgICAgPC9Sb3V0ZXM+XG4gICAgKTtcbiAgfVxuXG4gIC8vIDMuIExvYWRpbmcgcHJvZmlsZVxuICBpZiAobG9hZGluZ1Byb2ZpbGUpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG1pbi1oLXNjcmVlbiBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctc2xhdGUtNTBcIj5cbiAgICAgICAgPFNwaW5uZXIgbGFiZWw9XCJMb2FkaW5nIHdvcmtzcGFjZS4uLlwiIC8+XG4gICAgICA8L2Rpdj5cbiAgICApO1xuICB9XG5cbiAgY29uc3Qgcm9sZSA9ICh1c2VyPy5yb2xlIHx8IFwiY2FuZGlkYXRlXCIpLnRvTG93ZXJDYXNlKCkgYXMgXCJyZWNydWl0ZXJcIiB8IFwiY2FuZGlkYXRlXCI7XG5cbiAgLy8gNC4gQXV0aGVudGljYXRlZCBsYXlvdXRcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlbiBiZy1zbGF0ZS01MFwiPlxuICAgICAgPE5hdmJhciByb2xlPXtyb2xlfSBlbWFpbD17dXNlcj8uZW1haWx9IG9uTG9nb3V0PXtoYW5kbGVMb2dvdXR9IC8+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXhcIj5cbiAgICAgICAgPFNpZGViYXIgcm9sZT17cm9sZX0gLz5cbiAgICAgICAgPG1haW4gY2xhc3NOYW1lPVwibWluLXctMCBmbGV4LTEgcHgtNiBweS02XCI+XG4gICAgICAgICAgPFJvdXRlcz5cbiAgICAgICAgICAgIHtyb2xlID09PSBcImNhbmRpZGF0ZVwiID8gKFxuICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL2NhbmRpZGF0ZS9kYXNoYm9hcmRcIiBlbGVtZW50PXs8Q2FuZGlkYXRlRGFzaGJvYXJkIC8+fSAvPlxuICAgICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL3ByYWN0aWNlXCIgZWxlbWVudD17PFByYWN0aWNlQXJlbmEgLz59IC8+XG4gICAgICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCIqXCIgZWxlbWVudD17PE5hdmlnYXRlIHRvPVwiL2NhbmRpZGF0ZS9kYXNoYm9hcmRcIiByZXBsYWNlIC8+fSAvPlxuICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCIvcmVjcnVpdGVyL2Rhc2hib2FyZFwiIGVsZW1lbnQ9ezxSZWNydWl0ZXJEYXNoYm9hcmQgLz59IC8+XG4gICAgICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCIvcmVjcnVpdGVyL2Fzc2Vzc21lbnRzL25ld1wiIGVsZW1lbnQ9ezxBc3Nlc3NtZW50QnVpbGRlciAvPn0gLz5cbiAgICAgICAgICAgICAgICA8Um91dGUgcGF0aD1cIi9wcmFjdGljZVwiIGVsZW1lbnQ9ezxQcmFjdGljZUFyZW5hIC8+fSAvPlxuICAgICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL2NhbmRpZGF0ZS9kYXNoYm9hcmRcIiBlbGVtZW50PXs8Q2FuZGlkYXRlRGFzaGJvYXJkIC8+fSAvPlxuICAgICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiKlwiIGVsZW1lbnQ9ezxOYXZpZ2F0ZSB0bz1cIi9yZWNydWl0ZXIvZGFzaGJvYXJkXCIgcmVwbGFjZSAvPn0gLz5cbiAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvUm91dGVzPlxuICAgICAgICA8L21haW4+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiQzovVXNlcnMvWWFzd2FudGggUmFodWwvRG93bmxvYWRzL0JpdExhYnMtQ29kaW5nLUxhYi9mcm9udGVuZC9zcmMvQXBwLnRzeCJ9