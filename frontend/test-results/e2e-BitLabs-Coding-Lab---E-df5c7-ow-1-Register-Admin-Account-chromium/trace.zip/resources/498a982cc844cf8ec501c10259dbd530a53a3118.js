import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/Navbar.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1cbb189e"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/components/layout/Navbar.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import Button from "/src/components/ui/Button.tsx";
export default function Navbar({ role, email, onLogout }) {
  const formattedRole = role.toLowerCase() === "recruiter" ? "Recruiter" : "Candidate";
  return /* @__PURE__ */ jsxDEV("header", { className: "border-b border-slate-200 bg-white", children: /* @__PURE__ */ jsxDEV("div", { className: "flex h-16 items-center justify-between px-6", children: [
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-bold uppercase tracking-wider text-brand-600", children: "BitLabs" }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/components/layout/Navbar.tsx",
        lineNumber: 35,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("h1", { className: "text-base font-bold text-slate-900", children: "Coding Lab" }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/components/layout/Navbar.tsx",
        lineNumber: 36,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/components/layout/Navbar.tsx",
      lineNumber: 34,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
      email && /* @__PURE__ */ jsxDEV("span", { className: "hidden text-xs text-slate-500 sm:inline", children: email }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/components/layout/Navbar.tsx",
        lineNumber: 39,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold capitalize text-slate-700", children: formattedRole }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/components/layout/Navbar.tsx",
        lineNumber: 40,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { variant: "secondary", onClick: onLogout, children: "Logout" }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/components/layout/Navbar.tsx",
        lineNumber: 43,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/components/layout/Navbar.tsx",
      lineNumber: 38,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/components/layout/Navbar.tsx",
    lineNumber: 33,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/components/layout/Navbar.tsx",
    lineNumber: 32,
    columnNumber: 5
  }, this);
}
_c = Navbar;
var _c;
$RefreshReg$(_c, "Navbar");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/components/layout/Navbar.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/components/layout/Navbar.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZVU7Ozs7Ozs7Ozs7Ozs7Ozs7QUFmVixPQUFPQSxZQUFZO0FBUW5CLHdCQUF3QkMsT0FBTyxFQUFFQyxNQUFNQyxPQUFPQyxTQUFzQixHQUFHO0FBQ3JFLFFBQU1DLGdCQUFnQkgsS0FBS0ksWUFBWSxNQUFNLGNBQWMsY0FBYztBQUV6RSxTQUNFLHVCQUFDLFlBQU8sV0FBVSxzQ0FDaEIsaUNBQUMsU0FBSSxXQUFVLCtDQUNiO0FBQUEsMkJBQUMsU0FDQztBQUFBLDZCQUFDLE9BQUUsV0FBVSw2REFBNEQsdUJBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0Y7QUFBQSxNQUNoRix1QkFBQyxRQUFHLFdBQVUsc0NBQXFDLDBCQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZEO0FBQUEsU0FGL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFDQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ1pIO0FBQUFBLGVBQVMsdUJBQUMsVUFBSyxXQUFVLDJDQUEyQ0EsbUJBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUU7QUFBQSxNQUMzRSx1QkFBQyxVQUFLLFdBQVUsdUZBQ2JFLDJCQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsVUFBTyxTQUFRLGFBQVksU0FBU0QsVUFBUyxzQkFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUE7QUFBQSxPQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FjQSxLQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnQkE7QUFFSjtBQUFDRyxLQXRCdUJOO0FBQU0sSUFBQU07QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiQnV0dG9uIiwiTmF2YmFyIiwicm9sZSIsImVtYWlsIiwib25Mb2dvdXQiLCJmb3JtYXR0ZWRSb2xlIiwidG9Mb3dlckNhc2UiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJOYXZiYXIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBCdXR0b24gZnJvbSBcIi4uL3VpL0J1dHRvblwiO1xuXG50eXBlIE5hdmJhclByb3BzID0ge1xuICByb2xlOiBzdHJpbmc7XG4gIGVtYWlsPzogc3RyaW5nO1xuICBvbkxvZ291dDogKCkgPT4gdm9pZDtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE5hdmJhcih7IHJvbGUsIGVtYWlsLCBvbkxvZ291dCB9OiBOYXZiYXJQcm9wcykge1xuICBjb25zdCBmb3JtYXR0ZWRSb2xlID0gcm9sZS50b0xvd2VyQ2FzZSgpID09PSBcInJlY3J1aXRlclwiID8gXCJSZWNydWl0ZXJcIiA6IFwiQ2FuZGlkYXRlXCI7XG5cbiAgcmV0dXJuIChcbiAgICA8aGVhZGVyIGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDAgYmctd2hpdGVcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBoLTE2IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcHgtNlwiPlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWJyYW5kLTYwMFwiPkJpdExhYnM8L3A+XG4gICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDBcIj5Db2RpbmcgTGFiPC9oMT5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICB7ZW1haWwgJiYgPHNwYW4gY2xhc3NOYW1lPVwiaGlkZGVuIHRleHQteHMgdGV4dC1zbGF0ZS01MDAgc206aW5saW5lXCI+e2VtYWlsfTwvc3Bhbj59XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicm91bmRlZC1mdWxsIGJnLXNsYXRlLTEwMCBweC0zIHB5LTEgdGV4dC14cyBmb250LXNlbWlib2xkIGNhcGl0YWxpemUgdGV4dC1zbGF0ZS03MDBcIj5cbiAgICAgICAgICAgIHtmb3JtYXR0ZWRSb2xlfVxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIiBvbkNsaWNrPXtvbkxvZ291dH0+XG4gICAgICAgICAgICBMb2dvdXRcbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2hlYWRlcj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiQzovVXNlcnMvWWFzd2FudGggUmFodWwvRG93bmxvYWRzL0JpdExhYnMtQ29kaW5nLUxhYi9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9sYXlvdXQvTmF2YmFyLnRzeCJ9