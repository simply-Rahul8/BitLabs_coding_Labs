import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/Badge.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1cbb189e"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/components/ui/Badge.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
const statusClasses = {
  draft: "bg-slate-100 text-slate-700",
  active: "bg-emerald-100 text-emerald-700",
  completed: "bg-blue-100 text-blue-700",
  failed: "bg-red-100 text-red-700"
};
export default function Badge({ status, children }) {
  return /* @__PURE__ */ jsxDEV("span", { className: `inline-flex rounded-full px-2.5 py-1 text-xs font-semibold ${statusClasses[status]}`, children: children ?? status }, void 0, false, {
    fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/components/ui/Badge.tsx",
    lineNumber: 36,
    columnNumber: 5
  }, this);
}
_c = Badge;
var _c;
$RefreshReg$(_c, "Badge");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/components/ui/Badge.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/components/ui/Badge.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JJOzs7Ozs7Ozs7Ozs7Ozs7O0FBVEosTUFBTUEsZ0JBQTZDO0FBQUEsRUFDakRDLE9BQU87QUFBQSxFQUNQQyxRQUFRO0FBQUEsRUFDUkMsV0FBVztBQUFBLEVBQ1hDLFFBQVE7QUFDVjtBQUVBLHdCQUF3QkMsTUFBTSxFQUFFQyxRQUFRQyxTQUFxQixHQUFHO0FBQzlELFNBQ0UsdUJBQUMsVUFBSyxXQUFXLDhEQUE4RFAsY0FBY00sTUFBTSxDQUFDLElBQ2pHQyxzQkFBWUQsVUFEZjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRUE7QUFFSjtBQUFDRSxLQU51Qkg7QUFBSyxJQUFBRztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJzdGF0dXNDbGFzc2VzIiwiZHJhZnQiLCJhY3RpdmUiLCJjb21wbGV0ZWQiLCJmYWlsZWQiLCJCYWRnZSIsInN0YXR1cyIsImNoaWxkcmVuIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQmFkZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbInR5cGUgQmFkZ2VTdGF0dXMgPSBcImRyYWZ0XCIgfCBcImFjdGl2ZVwiIHwgXCJjb21wbGV0ZWRcIiB8IFwiZmFpbGVkXCI7XG5cbnR5cGUgQmFkZ2VQcm9wcyA9IHtcbiAgc3RhdHVzOiBCYWRnZVN0YXR1cztcbiAgY2hpbGRyZW4/OiBzdHJpbmc7XG59O1xuXG5jb25zdCBzdGF0dXNDbGFzc2VzOiBSZWNvcmQ8QmFkZ2VTdGF0dXMsIHN0cmluZz4gPSB7XG4gIGRyYWZ0OiBcImJnLXNsYXRlLTEwMCB0ZXh0LXNsYXRlLTcwMFwiLFxuICBhY3RpdmU6IFwiYmctZW1lcmFsZC0xMDAgdGV4dC1lbWVyYWxkLTcwMFwiLFxuICBjb21wbGV0ZWQ6IFwiYmctYmx1ZS0xMDAgdGV4dC1ibHVlLTcwMFwiLFxuICBmYWlsZWQ6IFwiYmctcmVkLTEwMCB0ZXh0LXJlZC03MDBcIlxufTtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQmFkZ2UoeyBzdGF0dXMsIGNoaWxkcmVuIH06IEJhZGdlUHJvcHMpIHtcbiAgcmV0dXJuIChcbiAgICA8c3BhbiBjbGFzc05hbWU9e2BpbmxpbmUtZmxleCByb3VuZGVkLWZ1bGwgcHgtMi41IHB5LTEgdGV4dC14cyBmb250LXNlbWlib2xkICR7c3RhdHVzQ2xhc3Nlc1tzdGF0dXNdfWB9PlxuICAgICAge2NoaWxkcmVuID8/IHN0YXR1c31cbiAgICA8L3NwYW4+XG4gICk7XG59XG4iXSwiZmlsZSI6IkM6L1VzZXJzL1lhc3dhbnRoIFJhaHVsL0Rvd25sb2Fkcy9CaXRMYWJzLUNvZGluZy1MYWIvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvdWkvQmFkZ2UudHN4In0=