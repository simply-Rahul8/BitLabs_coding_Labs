import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/PracticeArena.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1cbb189e"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=1cbb189e"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import CodeEditor from "/src/components/editor/CodeEditor.tsx";
import { languageTemplates, languageLabels } from "/src/constants/templates.ts";
import { runCode, getHint, evaluateCode, logProgress, getProgress } from "/src/api/practice.ts";
import toast from "/node_modules/.vite/deps/react-hot-toast.js?v=1cbb189e";
import Spinner from "/src/components/ui/Spinner.tsx";
export default function PracticeArena() {
  _s();
  const languages = Object.keys(languageLabels).filter((l) => l !== "swift");
  const [language, setLanguage] = useState("python");
  const [code, setCode] = useState(languageTemplates.python);
  const [stdin, setStdin] = useState("");
  const [stdout, setStdout] = useState("");
  const [stderr, setStderr] = useState("");
  const [exitCode, setExitCode] = useState(null);
  const [timedOut, setTimedOut] = useState(false);
  const [isRunning, setIsRunning] = useState(false);
  const [solvedCount, setSolvedCount] = useState(0);
  const [activeTab, setActiveTab] = useState("hint");
  const [userQuestion, setUserQuestion] = useState("");
  const [aiHint, setAiHint] = useState("");
  const [isHintLoading, setIsHintLoading] = useState(false);
  const [problemDescription, setProblemDescription] = useState("");
  const [isEvaluateLoading, setIsEvaluateLoading] = useState(false);
  const [evalResult, setEvalResult] = useState(null);
  const fetchProgress = async () => {
    try {
      const data = await getProgress();
      setSolvedCount(data.total_solved);
    } catch (err) {
      console.error("Unable to load practice progress", err);
    }
  };
  useEffect(() => {
    void fetchProgress();
  }, []);
  const handleLanguageChange = (e) => {
    const nextLang = e.target.value;
    const prevTemplate = languageTemplates[language];
    const nextTemplate = languageTemplates[nextLang];
    if (code === prevTemplate) {
      setLanguage(nextLang);
      setCode(nextTemplate);
    } else {
      const shouldSwap = window.confirm(
        `Replace current code with ${languageLabels[nextLang]} starter template? This will discard your edits.`
      );
      if (shouldSwap) {
        setLanguage(nextLang);
        setCode(nextTemplate);
      }
    }
  };
  const handleRunCode = async () => {
    try {
      setIsRunning(true);
      setStdout("");
      setStderr("");
      setExitCode(null);
      setTimedOut(false);
      const result = await runCode({
        source_code: code,
        language,
        stdin: stdin.trim() || void 0
      });
      setStdout(result.stdout || "");
      setStderr(result.stderr || "");
      setExitCode(result.exit_code);
      setTimedOut(result.timed_out);
      if (result.error) {
        setStderr(result.error);
      }
    } catch (err) {
      toast.error("Failed to run code. Make sure sandbox is running.");
    } finally {
      setIsRunning(false);
    }
  };
  const handleGetHint = async () => {
    try {
      setIsHintLoading(true);
      setAiHint("");
      const result = await getHint({
        source_code: code,
        language,
        user_question: userQuestion.trim() || void 0
      });
      setAiHint(result.hint);
    } catch (err) {
      setAiHint("AI unavailable. Check your code manually.");
      toast.error("Failed to fetch AI hint.");
    } finally {
      setIsHintLoading(false);
    }
  };
  const handleEvaluate = async () => {
    try {
      setIsEvaluateLoading(true);
      setEvalResult(null);
      const result = await evaluateCode({
        source_code: code,
        language,
        stdout: stdout || "(No output produced)",
        problem_description: problemDescription.trim() || void 0
      });
      setEvalResult(result);
      try {
        await logProgress({
          source_code: code,
          language,
          ai_score: result.score,
          is_correct: result.is_correct
        });
        if (result.is_correct) {
          toast.success("Progress saved! ✓");
          void fetchProgress();
        }
      } catch (logErr) {
        console.error("Unable to log progress", logErr);
      }
    } catch (err) {
      toast.error("AI Evaluation failed.");
    } finally {
      setIsEvaluateLoading(false);
    }
  };
  const renderMarkdown = (text) => {
    if (!text) return "";
    let html = text.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, "");
    html = html.replace(/```(?:\w+)?\n?([\s\S]*?)```/g, '<pre class="bg-gray-900 p-2 rounded text-green-400 text-xs overflow-auto font-mono my-2 border border-gray-800">$1</pre>');
    html = html.replace(/`([^`]+)`/g, '<code class="bg-gray-900 px-1 rounded text-green-400 font-mono font-medium">$1</code>');
    html = html.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
    return html;
  };
  const getStatusText = () => {
    if (isRunning) return "Running...";
    if (isHintLoading || isEvaluateLoading) return "AI Thinking...";
    return "Ready";
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col h-screen bg-gray-900 text-white overflow-hidden select-none", children: [
    /* @__PURE__ */ jsxDEV("header", { className: "h-12 bg-gray-800 border-b border-gray-700 flex items-center justify-between px-4 z-10 shrink-0", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "font-semibold text-white flex items-center gap-1.5", children: [
        /* @__PURE__ */ jsxDEV("span", { children: "⚡" }, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
          lineNumber: 195,
          columnNumber: 11
        }, this),
        " BitLabs Practice Arena"
      ] }, void 0, true, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
        lineNumber: 194,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsxDEV(
          "select",
          {
            value: language,
            onChange: handleLanguageChange,
            className: "rounded border border-indigo-700 bg-indigo-800 text-white px-2 py-1 text-sm outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500",
            children: [
              /* @__PURE__ */ jsxDEV("option", { value: "python", children: "Python" }, void 0, false, {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
                lineNumber: 203,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "c", children: "C" }, void 0, false, {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
                lineNumber: 204,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "cpp", children: "C++" }, void 0, false, {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
                lineNumber: 205,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "java", children: "Java" }, void 0, false, {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
                lineNumber: 206,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "javascript", children: "JavaScript" }, void 0, false, {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
                lineNumber: 207,
                columnNumber: 13
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
            lineNumber: 198,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("span", { className: "rounded bg-green-600 px-2.5 py-0.5 text-xs font-semibold tracking-wide text-white uppercase", children: [
          "Solved: ",
          solvedCount
        ] }, void 0, true, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
          lineNumber: 209,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
        lineNumber: 197,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
      lineNumber: 193,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("main", { className: "flex-1 flex min-h-0 overflow-hidden", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "w-3/5 flex flex-col border-r border-gray-700 bg-gray-900", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-h-0 relative", children: /* @__PURE__ */ jsxDEV(CodeEditor, { language, value: code, onChange: setCode, heightClass: "h-full" }, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
          lineNumber: 220,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
          lineNumber: 219,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-800 p-2 flex gap-2 border-t border-gray-700 shrink-0", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: handleRunCode,
              disabled: isRunning,
              className: "flex items-center gap-1 bg-gray-700 hover:bg-gray-600 disabled:opacity-50 text-white text-sm font-medium py-1.5 px-4 rounded border border-gray-600 transition-colors",
              children: isRunning ? /* @__PURE__ */ jsxDEV(Spinner, { label: "" }, void 0, false, {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
                lineNumber: 230,
                columnNumber: 28
              }, this) : "▶ Run"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
              lineNumber: 225,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => {
                setActiveTab("hint");
                const inp = document.getElementById("ai-hint-input");
                if (inp) inp.focus();
              },
              className: "flex items-center gap-1 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium py-1.5 px-4 rounded transition-colors",
              children: [
                /* @__PURE__ */ jsxDEV("span", { children: "💡" }, void 0, false, {
                  fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
                  lineNumber: 241,
                  columnNumber: 15
                }, this),
                " Hint"
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
              lineNumber: 232,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: handleEvaluate,
              disabled: isEvaluateLoading,
              className: "flex items-center gap-1 bg-green-600 hover:bg-green-700 disabled:opacity-50 text-white text-sm font-medium py-1.5 px-4 rounded transition-colors",
              children: isEvaluateLoading ? /* @__PURE__ */ jsxDEV(Spinner, { label: "" }, void 0, false, {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
                lineNumber: 248,
                columnNumber: 36
              }, this) : "✓ Evaluate"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
              lineNumber: 243,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
          lineNumber: 224,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
        lineNumber: 218,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "w-2/5 flex flex-col bg-gray-800 border-l border-gray-700 min-h-0", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "h-1/2 flex flex-col border-b border-gray-700 min-h-0", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-gray-400 p-2 shrink-0 select-none uppercase tracking-wider font-semibold", children: "Console" }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
            lineNumber: 257,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex-1 flex flex-col p-2 space-y-2 min-h-0", children: [
            /* @__PURE__ */ jsxDEV(
              "textarea",
              {
                value: stdin,
                onChange: (e) => setStdin(e.target.value),
                placeholder: "stdin input...",
                className: "w-full h-16 resize-none p-2 rounded bg-gray-900 text-green-400 font-mono text-sm placeholder-gray-600 border border-gray-750 outline-none focus:border-green-500 shrink-0"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
                lineNumber: 261,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "flex-1 bg-gray-900 border border-gray-750 rounded p-2 overflow-auto min-h-0", children: /* @__PURE__ */ jsxDEV("div", { className: "font-mono text-sm", children: timedOut ? /* @__PURE__ */ jsxDEV("span", { className: "text-yellow-400 font-semibold", children: "Execution timed out" }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
              lineNumber: 270,
              columnNumber: 19
            }, this) : exitCode !== null && exitCode !== 0 ? /* @__PURE__ */ jsxDEV("pre", { className: "text-red-400 whitespace-pre-wrap", children: stderr || `Exit Code: ${exitCode}` }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
              lineNumber: 272,
              columnNumber: 19
            }, this) : stderr ? /* @__PURE__ */ jsxDEV("pre", { className: "text-red-400 whitespace-pre-wrap", children: stderr }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
              lineNumber: 274,
              columnNumber: 19
            }, this) : stdout ? /* @__PURE__ */ jsxDEV("pre", { className: "text-green-400 whitespace-pre-wrap", children: stdout }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
              lineNumber: 276,
              columnNumber: 19
            }, this) : /* @__PURE__ */ jsxDEV("span", { className: "text-gray-500 italic", children: "Run your code to see output..." }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
              lineNumber: 278,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
              lineNumber: 268,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
              lineNumber: 267,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
            lineNumber: 260,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
          lineNumber: 256,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "h-1/2 flex flex-col min-h-0 bg-gray-850", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-900 border-b border-gray-700 flex shrink-0", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setActiveTab("hint"),
                className: `flex-1 py-2 text-xs font-semibold uppercase tracking-wider transition-colors ${activeTab === "hint" ? "bg-gray-800 text-blue-400 border-b-2 border-blue-500" : "text-gray-400 hover:text-gray-200"}`,
                children: "💡 Hint"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
                lineNumber: 289,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setActiveTab("evaluation"),
                className: `flex-1 py-2 text-xs font-semibold uppercase tracking-wider transition-colors ${activeTab === "evaluation" ? "bg-gray-800 text-green-400 border-b-2 border-green-500" : "text-gray-400 hover:text-gray-200"}`,
                children: "📊 Evaluate"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
                lineNumber: 299,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
            lineNumber: 288,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex-1 overflow-y-auto p-2 min-h-0 flex flex-col", children: activeTab === "hint" ? /* @__PURE__ */ jsxDEV("div", { className: "flex-1 flex flex-col min-h-0 space-y-2", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex gap-1.5 shrink-0", children: [
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  id: "ai-hint-input",
                  type: "text",
                  value: userQuestion,
                  onChange: (e) => setUserQuestion(e.target.value),
                  placeholder: "Ask about your code...",
                  className: "bg-gray-700 text-white rounded p-1.5 text-sm flex-1 outline-none border border-gray-650 focus:border-blue-500",
                  onKeyDown: (e) => e.key === "Enter" && handleGetHint()
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
                  lineNumber: 316,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: handleGetHint,
                  disabled: isHintLoading,
                  className: "bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded px-4 py-1.5 transition-colors disabled:opacity-50",
                  children: isHintLoading ? "Asking..." : "Ask"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
                  lineNumber: 325,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
              lineNumber: 315,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-h-0 overflow-y-auto", children: isHintLoading ? /* @__PURE__ */ jsxDEV("div", { className: "h-full flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(Spinner, { label: "AI is loading hint..." }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
              lineNumber: 337,
              columnNumber: 25
            }, this) }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
              lineNumber: 336,
              columnNumber: 19
            }, this) : aiHint ? /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: "bg-gray-700 rounded p-3 text-sm text-gray-200 whitespace-pre-wrap leading-relaxed border border-gray-650 shadow-inner",
                dangerouslySetInnerHTML: { __html: renderMarkdown(aiHint) }
              },
              void 0,
              false,
              {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
                lineNumber: 340,
                columnNumber: 19
              },
              this
            ) : /* @__PURE__ */ jsxDEV("div", { className: "h-full flex items-center justify-center text-gray-500 text-sm italic", children: "Ask AI anything about your code" }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
              lineNumber: 345,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
              lineNumber: 334,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
            lineNumber: 314,
            columnNumber: 15
          }, this) : /* @__PURE__ */ jsxDEV("div", { className: "flex-1 flex flex-col min-h-0 space-y-2", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-1.5 shrink-0 p-1 bg-gray-800 rounded border border-gray-700", children: [
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  value: problemDescription,
                  onChange: (e) => setProblemDescription(e.target.value),
                  placeholder: "Describe what you're trying to solve (optional)...",
                  className: "bg-gray-750 text-white rounded p-1.5 text-sm outline-none border border-gray-650 focus:border-green-500"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
                  lineNumber: 354,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: handleEvaluate,
                  disabled: isEvaluateLoading,
                  className: "bg-green-600 hover:bg-green-700 text-white text-sm font-semibold rounded py-2 transition-colors disabled:opacity-50 w-full",
                  children: isEvaluateLoading ? "Reviewing..." : "Evaluate My Code"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
                  lineNumber: 361,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
              lineNumber: 353,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-h-0 overflow-y-auto", children: isEvaluateLoading ? /* @__PURE__ */ jsxDEV("div", { className: "h-full flex flex-col items-center justify-center space-y-2", children: [
              /* @__PURE__ */ jsxDEV(Spinner, { label: "" }, void 0, false, {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
                lineNumber: 373,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-400 font-medium", children: "AI is reviewing your code..." }, void 0, false, {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
                lineNumber: 374,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
              lineNumber: 372,
              columnNumber: 19
            }, this) : evalResult ? /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-700 rounded p-3 border border-gray-650 space-y-3", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between border-b border-gray-600 pb-2", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-baseline gap-0.5", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: `text-3xl font-extrabold ${evalResult.score >= 70 ? "text-green-400" : evalResult.score >= 40 ? "text-yellow-400" : "text-red-400"}`, children: evalResult.score }, void 0, false, {
                    fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
                    lineNumber: 380,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-gray-400 text-xs font-medium", children: "/100" }, void 0, false, {
                    fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
                    lineNumber: 389,
                    columnNumber: 29
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
                  lineNumber: 379,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: evalResult.is_correct ? /* @__PURE__ */ jsxDEV("span", { className: "bg-green-600 px-2 py-0.5 rounded text-xs font-semibold text-white shadow-sm", children: "✓ Correct" }, void 0, false, {
                  fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
                  lineNumber: 393,
                  columnNumber: 25
                }, this) : /* @__PURE__ */ jsxDEV("span", { className: "bg-red-600 px-2 py-0.5 rounded text-xs font-semibold text-white shadow-sm", children: "✗ Needs Work" }, void 0, false, {
                  fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
                  lineNumber: 397,
                  columnNumber: 25
                }, this) }, void 0, false, {
                  fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
                  lineNumber: 391,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
                lineNumber: 378,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-bold text-gray-400 uppercase tracking-wider mb-0.5", children: "Feedback" }, void 0, false, {
                  fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
                  lineNumber: 405,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-gray-300 text-sm", children: evalResult.feedback }, void 0, false, {
                  fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
                  lineNumber: 406,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
                lineNumber: 404,
                columnNumber: 25
              }, this),
              evalResult.improvements.length > 0 && /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-bold text-gray-400 uppercase tracking-wider mb-1", children: "Suggested Improvements" }, void 0, false, {
                  fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
                  lineNumber: 411,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("ul", { className: "list-disc pl-4 text-sm text-gray-350 space-y-1", children: evalResult.improvements.map(
                  (tip, idx) => /* @__PURE__ */ jsxDEV("li", { children: tip }, idx, false, {
                    fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
                    lineNumber: 414,
                    columnNumber: 25
                  }, this)
                ) }, void 0, false, {
                  fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
                  lineNumber: 412,
                  columnNumber: 29
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
                lineNumber: 410,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
              lineNumber: 377,
              columnNumber: 19
            }, this) : /* @__PURE__ */ jsxDEV("div", { className: "h-full flex items-center justify-center text-gray-500 text-sm italic", children: "Ready to evaluate? Fill in the details above or click Evaluate." }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
              lineNumber: 421,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
              lineNumber: 370,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
            lineNumber: 352,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
            lineNumber: 312,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
          lineNumber: 286,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
        lineNumber: 254,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
      lineNumber: 216,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("footer", { className: "h-6 bg-gray-900 border-t border-gray-700 flex items-center justify-between px-3 shrink-0", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-gray-500 font-medium", children: [
        "Language: ",
        languageLabels[language]
      ] }, void 0, true, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
        lineNumber: 435,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-gray-500 font-medium font-mono", children: getStatusText() }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
        lineNumber: 438,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
      lineNumber: 434,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx",
    lineNumber: 191,
    columnNumber: 5
  }, this);
}
_s(PracticeArena, "1A5FSMdfHJPQwp6AiBd6JMgw+pY=");
_c = PracticeArena;
var _c;
$RefreshReg$(_c, "PracticeArena");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/PracticeArena.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0tVOzs7Ozs7Ozs7Ozs7Ozs7OztBQS9LVixTQUFTQSxXQUFXQyxnQkFBZ0I7QUFDcEMsT0FBT0MsZ0JBQWdCO0FBQ3ZCLFNBQVNDLG1CQUFzQ0Msc0JBQXNCO0FBQ3JFLFNBQVNDLFNBQVNDLFNBQVNDLGNBQWNDLGFBQWFDLG1CQUFtQjtBQUN6RSxPQUFPQyxXQUFXO0FBQ2xCLE9BQU9DLGFBQWE7QUFFcEIsd0JBQXdCQyxnQkFBZ0I7QUFBQUMsS0FBQTtBQUN0QyxRQUFNQyxZQUFZQyxPQUFPQyxLQUFLWixjQUFjLEVBQUVhLE9BQU8sQ0FBQUMsTUFBS0EsTUFBTSxPQUFPO0FBQ3ZFLFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJbkIsU0FBNEIsUUFBUTtBQUNwRSxRQUFNLENBQUNvQixNQUFNQyxPQUFPLElBQUlyQixTQUFTRSxrQkFBa0JvQixNQUFNO0FBQ3pELFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJeEIsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQ3lCLFFBQVFDLFNBQVMsSUFBSTFCLFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUMyQixRQUFRQyxTQUFTLElBQUk1QixTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDNkIsVUFBVUMsV0FBVyxJQUFJOUIsU0FBd0IsSUFBSTtBQUM1RCxRQUFNLENBQUMrQixVQUFVQyxXQUFXLElBQUloQyxTQUFTLEtBQUs7QUFDOUMsUUFBTSxDQUFDaUMsV0FBV0MsWUFBWSxJQUFJbEMsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQ21DLGFBQWFDLGNBQWMsSUFBSXBDLFNBQVMsQ0FBQztBQUNoRCxRQUFNLENBQUNxQyxXQUFXQyxZQUFZLElBQUl0QyxTQUFnQyxNQUFNO0FBQ3hFLFFBQU0sQ0FBQ3VDLGNBQWNDLGVBQWUsSUFBSXhDLFNBQVMsRUFBRTtBQUNuRCxRQUFNLENBQUN5QyxRQUFRQyxTQUFTLElBQUkxQyxTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDMkMsZUFBZUMsZ0JBQWdCLElBQUk1QyxTQUFTLEtBQUs7QUFFeEQsUUFBTSxDQUFDNkMsb0JBQW9CQyxxQkFBcUIsSUFBSTlDLFNBQVMsRUFBRTtBQUMvRCxRQUFNLENBQUMrQyxtQkFBbUJDLG9CQUFvQixJQUFJaEQsU0FBUyxLQUFLO0FBQ2hFLFFBQU0sQ0FBQ2lELFlBQVlDLGFBQWEsSUFBSWxELFNBSzFCLElBQUk7QUFFZCxRQUFNbUQsZ0JBQWdCLFlBQVk7QUFDaEMsUUFBSTtBQUNGLFlBQU1DLE9BQU8sTUFBTTVDLFlBQVk7QUFDL0I0QixxQkFBZWdCLEtBQUtDLFlBQVk7QUFBQSxJQUNsQyxTQUFTQyxLQUFLO0FBQ1pDLGNBQVFDLE1BQU0sb0NBQW9DRixHQUFHO0FBQUEsSUFDdkQ7QUFBQSxFQUNGO0FBRUF2RCxZQUFVLE1BQU07QUFDZCxTQUFLb0QsY0FBYztBQUFBLEVBQ3JCLEdBQUcsRUFBRTtBQUVMLFFBQU1NLHVCQUF1QkEsQ0FBQ0MsTUFBNEM7QUFDeEUsVUFBTUMsV0FBV0QsRUFBRUUsT0FBT0M7QUFDMUIsVUFBTUMsZUFBZTVELGtCQUFrQmdCLFFBQVE7QUFDL0MsVUFBTTZDLGVBQWU3RCxrQkFBa0J5RCxRQUFRO0FBRS9DLFFBQUl2QyxTQUFTMEMsY0FBYztBQUV6QjNDLGtCQUFZd0MsUUFBUTtBQUNwQnRDLGNBQVEwQyxZQUFZO0FBQUEsSUFDdEIsT0FBTztBQUNMLFlBQU1DLGFBQWFDLE9BQU9DO0FBQUFBLFFBQ3hCLDZCQUE2Qi9ELGVBQWV3RCxRQUFRLENBQUM7QUFBQSxNQUN2RDtBQUNBLFVBQUlLLFlBQVk7QUFDZDdDLG9CQUFZd0MsUUFBUTtBQUNwQnRDLGdCQUFRMEMsWUFBWTtBQUFBLE1BQ3RCO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFFQSxRQUFNSSxnQkFBZ0IsWUFBWTtBQUNoQyxRQUFJO0FBQ0ZqQyxtQkFBYSxJQUFJO0FBQ2pCUixnQkFBVSxFQUFFO0FBQ1pFLGdCQUFVLEVBQUU7QUFDWkUsa0JBQVksSUFBSTtBQUNoQkUsa0JBQVksS0FBSztBQUVqQixZQUFNb0MsU0FBUyxNQUFNaEUsUUFBUTtBQUFBLFFBQzNCaUUsYUFBYWpEO0FBQUFBLFFBQ2JGO0FBQUFBLFFBQ0FLLE9BQU9BLE1BQU0rQyxLQUFLLEtBQUtDO0FBQUFBLE1BQ3pCLENBQUM7QUFFRDdDLGdCQUFVMEMsT0FBTzNDLFVBQVUsRUFBRTtBQUM3QkcsZ0JBQVV3QyxPQUFPekMsVUFBVSxFQUFFO0FBQzdCRyxrQkFBWXNDLE9BQU9JLFNBQVM7QUFDNUJ4QyxrQkFBWW9DLE9BQU9LLFNBQVM7QUFFNUIsVUFBSUwsT0FBT1osT0FBTztBQUNoQjVCLGtCQUFVd0MsT0FBT1osS0FBSztBQUFBLE1BQ3hCO0FBQUEsSUFDRixTQUFTRixLQUFLO0FBQ1o3QyxZQUFNK0MsTUFBTSxtREFBbUQ7QUFBQSxJQUNqRSxVQUFDO0FBQ0N0QixtQkFBYSxLQUFLO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBRUEsUUFBTXdDLGdCQUFnQixZQUFZO0FBQ2hDLFFBQUk7QUFDRjlCLHVCQUFpQixJQUFJO0FBQ3JCRixnQkFBVSxFQUFFO0FBQ1osWUFBTTBCLFNBQVMsTUFBTS9ELFFBQVE7QUFBQSxRQUMzQmdFLGFBQWFqRDtBQUFBQSxRQUNiRjtBQUFBQSxRQUNBeUQsZUFBZXBDLGFBQWErQixLQUFLLEtBQUtDO0FBQUFBLE1BQ3hDLENBQUM7QUFDRDdCLGdCQUFVMEIsT0FBT1EsSUFBSTtBQUFBLElBQ3ZCLFNBQVN0QixLQUFLO0FBQ1paLGdCQUFVLDJDQUEyQztBQUNyRGpDLFlBQU0rQyxNQUFNLDBCQUEwQjtBQUFBLElBQ3hDLFVBQUM7QUFDQ1osdUJBQWlCLEtBQUs7QUFBQSxJQUN4QjtBQUFBLEVBQ0Y7QUFFQSxRQUFNaUMsaUJBQWlCLFlBQVk7QUFDakMsUUFBSTtBQUNGN0IsMkJBQXFCLElBQUk7QUFDekJFLG9CQUFjLElBQUk7QUFDbEIsWUFBTWtCLFNBQVMsTUFBTTlELGFBQWE7QUFBQSxRQUNoQytELGFBQWFqRDtBQUFBQSxRQUNiRjtBQUFBQSxRQUNBTyxRQUFRQSxVQUFVO0FBQUEsUUFDbEJxRCxxQkFBcUJqQyxtQkFBbUJ5QixLQUFLLEtBQUtDO0FBQUFBLE1BQ3BELENBQUM7QUFDRHJCLG9CQUFja0IsTUFBTTtBQUVwQixVQUFJO0FBQ0YsY0FBTTdELFlBQVk7QUFBQSxVQUNoQjhELGFBQWFqRDtBQUFBQSxVQUNiRjtBQUFBQSxVQUNBNkQsVUFBVVgsT0FBT1k7QUFBQUEsVUFDakJDLFlBQVliLE9BQU9hO0FBQUFBLFFBQ3JCLENBQUM7QUFDRCxZQUFJYixPQUFPYSxZQUFZO0FBQ3JCeEUsZ0JBQU15RSxRQUFRLG1CQUFtQjtBQUNqQyxlQUFLL0IsY0FBYztBQUFBLFFBQ3JCO0FBQUEsTUFDRixTQUFTZ0MsUUFBUTtBQUNmNUIsZ0JBQVFDLE1BQU0sMEJBQTBCMkIsTUFBTTtBQUFBLE1BQ2hEO0FBQUEsSUFDRixTQUFTN0IsS0FBSztBQUNaN0MsWUFBTStDLE1BQU0sdUJBQXVCO0FBQUEsSUFDckMsVUFBQztBQUNDUiwyQkFBcUIsS0FBSztBQUFBLElBQzVCO0FBQUEsRUFDRjtBQUdBLFFBQU1vQyxpQkFBaUJBLENBQUNDLFNBQWlCO0FBQ3ZDLFFBQUksQ0FBQ0EsS0FBTSxRQUFPO0FBRWxCLFFBQUlDLE9BQU9ELEtBQUtFLFFBQVEsdURBQXVELEVBQUU7QUFHakZELFdBQU9BLEtBQUtDLFFBQVEsZ0NBQWdDLDBIQUEwSDtBQUc5S0QsV0FBT0EsS0FBS0MsUUFBUSxjQUFjLHVGQUF1RjtBQUd6SEQsV0FBT0EsS0FBS0MsUUFBUSxvQkFBb0IscUJBQXFCO0FBRTdELFdBQU9EO0FBQUFBLEVBQ1Q7QUFHQSxRQUFNRSxnQkFBZ0JBLE1BQU07QUFDMUIsUUFBSXZELFVBQVcsUUFBTztBQUN0QixRQUFJVSxpQkFBaUJJLGtCQUFtQixRQUFPO0FBQy9DLFdBQU87QUFBQSxFQUNUO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsNkVBRWI7QUFBQSwyQkFBQyxZQUFPLFdBQVUsa0dBQ2hCO0FBQUEsNkJBQUMsUUFBRyxXQUFVLHNEQUNaO0FBQUEsK0JBQUMsVUFBSyxpQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQU87QUFBQSxRQUFPO0FBQUEsV0FEaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBTzdCO0FBQUFBLFlBQ1AsVUFBVXVDO0FBQUFBLFlBQ1YsV0FBVTtBQUFBLFlBRVY7QUFBQSxxQ0FBQyxZQUFPLE9BQU0sVUFBUyxzQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkI7QUFBQSxjQUM3Qix1QkFBQyxZQUFPLE9BQU0sS0FBSSxpQkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUI7QUFBQSxjQUNuQix1QkFBQyxZQUFPLE9BQU0sT0FBTSxtQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBdUI7QUFBQSxjQUN2Qix1QkFBQyxZQUFPLE9BQU0sUUFBTyxvQkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBeUI7QUFBQSxjQUN6Qix1QkFBQyxZQUFPLE9BQU0sY0FBYSwwQkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUM7QUFBQTtBQUFBO0FBQUEsVUFUdkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBVUE7QUFBQSxRQUNBLHVCQUFDLFVBQUssV0FBVSwrRkFBNkY7QUFBQTtBQUFBLFVBQ2xHdEI7QUFBQUEsYUFEWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFlQTtBQUFBLFNBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvQkE7QUFBQSxJQUdBLHVCQUFDLFVBQUssV0FBVSx1Q0FFZDtBQUFBLDZCQUFDLFNBQUksV0FBVSw0REFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSwyQkFDYixpQ0FBQyxjQUFXLFVBQW9CLE9BQU9mLE1BQU0sVUFBVUMsU0FBUyxhQUFZLFlBQTVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0YsS0FEdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsZ0VBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUzhDO0FBQUFBLGNBQ1QsVUFBVWxDO0FBQUFBLGNBQ1YsV0FBVTtBQUFBLGNBRVRBLHNCQUFZLHVCQUFDLFdBQVEsT0FBTSxNQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlCLElBQU07QUFBQTtBQUFBLFlBTHRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1BO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNO0FBQ2JLLDZCQUFhLE1BQU07QUFFbkIsc0JBQU1tRCxNQUFNQyxTQUFTQyxlQUFlLGVBQWU7QUFDbkQsb0JBQUlGLElBQUtBLEtBQUlHLE1BQU07QUFBQSxjQUNyQjtBQUFBLGNBQ0EsV0FBVTtBQUFBLGNBRVY7QUFBQSx1Q0FBQyxVQUFLLGtCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQVE7QUFBQSxnQkFBTztBQUFBO0FBQUE7QUFBQSxZQVRqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFVQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVNmO0FBQUFBLGNBQ1QsVUFBVTlCO0FBQUFBLGNBQ1YsV0FBVTtBQUFBLGNBRVRBLDhCQUFvQix1QkFBQyxXQUFRLE9BQU0sTUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpQixJQUFNO0FBQUE7QUFBQSxZQUw5QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNQTtBQUFBLGFBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEwQkE7QUFBQSxXQWhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBaUNBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsb0VBRWI7QUFBQSwrQkFBQyxTQUFJLFdBQVUsd0RBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUseUZBQXVGLHVCQUF0RztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsOENBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE9BQU94QjtBQUFBQSxnQkFDUCxVQUFVLENBQUNtQyxNQUFNbEMsU0FBU2tDLEVBQUVFLE9BQU9DLEtBQUs7QUFBQSxnQkFDeEMsYUFBWTtBQUFBLGdCQUNaLFdBQVU7QUFBQTtBQUFBLGNBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSXVMO0FBQUEsWUFFdkwsdUJBQUMsU0FBSSxXQUFVLCtFQUNiLGlDQUFDLFNBQUksV0FBVSxxQkFDWjlCLHFCQUNDLHVCQUFDLFVBQUssV0FBVSxpQ0FBZ0MsbUNBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1FLElBQ2pFRixhQUFhLFFBQVFBLGFBQWEsSUFDcEMsdUJBQUMsU0FBSSxXQUFVLG9DQUFvQ0Ysb0JBQVUsY0FBY0UsUUFBUSxNQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzRixJQUNwRkYsU0FDRix1QkFBQyxTQUFJLFdBQVUsb0NBQW9DQSxvQkFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEQsSUFDeERGLFNBQ0YsdUJBQUMsU0FBSSxXQUFVLHNDQUFzQ0Esb0JBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRELElBRTVELHVCQUFDLFVBQUssV0FBVSx3QkFBdUIsOENBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFFLEtBVnpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBWUEsS0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWNBO0FBQUEsZUFyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFzQkE7QUFBQSxhQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMkJBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsMkNBRWI7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsc0RBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVMsTUFBTWEsYUFBYSxNQUFNO0FBQUEsZ0JBQ2xDLFdBQVcsZ0ZBQ1RELGNBQWMsU0FDVix5REFDQSxtQ0FBbUM7QUFBQSxnQkFDdEM7QUFBQTtBQUFBLGNBTkw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBU0E7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUyxNQUFNQyxhQUFhLFlBQVk7QUFBQSxnQkFDeEMsV0FBVyxnRkFDVEQsY0FBYyxlQUNWLDJEQUNBLG1DQUFtQztBQUFBLGdCQUN0QztBQUFBO0FBQUEsY0FOTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFTQTtBQUFBLGVBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBcUJBO0FBQUEsVUFHQSx1QkFBQyxTQUFJLFdBQVUsb0RBQ1pBLHdCQUFjLFNBQ2IsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHlCQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsSUFBRztBQUFBLGtCQUNILE1BQUs7QUFBQSxrQkFDTCxPQUFPRTtBQUFBQSxrQkFDUCxVQUFVLENBQUNtQixNQUFNbEIsZ0JBQWdCa0IsRUFBRUUsT0FBT0MsS0FBSztBQUFBLGtCQUMvQyxhQUFZO0FBQUEsa0JBQ1osV0FBVTtBQUFBLGtCQUNWLFdBQVcsQ0FBQ0gsTUFBTUEsRUFBRW1DLFFBQVEsV0FBV25CLGNBQWM7QUFBQTtBQUFBLGdCQVB2RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FPeUQ7QUFBQSxjQUV6RDtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxTQUFTQTtBQUFBQSxrQkFDVCxVQUFVL0I7QUFBQUEsa0JBQ1YsV0FBVTtBQUFBLGtCQUVUQSwwQkFBZ0IsY0FBYztBQUFBO0FBQUEsZ0JBTGpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU1BO0FBQUEsaUJBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaUJBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsa0NBQ1pBLDBCQUNDLHVCQUFDLFNBQUksV0FBVSwyQ0FDYixpQ0FBQyxXQUFRLE9BQU0sMkJBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0MsS0FEeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQSxJQUNFRixTQUNGO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLHlCQUF5QixFQUFFcUQsUUFBUVYsZUFBZTNDLE1BQU0sRUFBRTtBQUFBO0FBQUEsY0FGNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBRThELElBRzlELHVCQUFDLFNBQUksV0FBVSx3RUFBc0UsK0NBQXJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUEsS0FiSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWVBO0FBQUEsZUFuQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFvQ0EsSUFFQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsaUZBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsT0FBT0k7QUFBQUEsa0JBQ1AsVUFBVSxDQUFDYSxNQUFNWixzQkFBc0JZLEVBQUVFLE9BQU9DLEtBQUs7QUFBQSxrQkFDckQsYUFBWTtBQUFBLGtCQUNaLFdBQVU7QUFBQTtBQUFBLGdCQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtxSDtBQUFBLGNBRXJIO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFNBQVNnQjtBQUFBQSxrQkFDVCxVQUFVOUI7QUFBQUEsa0JBQ1YsV0FBVTtBQUFBLGtCQUVUQSw4QkFBb0IsaUJBQWlCO0FBQUE7QUFBQSxnQkFMeEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTUE7QUFBQSxpQkFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWVBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsa0NBQ1pBLDhCQUNDLHVCQUFDLFNBQUksV0FBVSw4REFDYjtBQUFBLHFDQUFDLFdBQVEsT0FBTSxNQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlCO0FBQUEsY0FDakIsdUJBQUMsVUFBSyxXQUFVLHFDQUFvQyw0Q0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0Y7QUFBQSxpQkFGbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQSxJQUNFRSxhQUNGLHVCQUFDLFNBQUksV0FBVSw0REFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxtRUFDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLHlDQUFDLFVBQUssV0FBVywyQkFDZkEsV0FBVytCLFNBQVMsS0FDaEIsbUJBQ0EvQixXQUFXK0IsU0FBUyxLQUNwQixvQkFDQSxjQUFjLElBRWpCL0IscUJBQVcrQixTQVBkO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBUUE7QUFBQSxrQkFDQSx1QkFBQyxVQUFLLFdBQVUscUNBQW9DLG9CQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF3RDtBQUFBLHFCQVYxRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVdBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FDRS9CLHFCQUFXZ0MsYUFDVix1QkFBQyxVQUFLLFdBQVUsK0VBQTZFLHlCQUE3RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBLElBRUEsdUJBQUMsVUFBSyxXQUFVLDZFQUEyRSw0QkFBM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQSxLQVJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBVUE7QUFBQSxtQkF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF3QkE7QUFBQSxjQUVBLHVCQUFDLFNBQ0M7QUFBQSx1Q0FBQyxPQUFFLFdBQVUsbUVBQWtFLHdCQUEvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1RjtBQUFBLGdCQUN2Rix1QkFBQyxPQUFFLFdBQVUseUJBQXlCaEMscUJBQVc4QyxZQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEwRDtBQUFBLG1CQUY1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FFQzlDLFdBQVcrQyxhQUFhQyxTQUFTLEtBQ2hDLHVCQUFDLFNBQ0M7QUFBQSx1Q0FBQyxPQUFFLFdBQVUsaUVBQWdFLHNDQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFtRztBQUFBLGdCQUNuRyx1QkFBQyxRQUFHLFdBQVUsa0RBQ1hoRCxxQkFBVytDLGFBQWFFO0FBQUFBLGtCQUFJLENBQUNDLEtBQUtDLFFBQ2pDLHVCQUFDLFFBQWNELGlCQUFOQyxLQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQW1CO0FBQUEsZ0JBQ3BCLEtBSEg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFJQTtBQUFBLG1CQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBT0E7QUFBQSxpQkF4Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEwQ0EsSUFFQSx1QkFBQyxTQUFJLFdBQVUsd0VBQXNFLCtFQUFyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBLEtBckRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBdURBO0FBQUEsZUF6RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEwRUEsS0FsSEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFvSEE7QUFBQSxhQTlJRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBK0lBO0FBQUEsV0EvS0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdMQTtBQUFBLFNBdE5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1TkE7QUFBQSxJQUdBLHVCQUFDLFlBQU8sV0FBVSw0RkFDaEI7QUFBQSw2QkFBQyxVQUFLLFdBQVUscUNBQW1DO0FBQUE7QUFBQSxRQUN0Q2pHLGVBQWVlLFFBQVE7QUFBQSxXQURwQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFVBQUssV0FBVSwrQ0FDYnNFLHdCQUFjLEtBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9BO0FBQUEsT0ExUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTJQQTtBQUVKO0FBQUM1RSxHQWphdUJELGVBQWE7QUFBQSxLQUFiQTtBQUFhLElBQUEwRjtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIkNvZGVFZGl0b3IiLCJsYW5ndWFnZVRlbXBsYXRlcyIsImxhbmd1YWdlTGFiZWxzIiwicnVuQ29kZSIsImdldEhpbnQiLCJldmFsdWF0ZUNvZGUiLCJsb2dQcm9ncmVzcyIsImdldFByb2dyZXNzIiwidG9hc3QiLCJTcGlubmVyIiwiUHJhY3RpY2VBcmVuYSIsIl9zIiwibGFuZ3VhZ2VzIiwiT2JqZWN0Iiwia2V5cyIsImZpbHRlciIsImwiLCJsYW5ndWFnZSIsInNldExhbmd1YWdlIiwiY29kZSIsInNldENvZGUiLCJweXRob24iLCJzdGRpbiIsInNldFN0ZGluIiwic3Rkb3V0Iiwic2V0U3Rkb3V0Iiwic3RkZXJyIiwic2V0U3RkZXJyIiwiZXhpdENvZGUiLCJzZXRFeGl0Q29kZSIsInRpbWVkT3V0Iiwic2V0VGltZWRPdXQiLCJpc1J1bm5pbmciLCJzZXRJc1J1bm5pbmciLCJzb2x2ZWRDb3VudCIsInNldFNvbHZlZENvdW50IiwiYWN0aXZlVGFiIiwic2V0QWN0aXZlVGFiIiwidXNlclF1ZXN0aW9uIiwic2V0VXNlclF1ZXN0aW9uIiwiYWlIaW50Iiwic2V0QWlIaW50IiwiaXNIaW50TG9hZGluZyIsInNldElzSGludExvYWRpbmciLCJwcm9ibGVtRGVzY3JpcHRpb24iLCJzZXRQcm9ibGVtRGVzY3JpcHRpb24iLCJpc0V2YWx1YXRlTG9hZGluZyIsInNldElzRXZhbHVhdGVMb2FkaW5nIiwiZXZhbFJlc3VsdCIsInNldEV2YWxSZXN1bHQiLCJmZXRjaFByb2dyZXNzIiwiZGF0YSIsInRvdGFsX3NvbHZlZCIsImVyciIsImNvbnNvbGUiLCJlcnJvciIsImhhbmRsZUxhbmd1YWdlQ2hhbmdlIiwiZSIsIm5leHRMYW5nIiwidGFyZ2V0IiwidmFsdWUiLCJwcmV2VGVtcGxhdGUiLCJuZXh0VGVtcGxhdGUiLCJzaG91bGRTd2FwIiwid2luZG93IiwiY29uZmlybSIsImhhbmRsZVJ1bkNvZGUiLCJyZXN1bHQiLCJzb3VyY2VfY29kZSIsInRyaW0iLCJ1bmRlZmluZWQiLCJleGl0X2NvZGUiLCJ0aW1lZF9vdXQiLCJoYW5kbGVHZXRIaW50IiwidXNlcl9xdWVzdGlvbiIsImhpbnQiLCJoYW5kbGVFdmFsdWF0ZSIsInByb2JsZW1fZGVzY3JpcHRpb24iLCJhaV9zY29yZSIsInNjb3JlIiwiaXNfY29ycmVjdCIsInN1Y2Nlc3MiLCJsb2dFcnIiLCJyZW5kZXJNYXJrZG93biIsInRleHQiLCJodG1sIiwicmVwbGFjZSIsImdldFN0YXR1c1RleHQiLCJpbnAiLCJkb2N1bWVudCIsImdldEVsZW1lbnRCeUlkIiwiZm9jdXMiLCJrZXkiLCJfX2h0bWwiLCJmZWVkYmFjayIsImltcHJvdmVtZW50cyIsImxlbmd0aCIsIm1hcCIsInRpcCIsImlkeCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlByYWN0aWNlQXJlbmEudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCBDb2RlRWRpdG9yIGZyb20gXCIuLi9jb21wb25lbnRzL2VkaXRvci9Db2RlRWRpdG9yXCI7XG5pbXBvcnQgeyBsYW5ndWFnZVRlbXBsYXRlcywgU3VwcG9ydGVkTGFuZ3VhZ2UsIGxhbmd1YWdlTGFiZWxzIH0gZnJvbSBcIi4uL2NvbnN0YW50cy90ZW1wbGF0ZXNcIjtcbmltcG9ydCB7IHJ1bkNvZGUsIGdldEhpbnQsIGV2YWx1YXRlQ29kZSwgbG9nUHJvZ3Jlc3MsIGdldFByb2dyZXNzIH0gZnJvbSBcIi4uL2FwaS9wcmFjdGljZVwiO1xuaW1wb3J0IHRvYXN0IGZyb20gXCJyZWFjdC1ob3QtdG9hc3RcIjtcbmltcG9ydCBTcGlubmVyIGZyb20gXCIuLi9jb21wb25lbnRzL3VpL1NwaW5uZXJcIjtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUHJhY3RpY2VBcmVuYSgpIHtcbiAgY29uc3QgbGFuZ3VhZ2VzID0gT2JqZWN0LmtleXMobGFuZ3VhZ2VMYWJlbHMpLmZpbHRlcihsID0+IGwgIT09IFwic3dpZnRcIikgYXMgU3VwcG9ydGVkTGFuZ3VhZ2VbXTtcbiAgY29uc3QgW2xhbmd1YWdlLCBzZXRMYW5ndWFnZV0gPSB1c2VTdGF0ZTxTdXBwb3J0ZWRMYW5ndWFnZT4oXCJweXRob25cIik7XG4gIGNvbnN0IFtjb2RlLCBzZXRDb2RlXSA9IHVzZVN0YXRlKGxhbmd1YWdlVGVtcGxhdGVzLnB5dGhvbik7XG4gIGNvbnN0IFtzdGRpbiwgc2V0U3RkaW5dID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFtzdGRvdXQsIHNldFN0ZG91dF0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW3N0ZGVyciwgc2V0U3RkZXJyXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbZXhpdENvZGUsIHNldEV4aXRDb2RlXSA9IHVzZVN0YXRlPG51bWJlciB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbdGltZWRPdXQsIHNldFRpbWVkT3V0XSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2lzUnVubmluZywgc2V0SXNSdW5uaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3NvbHZlZENvdW50LCBzZXRTb2x2ZWRDb3VudF0gPSB1c2VTdGF0ZSgwKTtcbiAgY29uc3QgW2FjdGl2ZVRhYiwgc2V0QWN0aXZlVGFiXSA9IHVzZVN0YXRlPFwiaGludFwiIHwgXCJldmFsdWF0aW9uXCI+KFwiaGludFwiKTtcbiAgY29uc3QgW3VzZXJRdWVzdGlvbiwgc2V0VXNlclF1ZXN0aW9uXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbYWlIaW50LCBzZXRBaUhpbnRdID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFtpc0hpbnRMb2FkaW5nLCBzZXRJc0hpbnRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgXG4gIGNvbnN0IFtwcm9ibGVtRGVzY3JpcHRpb24sIHNldFByb2JsZW1EZXNjcmlwdGlvbl0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW2lzRXZhbHVhdGVMb2FkaW5nLCBzZXRJc0V2YWx1YXRlTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtldmFsUmVzdWx0LCBzZXRFdmFsUmVzdWx0XSA9IHVzZVN0YXRlPHtcbiAgICBpc19jb3JyZWN0OiBib29sZWFuO1xuICAgIHNjb3JlOiBudW1iZXI7XG4gICAgZmVlZGJhY2s6IHN0cmluZztcbiAgICBpbXByb3ZlbWVudHM6IHN0cmluZ1tdO1xuICB9IHwgbnVsbD4obnVsbCk7XG5cbiAgY29uc3QgZmV0Y2hQcm9ncmVzcyA9IGFzeW5jICgpID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IGdldFByb2dyZXNzKCk7XG4gICAgICBzZXRTb2x2ZWRDb3VudChkYXRhLnRvdGFsX3NvbHZlZCk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiVW5hYmxlIHRvIGxvYWQgcHJhY3RpY2UgcHJvZ3Jlc3NcIiwgZXJyKTtcbiAgICB9XG4gIH07XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICB2b2lkIGZldGNoUHJvZ3Jlc3MoKTtcbiAgfSwgW10pO1xuXG4gIGNvbnN0IGhhbmRsZUxhbmd1YWdlQ2hhbmdlID0gKGU6IFJlYWN0LkNoYW5nZUV2ZW50PEhUTUxTZWxlY3RFbGVtZW50PikgPT4ge1xuICAgIGNvbnN0IG5leHRMYW5nID0gZS50YXJnZXQudmFsdWUgYXMgU3VwcG9ydGVkTGFuZ3VhZ2U7XG4gICAgY29uc3QgcHJldlRlbXBsYXRlID0gbGFuZ3VhZ2VUZW1wbGF0ZXNbbGFuZ3VhZ2VdO1xuICAgIGNvbnN0IG5leHRUZW1wbGF0ZSA9IGxhbmd1YWdlVGVtcGxhdGVzW25leHRMYW5nXTtcblxuICAgIGlmIChjb2RlID09PSBwcmV2VGVtcGxhdGUpIHtcbiAgICAgIC8vIFN3YXBwaW5nIHNpbGVudGx5IGlmIHVubW9kaWZpZWRcbiAgICAgIHNldExhbmd1YWdlKG5leHRMYW5nKTtcbiAgICAgIHNldENvZGUobmV4dFRlbXBsYXRlKTtcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc3Qgc2hvdWxkU3dhcCA9IHdpbmRvdy5jb25maXJtKFxuICAgICAgICBgUmVwbGFjZSBjdXJyZW50IGNvZGUgd2l0aCAke2xhbmd1YWdlTGFiZWxzW25leHRMYW5nXX0gc3RhcnRlciB0ZW1wbGF0ZT8gVGhpcyB3aWxsIGRpc2NhcmQgeW91ciBlZGl0cy5gXG4gICAgICApO1xuICAgICAgaWYgKHNob3VsZFN3YXApIHtcbiAgICAgICAgc2V0TGFuZ3VhZ2UobmV4dExhbmcpO1xuICAgICAgICBzZXRDb2RlKG5leHRUZW1wbGF0ZSk7XG4gICAgICB9XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVJ1bkNvZGUgPSBhc3luYyAoKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIHNldElzUnVubmluZyh0cnVlKTtcbiAgICAgIHNldFN0ZG91dChcIlwiKTtcbiAgICAgIHNldFN0ZGVycihcIlwiKTtcbiAgICAgIHNldEV4aXRDb2RlKG51bGwpO1xuICAgICAgc2V0VGltZWRPdXQoZmFsc2UpO1xuXG4gICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBydW5Db2RlKHtcbiAgICAgICAgc291cmNlX2NvZGU6IGNvZGUsXG4gICAgICAgIGxhbmd1YWdlLFxuICAgICAgICBzdGRpbjogc3RkaW4udHJpbSgpIHx8IHVuZGVmaW5lZFxuICAgICAgfSk7XG5cbiAgICAgIHNldFN0ZG91dChyZXN1bHQuc3Rkb3V0IHx8IFwiXCIpO1xuICAgICAgc2V0U3RkZXJyKHJlc3VsdC5zdGRlcnIgfHwgXCJcIik7XG4gICAgICBzZXRFeGl0Q29kZShyZXN1bHQuZXhpdF9jb2RlKTtcbiAgICAgIHNldFRpbWVkT3V0KHJlc3VsdC50aW1lZF9vdXQpO1xuXG4gICAgICBpZiAocmVzdWx0LmVycm9yKSB7XG4gICAgICAgIHNldFN0ZGVycihyZXN1bHQuZXJyb3IpO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgdG9hc3QuZXJyb3IoXCJGYWlsZWQgdG8gcnVuIGNvZGUuIE1ha2Ugc3VyZSBzYW5kYm94IGlzIHJ1bm5pbmcuXCIpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRJc1J1bm5pbmcoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBoYW5kbGVHZXRIaW50ID0gYXN5bmMgKCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBzZXRJc0hpbnRMb2FkaW5nKHRydWUpO1xuICAgICAgc2V0QWlIaW50KFwiXCIpO1xuICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgZ2V0SGludCh7XG4gICAgICAgIHNvdXJjZV9jb2RlOiBjb2RlLFxuICAgICAgICBsYW5ndWFnZSxcbiAgICAgICAgdXNlcl9xdWVzdGlvbjogdXNlclF1ZXN0aW9uLnRyaW0oKSB8fCB1bmRlZmluZWRcbiAgICAgIH0pO1xuICAgICAgc2V0QWlIaW50KHJlc3VsdC5oaW50KTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHNldEFpSGludChcIkFJIHVuYXZhaWxhYmxlLiBDaGVjayB5b3VyIGNvZGUgbWFudWFsbHkuXCIpO1xuICAgICAgdG9hc3QuZXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggQUkgaGludC5cIik7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldElzSGludExvYWRpbmcoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBoYW5kbGVFdmFsdWF0ZSA9IGFzeW5jICgpID0+IHtcbiAgICB0cnkge1xuICAgICAgc2V0SXNFdmFsdWF0ZUxvYWRpbmcodHJ1ZSk7XG4gICAgICBzZXRFdmFsUmVzdWx0KG51bGwpO1xuICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgZXZhbHVhdGVDb2RlKHtcbiAgICAgICAgc291cmNlX2NvZGU6IGNvZGUsXG4gICAgICAgIGxhbmd1YWdlLFxuICAgICAgICBzdGRvdXQ6IHN0ZG91dCB8fCBcIihObyBvdXRwdXQgcHJvZHVjZWQpXCIsXG4gICAgICAgIHByb2JsZW1fZGVzY3JpcHRpb246IHByb2JsZW1EZXNjcmlwdGlvbi50cmltKCkgfHwgdW5kZWZpbmVkXG4gICAgICB9KTtcbiAgICAgIHNldEV2YWxSZXN1bHQocmVzdWx0KTtcblxuICAgICAgdHJ5IHtcbiAgICAgICAgYXdhaXQgbG9nUHJvZ3Jlc3Moe1xuICAgICAgICAgIHNvdXJjZV9jb2RlOiBjb2RlLFxuICAgICAgICAgIGxhbmd1YWdlLFxuICAgICAgICAgIGFpX3Njb3JlOiByZXN1bHQuc2NvcmUsXG4gICAgICAgICAgaXNfY29ycmVjdDogcmVzdWx0LmlzX2NvcnJlY3RcbiAgICAgICAgfSk7XG4gICAgICAgIGlmIChyZXN1bHQuaXNfY29ycmVjdCkge1xuICAgICAgICAgIHRvYXN0LnN1Y2Nlc3MoXCJQcm9ncmVzcyBzYXZlZCEg4pyTXCIpO1xuICAgICAgICAgIHZvaWQgZmV0Y2hQcm9ncmVzcygpO1xuICAgICAgICB9XG4gICAgICB9IGNhdGNoIChsb2dFcnIpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIlVuYWJsZSB0byBsb2cgcHJvZ3Jlc3NcIiwgbG9nRXJyKTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHRvYXN0LmVycm9yKFwiQUkgRXZhbHVhdGlvbiBmYWlsZWQuXCIpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRJc0V2YWx1YXRlTG9hZGluZyhmYWxzZSk7XG4gICAgfVxuICB9O1xuXG4gIC8vIEJhc2ljIE1hcmtkb3duIFJlbmRlcmVyXG4gIGNvbnN0IHJlbmRlck1hcmtkb3duID0gKHRleHQ6IHN0cmluZykgPT4ge1xuICAgIGlmICghdGV4dCkgcmV0dXJuIFwiXCI7XG4gICAgLy8gU2FuaXRpemUgZmlyc3QgYnkgc3RyaXBwaW5nIDxzY3JpcHQ+IHRhZ3NcbiAgICBsZXQgaHRtbCA9IHRleHQucmVwbGFjZSgvPHNjcmlwdFxcYltePF0qKD86KD8hPFxcL3NjcmlwdD4pPFtePF0qKSo8XFwvc2NyaXB0Pi9naSwgXCJcIik7XG5cbiAgICAvLyBDb2RlIGJsb2NrcyAoYGBgYmxvY2tgYGApXG4gICAgaHRtbCA9IGh0bWwucmVwbGFjZSgvYGBgKD86XFx3Kyk/XFxuPyhbXFxzXFxTXSo/KWBgYC9nLCAnPHByZSBjbGFzcz1cImJnLWdyYXktOTAwIHAtMiByb3VuZGVkIHRleHQtZ3JlZW4tNDAwIHRleHQteHMgb3ZlcmZsb3ctYXV0byBmb250LW1vbm8gbXktMiBib3JkZXIgYm9yZGVyLWdyYXktODAwXCI+JDE8L3ByZT4nKTtcblxuICAgIC8vIElubGluZSBjb2RlIChgY29kZWApXG4gICAgaHRtbCA9IGh0bWwucmVwbGFjZSgvYChbXmBdKylgL2csICc8Y29kZSBjbGFzcz1cImJnLWdyYXktOTAwIHB4LTEgcm91bmRlZCB0ZXh0LWdyZWVuLTQwMCBmb250LW1vbm8gZm9udC1tZWRpdW1cIj4kMTwvY29kZT4nKTtcblxuICAgIC8vIEJvbGQgKCoqYm9sZCoqKVxuICAgIGh0bWwgPSBodG1sLnJlcGxhY2UoL1xcKlxcKihbXipdKylcXCpcXCovZywgJzxzdHJvbmc+JDE8L3N0cm9uZz4nKTtcblxuICAgIHJldHVybiBodG1sO1xuICB9O1xuXG4gIC8vIFN0YXR1cyBCYXIgaGVscGVyc1xuICBjb25zdCBnZXRTdGF0dXNUZXh0ID0gKCkgPT4ge1xuICAgIGlmIChpc1J1bm5pbmcpIHJldHVybiBcIlJ1bm5pbmcuLi5cIjtcbiAgICBpZiAoaXNIaW50TG9hZGluZyB8fCBpc0V2YWx1YXRlTG9hZGluZykgcmV0dXJuIFwiQUkgVGhpbmtpbmcuLi5cIjtcbiAgICByZXR1cm4gXCJSZWFkeVwiO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGgtc2NyZWVuIGJnLWdyYXktOTAwIHRleHQtd2hpdGUgb3ZlcmZsb3ctaGlkZGVuIHNlbGVjdC1ub25lXCI+XG4gICAgICB7LyogUk9XIDE6IFRvcCBCYXIgKGgtMTIpICovfVxuICAgICAgPGhlYWRlciBjbGFzc05hbWU9XCJoLTEyIGJnLWdyYXktODAwIGJvcmRlci1iIGJvcmRlci1ncmF5LTcwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcHgtNCB6LTEwIHNocmluay0wXCI+XG4gICAgICAgIDxoMSBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtd2hpdGUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgIDxzcGFuPuKaoTwvc3Bhbj4gQml0TGFicyBQcmFjdGljZSBBcmVuYVxuICAgICAgICA8L2gxPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgdmFsdWU9e2xhbmd1YWdlfVxuICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUxhbmd1YWdlQ2hhbmdlfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZCBib3JkZXIgYm9yZGVyLWluZGlnby03MDAgYmctaW5kaWdvLTgwMCB0ZXh0LXdoaXRlIHB4LTIgcHktMSB0ZXh0LXNtIG91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItaW5kaWdvLTUwMCBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy1pbmRpZ28tNTAwXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwicHl0aG9uXCI+UHl0aG9uPC9vcHRpb24+XG4gICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiY1wiPkM8L29wdGlvbj5cbiAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJjcHBcIj5DKys8L29wdGlvbj5cbiAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJqYXZhXCI+SmF2YTwvb3B0aW9uPlxuICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImphdmFzY3JpcHRcIj5KYXZhU2NyaXB0PC9vcHRpb24+XG4gICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicm91bmRlZCBiZy1ncmVlbi02MDAgcHgtMi41IHB5LTAuNSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdHJhY2tpbmctd2lkZSB0ZXh0LXdoaXRlIHVwcGVyY2FzZVwiPlxuICAgICAgICAgICAgU29sdmVkOiB7c29sdmVkQ291bnR9XG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvaGVhZGVyPlxuXG4gICAgICB7LyogUk9XIDI6IE1haW4gQXJlYSAoZmxleC0xKSAqL31cbiAgICAgIDxtYWluIGNsYXNzTmFtZT1cImZsZXgtMSBmbGV4IG1pbi1oLTAgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgIHsvKiBMZWZ0IFBhbmVsICh3LTMvNSkgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0zLzUgZmxleCBmbGV4LWNvbCBib3JkZXItciBib3JkZXItZ3JheS03MDAgYmctZ3JheS05MDBcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBtaW4taC0wIHJlbGF0aXZlXCI+XG4gICAgICAgICAgICA8Q29kZUVkaXRvciBsYW5ndWFnZT17bGFuZ3VhZ2V9IHZhbHVlPXtjb2RlfSBvbkNoYW5nZT17c2V0Q29kZX0gaGVpZ2h0Q2xhc3M9XCJoLWZ1bGxcIiAvPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIEFjdGlvbiBCYXIgKHAtMikgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTgwMCBwLTIgZmxleCBnYXAtMiBib3JkZXItdCBib3JkZXItZ3JheS03MDAgc2hyaW5rLTBcIj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlUnVuQ29kZX1cbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzUnVubmluZ31cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgYmctZ3JheS03MDAgaG92ZXI6YmctZ3JheS02MDAgZGlzYWJsZWQ6b3BhY2l0eS01MCB0ZXh0LXdoaXRlIHRleHQtc20gZm9udC1tZWRpdW0gcHktMS41IHB4LTQgcm91bmRlZCBib3JkZXIgYm9yZGVyLWdyYXktNjAwIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAge2lzUnVubmluZyA/IDxTcGlubmVyIGxhYmVsPVwiXCIgLz4gOiBcIuKWtiBSdW5cIn1cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgc2V0QWN0aXZlVGFiKFwiaGludFwiKTtcbiAgICAgICAgICAgICAgICAvLyBGb2N1cyBpbnB1dCBmaWVsZCBpZiBwb3NzaWJsZVxuICAgICAgICAgICAgICAgIGNvbnN0IGlucCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiYWktaGludC1pbnB1dFwiKTtcbiAgICAgICAgICAgICAgICBpZiAoaW5wKSBpbnAuZm9jdXMoKTtcbiAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgYmctYmx1ZS02MDAgaG92ZXI6YmctYmx1ZS03MDAgdGV4dC13aGl0ZSB0ZXh0LXNtIGZvbnQtbWVkaXVtIHB5LTEuNSBweC00IHJvdW5kZWQgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8c3Bhbj7wn5KhPC9zcGFuPiBIaW50XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlRXZhbHVhdGV9XG4gICAgICAgICAgICAgIGRpc2FibGVkPXtpc0V2YWx1YXRlTG9hZGluZ31cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgYmctZ3JlZW4tNjAwIGhvdmVyOmJnLWdyZWVuLTcwMCBkaXNhYmxlZDpvcGFjaXR5LTUwIHRleHQtd2hpdGUgdGV4dC1zbSBmb250LW1lZGl1bSBweS0xLjUgcHgtNCByb3VuZGVkIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAge2lzRXZhbHVhdGVMb2FkaW5nID8gPFNwaW5uZXIgbGFiZWw9XCJcIiAvPiA6IFwi4pyTIEV2YWx1YXRlXCJ9XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIFJpZ2h0IFBhbmVsICh3LTIvNSkgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0yLzUgZmxleCBmbGV4LWNvbCBiZy1ncmF5LTgwMCBib3JkZXItbCBib3JkZXItZ3JheS03MDAgbWluLWgtMFwiPlxuICAgICAgICAgIHsvKiBUb3AgSGFsZjogQ29uc29sZSAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtMS8yIGZsZXggZmxleC1jb2wgYm9yZGVyLWIgYm9yZGVyLWdyYXktNzAwIG1pbi1oLTBcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNDAwIHAtMiBzaHJpbmstMCBzZWxlY3Qtbm9uZSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgZm9udC1zZW1pYm9sZFwiPlxuICAgICAgICAgICAgICBDb25zb2xlXG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIGZsZXggZmxleC1jb2wgcC0yIHNwYWNlLXktMiBtaW4taC0wXCI+XG4gICAgICAgICAgICAgIDx0ZXh0YXJlYVxuICAgICAgICAgICAgICAgIHZhbHVlPXtzdGRpbn1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFN0ZGluKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cInN0ZGluIGlucHV0Li4uXCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xNiByZXNpemUtbm9uZSBwLTIgcm91bmRlZCBiZy1ncmF5LTkwMCB0ZXh0LWdyZWVuLTQwMCBmb250LW1vbm8gdGV4dC1zbSBwbGFjZWhvbGRlci1ncmF5LTYwMCBib3JkZXIgYm9yZGVyLWdyYXktNzUwIG91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItZ3JlZW4tNTAwIHNocmluay0wXCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgYmctZ3JheS05MDAgYm9yZGVyIGJvcmRlci1ncmF5LTc1MCByb3VuZGVkIHAtMiBvdmVyZmxvdy1hdXRvIG1pbi1oLTBcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LXNtXCI+XG4gICAgICAgICAgICAgICAgICB7dGltZWRPdXQgPyAoXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteWVsbG93LTQwMCBmb250LXNlbWlib2xkXCI+RXhlY3V0aW9uIHRpbWVkIG91dDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICkgOiBleGl0Q29kZSAhPT0gbnVsbCAmJiBleGl0Q29kZSAhPT0gMCA/IChcbiAgICAgICAgICAgICAgICAgICAgPHByZSBjbGFzc05hbWU9XCJ0ZXh0LXJlZC00MDAgd2hpdGVzcGFjZS1wcmUtd3JhcFwiPntzdGRlcnIgfHwgYEV4aXQgQ29kZTogJHtleGl0Q29kZX1gfTwvcHJlPlxuICAgICAgICAgICAgICAgICAgKSA6IHN0ZGVyciA/IChcbiAgICAgICAgICAgICAgICAgICAgPHByZSBjbGFzc05hbWU9XCJ0ZXh0LXJlZC00MDAgd2hpdGVzcGFjZS1wcmUtd3JhcFwiPntzdGRlcnJ9PC9wcmU+XG4gICAgICAgICAgICAgICAgICApIDogc3Rkb3V0ID8gKFxuICAgICAgICAgICAgICAgICAgICA8cHJlIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNDAwIHdoaXRlc3BhY2UtcHJlLXdyYXBcIj57c3Rkb3V0fTwvcHJlPlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMCBpdGFsaWNcIj5SdW4geW91ciBjb2RlIHRvIHNlZSBvdXRwdXQuLi48L3NwYW4+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIEJvdHRvbSBIYWxmOiBBSSBQYW5lbCAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtMS8yIGZsZXggZmxleC1jb2wgbWluLWgtMCBiZy1ncmF5LTg1MFwiPlxuICAgICAgICAgICAgey8qIFRhYiBCYXIgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYXktOTAwIGJvcmRlci1iIGJvcmRlci1ncmF5LTcwMCBmbGV4IHNocmluay0wXCI+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUYWIoXCJoaW50XCIpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXgtMSBweS0yIHRleHQteHMgZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdHJhbnNpdGlvbi1jb2xvcnMgJHtcbiAgICAgICAgICAgICAgICAgIGFjdGl2ZVRhYiA9PT0gXCJoaW50XCJcbiAgICAgICAgICAgICAgICAgICAgPyBcImJnLWdyYXktODAwIHRleHQtYmx1ZS00MDAgYm9yZGVyLWItMiBib3JkZXItYmx1ZS01MDBcIlxuICAgICAgICAgICAgICAgICAgICA6IFwidGV4dC1ncmF5LTQwMCBob3Zlcjp0ZXh0LWdyYXktMjAwXCJcbiAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIPCfkqEgSGludFxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVRhYihcImV2YWx1YXRpb25cIil9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleC0xIHB5LTIgdGV4dC14cyBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0cmFuc2l0aW9uLWNvbG9ycyAke1xuICAgICAgICAgICAgICAgICAgYWN0aXZlVGFiID09PSBcImV2YWx1YXRpb25cIlxuICAgICAgICAgICAgICAgICAgICA/IFwiYmctZ3JheS04MDAgdGV4dC1ncmVlbi00MDAgYm9yZGVyLWItMiBib3JkZXItZ3JlZW4tNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgOiBcInRleHQtZ3JheS00MDAgaG92ZXI6dGV4dC1ncmF5LTIwMFwiXG4gICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICDwn5OKIEV2YWx1YXRlXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBBSSBDb250ZW50IEFyZWEgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBvdmVyZmxvdy15LWF1dG8gcC0yIG1pbi1oLTAgZmxleCBmbGV4LWNvbFwiPlxuICAgICAgICAgICAgICB7YWN0aXZlVGFiID09PSBcImhpbnRcIiA/IChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBmbGV4IGZsZXgtY29sIG1pbi1oLTAgc3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTEuNSBzaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cImFpLWhpbnQtaW5wdXRcIlxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXNlclF1ZXN0aW9ufVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0VXNlclF1ZXN0aW9uKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkFzayBhYm91dCB5b3VyIGNvZGUuLi5cIlxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNzAwIHRleHQtd2hpdGUgcm91bmRlZCBwLTEuNSB0ZXh0LXNtIGZsZXgtMSBvdXRsaW5lLW5vbmUgYm9yZGVyIGJvcmRlci1ncmF5LTY1MCBmb2N1czpib3JkZXItYmx1ZS01MDBcIlxuICAgICAgICAgICAgICAgICAgICAgIG9uS2V5RG93bj17KGUpID0+IGUua2V5ID09PSBcIkVudGVyXCIgJiYgaGFuZGxlR2V0SGludCgpfVxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlR2V0SGludH1cbiAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNIaW50TG9hZGluZ31cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ibHVlLTYwMCBob3ZlcjpiZy1ibHVlLTcwMCB0ZXh0LXdoaXRlIHRleHQtc20gZm9udC1zZW1pYm9sZCByb3VuZGVkIHB4LTQgcHktMS41IHRyYW5zaXRpb24tY29sb3JzIGRpc2FibGVkOm9wYWNpdHktNTBcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAge2lzSGludExvYWRpbmcgPyBcIkFza2luZy4uLlwiIDogXCJBc2tcIn1cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgbWluLWgtMCBvdmVyZmxvdy15LWF1dG9cIj5cbiAgICAgICAgICAgICAgICAgICAge2lzSGludExvYWRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxTcGlubmVyIGxhYmVsPVwiQUkgaXMgbG9hZGluZyBoaW50Li4uXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKSA6IGFpSGludCA/IChcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTcwMCByb3VuZGVkIHAtMyB0ZXh0LXNtIHRleHQtZ3JheS0yMDAgd2hpdGVzcGFjZS1wcmUtd3JhcCBsZWFkaW5nLXJlbGF4ZWQgYm9yZGVyIGJvcmRlci1ncmF5LTY1MCBzaGFkb3ctaW5uZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgZGFuZ2Vyb3VzbHlTZXRJbm5lckhUTUw9e3sgX19odG1sOiByZW5kZXJNYXJrZG93bihhaUhpbnQpIH19XG4gICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LWdyYXktNTAwIHRleHQtc20gaXRhbGljXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBBc2sgQUkgYW55dGhpbmcgYWJvdXQgeW91ciBjb2RlXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBmbGV4IGZsZXgtY29sIG1pbi1oLTAgc3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTEuNSBzaHJpbmstMCBwLTEgYmctZ3JheS04MDAgcm91bmRlZCBib3JkZXIgYm9yZGVyLWdyYXktNzAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cHJvYmxlbURlc2NyaXB0aW9ufVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UHJvYmxlbURlc2NyaXB0aW9uKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkRlc2NyaWJlIHdoYXQgeW91J3JlIHRyeWluZyB0byBzb2x2ZSAob3B0aW9uYWwpLi4uXCJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTc1MCB0ZXh0LXdoaXRlIHJvdW5kZWQgcC0xLjUgdGV4dC1zbSBvdXRsaW5lLW5vbmUgYm9yZGVyIGJvcmRlci1ncmF5LTY1MCBmb2N1czpib3JkZXItZ3JlZW4tNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUV2YWx1YXRlfVxuICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc0V2YWx1YXRlTG9hZGluZ31cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmVlbi02MDAgaG92ZXI6YmctZ3JlZW4tNzAwIHRleHQtd2hpdGUgdGV4dC1zbSBmb250LXNlbWlib2xkIHJvdW5kZWQgcHktMiB0cmFuc2l0aW9uLWNvbG9ycyBkaXNhYmxlZDpvcGFjaXR5LTUwIHctZnVsbFwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICB7aXNFdmFsdWF0ZUxvYWRpbmcgPyBcIlJldmlld2luZy4uLlwiIDogXCJFdmFsdWF0ZSBNeSBDb2RlXCJ9XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG1pbi1oLTAgb3ZlcmZsb3cteS1hdXRvXCI+XG4gICAgICAgICAgICAgICAgICAgIHtpc0V2YWx1YXRlTG9hZGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtZnVsbCBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxTcGlubmVyIGxhYmVsPVwiXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTQwMCBmb250LW1lZGl1bVwiPkFJIGlzIHJldmlld2luZyB5b3VyIGNvZGUuLi48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICkgOiBldmFsUmVzdWx0ID8gKFxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS03MDAgcm91bmRlZCBwLTMgYm9yZGVyIGJvcmRlci1ncmF5LTY1MCBzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGJvcmRlci1iIGJvcmRlci1ncmF5LTYwMCBwYi0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1iYXNlbGluZSBnYXAtMC41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgdGV4dC0zeGwgZm9udC1leHRyYWJvbGQgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV2YWxSZXN1bHQuc2NvcmUgPj0gNzBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcInRleHQtZ3JlZW4tNDAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBldmFsUmVzdWx0LnNjb3JlID49IDQwXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJ0ZXh0LXllbGxvdy00MDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwidGV4dC1yZWQtNDAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXZhbFJlc3VsdC5zY29yZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMCB0ZXh0LXhzIGZvbnQtbWVkaXVtXCI+LzEwMDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2V2YWxSZXN1bHQuaXNfY29ycmVjdCA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJnLWdyZWVuLTYwMCBweC0yIHB5LTAuNSByb3VuZGVkIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXdoaXRlIHNoYWRvdy1zbVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDinJMgQ29ycmVjdFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiZy1yZWQtNjAwIHB4LTIgcHktMC41IHJvdW5kZWQgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtd2hpdGUgc2hhZG93LXNtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKclyBOZWVkcyBXb3JrXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1ncmF5LTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgbWItMC41XCI+RmVlZGJhY2s8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS0zMDAgdGV4dC1zbVwiPntldmFsUmVzdWx0LmZlZWRiYWNrfTwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXZhbFJlc3VsdC5pbXByb3ZlbWVudHMubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1ncmF5LTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgbWItMVwiPlN1Z2dlc3RlZCBJbXByb3ZlbWVudHM8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cImxpc3QtZGlzYyBwbC00IHRleHQtc20gdGV4dC1ncmF5LTM1MCBzcGFjZS15LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtldmFsUmVzdWx0LmltcHJvdmVtZW50cy5tYXAoKHRpcCwgaWR4KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsaSBrZXk9e2lkeH0+e3RpcH08L2xpPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtZ3JheS01MDAgdGV4dC1zbSBpdGFsaWNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIFJlYWR5IHRvIGV2YWx1YXRlPyBGaWxsIGluIHRoZSBkZXRhaWxzIGFib3ZlIG9yIGNsaWNrIEV2YWx1YXRlLlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L21haW4+XG5cbiAgICAgIHsvKiBST1cgMzogU3RhdHVzIEJhciAoaC02KSAqL31cbiAgICAgIDxmb290ZXIgY2xhc3NOYW1lPVwiaC02IGJnLWdyYXktOTAwIGJvcmRlci10IGJvcmRlci1ncmF5LTcwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcHgtMyBzaHJpbmstMFwiPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgZm9udC1tZWRpdW1cIj5cbiAgICAgICAgICBMYW5ndWFnZToge2xhbmd1YWdlTGFiZWxzW2xhbmd1YWdlXX1cbiAgICAgICAgPC9zcGFuPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgZm9udC1tZWRpdW0gZm9udC1tb25vXCI+XG4gICAgICAgICAge2dldFN0YXR1c1RleHQoKX1cbiAgICAgICAgPC9zcGFuPlxuICAgICAgPC9mb290ZXI+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6IkM6L1VzZXJzL1lhc3dhbnRoIFJhaHVsL0Rvd25sb2Fkcy9CaXRMYWJzLUNvZGluZy1MYWIvZnJvbnRlbmQvc3JjL3JvdXRlcy9QcmFjdGljZUFyZW5hLnRzeCJ9