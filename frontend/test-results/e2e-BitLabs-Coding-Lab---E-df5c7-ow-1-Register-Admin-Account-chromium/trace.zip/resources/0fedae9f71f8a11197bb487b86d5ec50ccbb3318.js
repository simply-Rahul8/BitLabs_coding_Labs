import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/TakeAssessment.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1cbb189e"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=1cbb189e"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=1cbb189e";
import toast from "/node_modules/.vite/deps/react-hot-toast.js?v=1cbb189e";
import { getInvitation } from "/src/api/assessments.ts";
import { runCode, submitSolution, getSubmission } from "/src/api/submissions.ts";
import CodeEditor from "/src/components/editor/CodeEditor.tsx";
import LanguageSelector from "/src/components/editor/LanguageSelector.tsx";
import Button from "/src/components/ui/Button.tsx";
import Spinner from "/src/components/ui/Spinner.tsx";
import { languageTemplates } from "/src/constants/templates.ts";
export default function TakeAssessment() {
  _s();
  const { token } = useParams();
  const [assessmentTitle, setAssessmentTitle] = useState("");
  const [difficulty, setDifficulty] = useState("easy");
  const [problemStatement, setProblemStatement] = useState("");
  const [constraints, setConstraints] = useState("");
  const [examples, setExamples] = useState("");
  const [language, setLanguage] = useState("python");
  const [code, setCode] = useState(languageTemplates.python);
  const [stdin, setStdin] = useState("");
  const [stdout, setStdout] = useState("Run your code to see output here.");
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [runLoading, setRunLoading] = useState(false);
  const [submitLoading, setSubmitLoading] = useState(false);
  const [isExpired, setIsExpired] = useState(false);
  const [timeLeftSeconds, setTimeLeftSeconds] = useState(0);
  const [resultOpen, setResultOpen] = useState(false);
  const [submissionResult, setSubmissionResult] = useState(null);
  const [processingAsync, setProcessingAsync] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [questionStarterCode, setQuestionStarterCode] = useState(null);
  const [testCases, setTestCases] = useState([]);
  const [runTestResultSummary, setRunTestResultSummary] = useState("");
  useEffect(() => {
    const fetchAssessment = async () => {
      if (!token) {
        setLoading(false);
        return;
      }
      try {
        const invitation = await getInvitation(token);
        if (invitation.status === "completed") {
          setSubmitted(true);
          setLoading(false);
          return;
        }
        setAssessmentTitle(invitation.assessment_title || "Assessment");
        setDifficulty(invitation.difficulty || "easy");
        setTimeLeftSeconds((invitation.time_limit_mins || 30) * 60);
        const firstQ = invitation.questions?.[0];
        if (firstQ) {
          const sc = firstQ.starter_code || {};
          const allLangs = Object.keys(languageTemplates);
          const anyCode = Object.values(sc)[0] ?? "";
          allLangs.forEach((lang) => {
            if (!sc[lang]) {
              sc[lang] = anyCode;
            }
          });
          setQuestionStarterCode(sc);
          setProblemStatement(firstQ.problem_statement || invitation.assessment_description || "No problem statement available.");
          setConstraints(firstQ.constraints || "No additional constraints were supplied.");
          setTestCases(firstQ.test_cases || []);
          const rawExamples = firstQ.examples;
          let formattedExamples = "No examples were supplied.";
          if (rawExamples) {
            if (typeof rawExamples === "string") {
              formattedExamples = rawExamples;
            } else if (typeof rawExamples === "object") {
              formattedExamples = Object.values(rawExamples).join("\n\n");
            }
          }
          setExamples(formattedExamples || "No examples were supplied.");
        } else {
          setProblemStatement(invitation.assessment_description || "No problem statement available.");
          setConstraints("No additional constraints were supplied.");
          setExamples("No examples were supplied.");
        }
      } catch (error) {
        setNotFound(true);
        toast.error("This assessment link is invalid or expired.");
      } finally {
        setLoading(false);
      }
    };
    void fetchAssessment();
  }, [token]);
  useEffect(() => {
    if (questionStarterCode && questionStarterCode[language]) {
      setCode(questionStarterCode[language]);
    } else {
      setCode(languageTemplates[language] || "");
    }
  }, [language, questionStarterCode]);
  useEffect(() => {
    if (!timeLeftSeconds || timeLeftSeconds <= 0) {
      if (timeLeftSeconds <= 0 && timeLeftSeconds !== 0) {
        setIsExpired(true);
      }
      return;
    }
    const timer = window.setInterval(() => {
      setTimeLeftSeconds((current) => {
        if (current <= 1) {
          window.clearInterval(timer);
          setIsExpired(true);
          return 0;
        }
        return current - 1;
      });
    }, 1e3);
    return () => window.clearInterval(timer);
  }, [timeLeftSeconds]);
  const formattedTime = useMemo(() => {
    const minutes = Math.floor(timeLeftSeconds / 60);
    const seconds = timeLeftSeconds % 60;
    return `${minutes.toString().padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`;
  }, [timeLeftSeconds]);
  const handleRunCode = async () => {
    if (!token || isExpired) return;
    try {
      setRunLoading(true);
      setRunTestResultSummary("");
      const result = await runCode({
        source_code: code,
        language,
        stdin,
        invitation_token: token
      });
      setStdout(result.stdout || result.stderr || "No output");
      if (result.test_results) {
        const tr = result.test_results;
        setRunTestResultSummary(`Passed ${tr.passed} / ${tr.total}`);
        setTestCases((prevCases) => {
          return prevCases.map((c, idx) => {
            const runInfo = tr.results?.[idx];
            if (runInfo) {
              return {
                ...c,
                passed: runInfo.passed,
                actual: runInfo.actual,
                run: true
              };
            }
            return c;
          });
        });
        if (tr.passed === tr.total) {
          toast.success("Code execution successful.");
        } else {
          toast.error("Test cases failed.");
        }
      } else {
        if (result.stdout === "code execution successful") {
          toast.success("Code execution successful.");
        } else {
          toast.error("Test cases failed.");
        }
      }
    } catch (error) {
      toast.error("Execution failed.");
    } finally {
      setRunLoading(false);
    }
  };
  const handleSubmit = async () => {
    if (!token || isExpired) {
      toast.error("This assessment can no longer be submitted.");
      return;
    }
    setSubmitLoading(true);
    try {
      const response = await submitSolution({
        invitation_token: token,
        source_code: code,
        language
      });
      if (response.status === 202) {
        setProcessingAsync(true);
        const subId = response.data.submission_id;
        let attempts = 0;
        const maxAttempts = 60;
        const pollInterval = 1500;
        while (attempts < maxAttempts) {
          await new Promise((resolve) => setTimeout(resolve, pollInterval));
          attempts++;
          try {
            const checkRes = await getSubmission(subId);
            if (checkRes.score !== null && checkRes.score !== void 0 && checkRes.ai_evaluation) {
              setSubmitted(true);
              break;
            }
          } catch (pollErr) {
            console.error("Polling error:", pollErr);
          }
        }
        if (attempts >= maxAttempts) {
          toast.error("Evaluation is taking longer than expected. Please check your dashboard later.");
        }
        setProcessingAsync(false);
      } else {
        setSubmitted(true);
      }
    } catch (err) {
      toast.error(err?.response?.data?.detail || "Submission failed");
    } finally {
      setSubmitLoading(false);
      setProcessingAsync(false);
    }
  };
  if (loading) {
    return /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-[70vh] items-center justify-center bg-slate-950", children: /* @__PURE__ */ jsxDEV(Spinner, { label: "Preparing assessment" }, void 0, false, {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
      lineNumber: 260,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
      lineNumber: 259,
      columnNumber: 7
    }, this);
  }
  if (!token || notFound) {
    return /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-[70vh] items-center justify-center bg-slate-950 px-6", children: /* @__PURE__ */ jsxDEV("div", { className: "max-w-md rounded-xl border border-slate-700 bg-slate-900 p-8 text-center text-slate-200", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-semibold text-white", children: "404 — Assessment not found" }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
        lineNumber: 269,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-slate-400", children: "This assessment link is invalid or missing." }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
        lineNumber: 270,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
      lineNumber: 268,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
      lineNumber: 267,
      columnNumber: 7
    }, this);
  }
  if (submitted) {
    return /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-screen items-center justify-center bg-slate-950 px-6 animate-fade-in", children: /* @__PURE__ */ jsxDEV("div", { className: "max-w-md text-center text-slate-200", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-4xl font-bold text-white mb-4", children: "Thank You!" }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
        lineNumber: 280,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-slate-400 text-sm leading-6", children: "Your assessment has been successfully submitted. You may now close this window." }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
        lineNumber: 281,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
      lineNumber: 279,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
      lineNumber: 278,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen bg-slate-900 text-slate-100", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-screen flex-col lg:flex-row", children: [
      /* @__PURE__ */ jsxDEV("aside", { className: "w-full border-b border-slate-800 bg-slate-950 p-6 lg:w-[40%] lg:border-b-0 lg:border-r", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mb-5 flex items-center justify-between gap-3", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold text-white", children: assessmentTitle || "Assessment" }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
              lineNumber: 295,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mt-2 inline-flex rounded-full bg-slate-800 px-2.5 py-1 text-xs font-medium text-slate-200", children: difficulty }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
              lineNumber: 296,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
            lineNumber: 294,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "rounded-md border border-slate-700 bg-slate-900 px-3 py-2 text-sm font-medium text-slate-200", children: formattedTime }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
            lineNumber: 298,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
          lineNumber: 293,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-6 overflow-y-auto pr-1", children: [
          /* @__PURE__ */ jsxDEV("section", { children: [
            /* @__PURE__ */ jsxDEV("h2", { className: "mb-2 text-sm font-semibold uppercase tracking-wide text-slate-400", children: "Problem" }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
              lineNumber: 303,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "whitespace-pre-wrap text-sm leading-7 text-slate-200", children: problemStatement }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
              lineNumber: 304,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
            lineNumber: 302,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("section", { children: [
            /* @__PURE__ */ jsxDEV("h2", { className: "mb-2 text-sm font-semibold uppercase tracking-wide text-slate-400", children: "Constraints" }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
              lineNumber: 308,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "whitespace-pre-wrap text-sm leading-7 text-slate-200", children: constraints }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
              lineNumber: 309,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
            lineNumber: 307,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("section", { children: [
            /* @__PURE__ */ jsxDEV("h2", { className: "mb-2 text-sm font-semibold uppercase tracking-wide text-slate-400", children: "Examples" }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
              lineNumber: 313,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "whitespace-pre-wrap text-sm leading-7 text-slate-200", children: examples }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
              lineNumber: 314,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
            lineNumber: 312,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
          lineNumber: 301,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
        lineNumber: 292,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("main", { className: "flex-1 bg-slate-900 p-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mb-4 flex items-center justify-between gap-3", children: /* @__PURE__ */ jsxDEV(LanguageSelector, { value: language, onChange: setLanguage }, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
          lineNumber: 321,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
          lineNumber: 320,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(CodeEditor, { language, value: code, onChange: setCode }, void 0, false, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
          lineNumber: 324,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-5 grid gap-5 xl:grid-cols-[1fr_1.2fr]", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "rounded-lg border border-slate-700 bg-slate-950 p-4", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "mb-2 block text-sm font-medium text-slate-300", children: "Input" }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
              lineNumber: 328,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("textarea", { value: stdin, onChange: (event) => setStdin(event.target.value), className: "min-h-28 w-full rounded-md border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-slate-100 outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-900", placeholder: "Enter stdin here" }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
              lineNumber: 329,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
            lineNumber: 327,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "rounded-lg border border-slate-700 bg-slate-950 p-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "mb-2 flex items-center justify-between", children: /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-slate-300", children: "Output" }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
              lineNumber: 334,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
              lineNumber: 333,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("pre", { className: "min-h-28 whitespace-pre-wrap rounded-md border border-slate-700 bg-slate-900 p-3 text-sm text-slate-100", children: stdout }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
              lineNumber: 336,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
            lineNumber: 332,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
          lineNumber: 326,
          columnNumber: 11
        }, this),
        testCases.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "mt-6 rounded-lg border border-slate-700 bg-slate-950 p-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "mb-4 flex items-center justify-between border-b border-slate-800 pb-2", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold tracking-wider uppercase text-slate-400", children: "Test Cases" }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
              lineNumber: 344,
              columnNumber: 17
            }, this),
            runTestResultSummary && /* @__PURE__ */ jsxDEV("span", { className: `text-xs font-bold px-2 py-0.5 rounded ${(() => {
              const parts = runTestResultSummary.replace("Passed ", "").split(" / ");
              return parts[0] !== parts[1];
            })() ? "bg-rose-950/60 text-rose-400 border border-rose-800/60" : "bg-emerald-950/60 text-emerald-400 border border-emerald-800/60"}`, children: runTestResultSummary }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
              lineNumber: 346,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
            lineNumber: 343,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: testCases.map(
            (tc, idx) => /* @__PURE__ */ jsxDEV("div", { className: "rounded-md border border-slate-800 bg-slate-900/40 p-3", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: tc.is_hidden ? /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-1.5 text-xs font-semibold text-slate-400", children: [
                  "🔒 Hidden Test Case ",
                  idx + 1
                ] }, void 0, true, {
                  fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
                  lineNumber: 365,
                  columnNumber: 21
                }, this) : /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-semibold text-slate-350", children: [
                  "Visible Test Case ",
                  idx + 1
                ] }, void 0, true, {
                  fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
                  lineNumber: 369,
                  columnNumber: 21
                }, this) }, void 0, false, {
                  fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
                  lineNumber: 363,
                  columnNumber: 23
                }, this),
                tc.run && /* @__PURE__ */ jsxDEV("span", { className: `text-xs font-semibold px-2 py-0.5 rounded ${tc.passed ? "bg-emerald-950 text-emerald-400 border border-emerald-900" : "bg-rose-950 text-rose-400 border border-rose-900"}`, children: tc.passed ? "Passed" : "Failed" }, void 0, false, {
                  fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
                  lineNumber: 375,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
                lineNumber: 362,
                columnNumber: 21
              }, this),
              !tc.is_hidden && /* @__PURE__ */ jsxDEV("div", { className: "mt-3 grid gap-3 md:grid-cols-2 text-xs font-mono", children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] uppercase text-slate-500 font-bold block mb-1", children: "Input" }, void 0, false, {
                    fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
                    lineNumber: 388,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("pre", { className: "rounded bg-slate-950 p-2 border border-slate-800 overflow-x-auto text-slate-300 max-h-24", children: tc.input }, void 0, false, {
                    fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
                    lineNumber: 389,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
                  lineNumber: 387,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] uppercase text-slate-500 font-bold block mb-1", children: "Expected Output" }, void 0, false, {
                    fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
                    lineNumber: 392,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("pre", { className: "rounded bg-slate-950 p-2 border border-slate-800 overflow-x-auto text-slate-300 max-h-24", children: tc.expected_output }, void 0, false, {
                    fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
                    lineNumber: 393,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
                  lineNumber: 391,
                  columnNumber: 25
                }, this),
                tc.run && tc.actual && /* @__PURE__ */ jsxDEV("div", { className: "col-span-2", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] uppercase text-slate-500 font-bold block mb-1", children: "Actual Output" }, void 0, false, {
                    fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
                    lineNumber: 397,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("pre", { className: `rounded p-2 border overflow-x-auto max-h-24 ${tc.passed ? "bg-slate-950 border-slate-800 text-slate-200" : "bg-rose-950/20 border-rose-900/40 text-rose-300"}`, children: tc.actual }, void 0, false, {
                    fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
                    lineNumber: 398,
                    columnNumber: 29
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
                  lineNumber: 396,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
                lineNumber: 386,
                columnNumber: 17
              }, this)
            ] }, tc.id || idx, true, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
              lineNumber: 361,
              columnNumber: 15
            }, this)
          ) }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
            lineNumber: 359,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
          lineNumber: 342,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-5 flex flex-wrap items-center justify-between gap-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "text-sm font-medium", children: runTestResultSummary && /* @__PURE__ */ jsxDEV("span", { className: (() => {
            const parts = runTestResultSummary.replace("Passed ", "").split(" / ");
            return parts[0] !== parts[1];
          })() ? "text-rose-400" : "text-emerald-400", children: (() => {
            const parts = runTestResultSummary.replace("Passed ", "").split(" / ");
            const passedCount = parseInt(parts[0], 10);
            const totalCount = parseInt(parts[1], 10);
            if (passedCount !== totalCount) {
              if (totalCount === 1) {
                return "test 1/1 failed";
              }
              return `test cases failed: ${passedCount}/${totalCount} passed`;
            }
            return "all test cases passed";
          })() }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
            lineNumber: 416,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
            lineNumber: 414,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3", children: [
            /* @__PURE__ */ jsxDEV(Button, { type: "button", variant: "secondary", disabled: runLoading || isExpired, onClick: handleRunCode, children: runLoading ? /* @__PURE__ */ jsxDEV(Spinner, { label: "Running" }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
              lineNumber: 442,
              columnNumber: 31
            }, this) : "Run Code" }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
              lineNumber: 441,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(Button, { type: "button", disabled: submitLoading || isExpired, onClick: handleSubmit, children: submitLoading ? /* @__PURE__ */ jsxDEV(Spinner, { label: "Submitting" }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
              lineNumber: 445,
              columnNumber: 34
            }, this) : "Submit" }, void 0, false, {
              fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
              lineNumber: 444,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
            lineNumber: 440,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
          lineNumber: 413,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
        lineNumber: 319,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
      lineNumber: 291,
      columnNumber: 7
    }, this),
    processingAsync && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "w-full max-w-md rounded-xl border border-slate-700 bg-slate-900 p-6 shadow-xl text-center animate-fade-in", children: [
      /* @__PURE__ */ jsxDEV(Spinner, { label: "Evaluating submission..." }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
        lineNumber: 455,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "mt-4 text-sm text-slate-400", children: "Running test cases and generating AI feedback. This may take a few seconds..." }, void 0, false, {
        fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
        lineNumber: 456,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
      lineNumber: 454,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
      lineNumber: 453,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx",
    lineNumber: 290,
    columnNumber: 5
  }, this);
}
_s(TakeAssessment, "5Kq0jzNCo5/j3QttLKCXqXAlRTs=", false, function() {
  return [useParams];
});
_c = TakeAssessment;
var _c;
$RefreshReg$(_c, "TakeAssessment");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/routes/TakeAssessment.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ1BROzs7Ozs7Ozs7Ozs7Ozs7OztBQWhQUixTQUFTQSxXQUFXQyxTQUFTQyxnQkFBZ0I7QUFDN0MsU0FBU0MsaUJBQWlCO0FBQzFCLE9BQU9DLFdBQVc7QUFDbEIsU0FBd0JDLHFCQUFxQjtBQUM3QyxTQUFTQyxTQUFTQyxnQkFBZ0JDLHFCQUE0QztBQUM5RSxPQUFPQyxnQkFBZ0I7QUFDdkIsT0FBT0Msc0JBQXNCO0FBQzdCLE9BQU9DLFlBQVk7QUFDbkIsT0FBT0MsYUFBYTtBQUNwQixTQUFTQyx5QkFBaUQ7QUFFMUQsd0JBQXdCQyxpQkFBaUI7QUFBQUMsS0FBQTtBQUN2QyxRQUFNLEVBQUVDLE1BQU0sSUFBSWIsVUFBVTtBQUM1QixRQUFNLENBQUNjLGlCQUFpQkMsa0JBQWtCLElBQUloQixTQUFTLEVBQUU7QUFDekQsUUFBTSxDQUFDaUIsWUFBWUMsYUFBYSxJQUFJbEIsU0FBUyxNQUFNO0FBQ25ELFFBQU0sQ0FBQ21CLGtCQUFrQkMsbUJBQW1CLElBQUlwQixTQUFTLEVBQUU7QUFDM0QsUUFBTSxDQUFDcUIsYUFBYUMsY0FBYyxJQUFJdEIsU0FBUyxFQUFFO0FBQ2pELFFBQU0sQ0FBQ3VCLFVBQVVDLFdBQVcsSUFBSXhCLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUN5QixVQUFVQyxXQUFXLElBQUkxQixTQUE0QixRQUFRO0FBQ3BFLFFBQU0sQ0FBQzJCLE1BQU1DLE9BQU8sSUFBSTVCLFNBQVNXLGtCQUFrQmtCLE1BQU07QUFDekQsUUFBTSxDQUFDQyxPQUFPQyxRQUFRLElBQUkvQixTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDZ0MsUUFBUUMsU0FBUyxJQUFJakMsU0FBUyxtQ0FBbUM7QUFDeEUsUUFBTSxDQUFDa0MsU0FBU0MsVUFBVSxJQUFJbkMsU0FBUyxJQUFJO0FBQzNDLFFBQU0sQ0FBQ29DLFVBQVVDLFdBQVcsSUFBSXJDLFNBQVMsS0FBSztBQUM5QyxRQUFNLENBQUNzQyxZQUFZQyxhQUFhLElBQUl2QyxTQUFTLEtBQUs7QUFDbEQsUUFBTSxDQUFDd0MsZUFBZUMsZ0JBQWdCLElBQUl6QyxTQUFTLEtBQUs7QUFDeEQsUUFBTSxDQUFDMEMsV0FBV0MsWUFBWSxJQUFJM0MsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQzRDLGlCQUFpQkMsa0JBQWtCLElBQUk3QyxTQUFTLENBQUM7QUFDeEQsUUFBTSxDQUFDOEMsWUFBWUMsYUFBYSxJQUFJL0MsU0FBUyxLQUFLO0FBQ2xELFFBQU0sQ0FBQ2dELGtCQUFrQkMsbUJBQW1CLElBQUlqRCxTQUFrQyxJQUFJO0FBQ3RGLFFBQU0sQ0FBQ2tELGlCQUFpQkMsa0JBQWtCLElBQUluRCxTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDb0QsV0FBV0MsWUFBWSxJQUFJckQsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQ3NELHFCQUFxQkMsc0JBQXNCLElBQUl2RCxTQUF3QyxJQUFJO0FBQ2xHLFFBQU0sQ0FBQ3dELFdBQVdDLFlBQVksSUFBSXpELFNBUTlCLEVBQUU7QUFDTixRQUFNLENBQUMwRCxzQkFBc0JDLHVCQUF1QixJQUFJM0QsU0FBaUIsRUFBRTtBQUUzRUYsWUFBVSxNQUFNO0FBQ2QsVUFBTThELGtCQUFrQixZQUFZO0FBQ2xDLFVBQUksQ0FBQzlDLE9BQU87QUFDVnFCLG1CQUFXLEtBQUs7QUFDaEI7QUFBQSxNQUNGO0FBRUEsVUFBSTtBQUNGLGNBQU0wQixhQUFhLE1BQU0xRCxjQUFjVyxLQUFLO0FBQzVDLFlBQUkrQyxXQUFXQyxXQUFXLGFBQWE7QUFDckNULHVCQUFhLElBQUk7QUFDakJsQixxQkFBVyxLQUFLO0FBQ2hCO0FBQUEsUUFDRjtBQUNBbkIsMkJBQW1CNkMsV0FBV0Usb0JBQW9CLFlBQVk7QUFDOUQ3QyxzQkFBYzJDLFdBQVc1QyxjQUFjLE1BQU07QUFDN0M0Qiw0QkFBb0JnQixXQUFXRyxtQkFBbUIsTUFBTSxFQUFFO0FBRTFELGNBQU1DLFNBQVNKLFdBQVdLLFlBQVksQ0FBQztBQUN2QyxZQUFJRCxRQUFRO0FBRVYsZ0JBQU1FLEtBQUtGLE9BQU9HLGdCQUFnQixDQUFDO0FBQ25DLGdCQUFNQyxXQUFXQyxPQUFPQyxLQUFLNUQsaUJBQWlCO0FBQzlDLGdCQUFNNkQsVUFBVUYsT0FBT0csT0FBT04sRUFBRSxFQUFFLENBQUMsS0FBSztBQUN4Q0UsbUJBQVNLLFFBQVEsQ0FBQ0MsU0FBUztBQUN6QixnQkFBSSxDQUFDUixHQUFHUSxJQUFJLEdBQUc7QUFDYlIsaUJBQUdRLElBQUksSUFBSUg7QUFBQUEsWUFDYjtBQUFBLFVBQ0YsQ0FBQztBQUNEakIsaUNBQXVCWSxFQUFFO0FBQ3pCL0MsOEJBQW9CNkMsT0FBT1cscUJBQXFCZixXQUFXZ0IsMEJBQTBCLGlDQUFpQztBQUN0SHZELHlCQUFlMkMsT0FBTzVDLGVBQWUsMENBQTBDO0FBQy9Fb0MsdUJBQWFRLE9BQU9hLGNBQWMsRUFBRTtBQUNwQyxnQkFBTUMsY0FBY2QsT0FBTzFDO0FBQzNCLGNBQUl5RCxvQkFBb0I7QUFDeEIsY0FBSUQsYUFBYTtBQUNmLGdCQUFJLE9BQU9BLGdCQUFnQixVQUFVO0FBQ25DQyxrQ0FBb0JEO0FBQUFBLFlBQ3RCLFdBQVcsT0FBT0EsZ0JBQWdCLFVBQVU7QUFDMUNDLGtDQUFvQlYsT0FBT0csT0FBT00sV0FBVyxFQUFFRSxLQUFLLE1BQU07QUFBQSxZQUM1RDtBQUFBLFVBQ0Y7QUFDQXpELHNCQUFZd0QscUJBQXFCLDRCQUE0QjtBQUFBLFFBQy9ELE9BQU87QUFDTDVELDhCQUFvQnlDLFdBQVdnQiwwQkFBMEIsaUNBQWlDO0FBQzFGdkQseUJBQWUsMENBQTBDO0FBQ3pERSxzQkFBWSw0QkFBNEI7QUFBQSxRQUMxQztBQUFBLE1BQ0YsU0FBUzBELE9BQU87QUFDZDdDLG9CQUFZLElBQUk7QUFDaEJuQyxjQUFNZ0YsTUFBTSw2Q0FBNkM7QUFBQSxNQUMzRCxVQUFDO0FBQ0MvQyxtQkFBVyxLQUFLO0FBQUEsTUFDbEI7QUFBQSxJQUNGO0FBRUEsU0FBS3lCLGdCQUFnQjtBQUFBLEVBQ3ZCLEdBQUcsQ0FBQzlDLEtBQUssQ0FBQztBQUVWaEIsWUFBVSxNQUFNO0FBQ2QsUUFBSXdELHVCQUF1QkEsb0JBQW9CN0IsUUFBUSxHQUFHO0FBQ3hERyxjQUFRMEIsb0JBQW9CN0IsUUFBUSxDQUFDO0FBQUEsSUFDdkMsT0FBTztBQUNMRyxjQUFRakIsa0JBQWtCYyxRQUFRLEtBQUssRUFBRTtBQUFBLElBQzNDO0FBQUEsRUFDRixHQUFHLENBQUNBLFVBQVU2QixtQkFBbUIsQ0FBQztBQUVsQ3hELFlBQVUsTUFBTTtBQUNkLFFBQUksQ0FBQzhDLG1CQUFtQkEsbUJBQW1CLEdBQUc7QUFDNUMsVUFBSUEsbUJBQW1CLEtBQUtBLG9CQUFvQixHQUFHO0FBQ2pERCxxQkFBYSxJQUFJO0FBQUEsTUFDbkI7QUFDQTtBQUFBLElBQ0Y7QUFFQSxVQUFNd0MsUUFBUUMsT0FBT0MsWUFBWSxNQUFNO0FBQ3JDeEMseUJBQW1CLENBQUN5QyxZQUFZO0FBQzlCLFlBQUlBLFdBQVcsR0FBRztBQUNoQkYsaUJBQU9HLGNBQWNKLEtBQUs7QUFDMUJ4Qyx1QkFBYSxJQUFJO0FBQ2pCLGlCQUFPO0FBQUEsUUFDVDtBQUNBLGVBQU8yQyxVQUFVO0FBQUEsTUFDbkIsQ0FBQztBQUFBLElBQ0gsR0FBRyxHQUFJO0FBRVAsV0FBTyxNQUFNRixPQUFPRyxjQUFjSixLQUFLO0FBQUEsRUFDekMsR0FBRyxDQUFDdkMsZUFBZSxDQUFDO0FBRXBCLFFBQU00QyxnQkFBZ0J6RixRQUFRLE1BQU07QUFDbEMsVUFBTTBGLFVBQVVDLEtBQUtDLE1BQU0vQyxrQkFBa0IsRUFBRTtBQUMvQyxVQUFNZ0QsVUFBVWhELGtCQUFrQjtBQUNsQyxXQUFPLEdBQUc2QyxRQUFRSSxTQUFTLEVBQUVDLFNBQVMsR0FBRyxHQUFHLENBQUMsSUFBSUYsUUFBUUMsU0FBUyxFQUFFQyxTQUFTLEdBQUcsR0FBRyxDQUFDO0FBQUEsRUFDdEYsR0FBRyxDQUFDbEQsZUFBZSxDQUFDO0FBRXBCLFFBQU1tRCxnQkFBZ0IsWUFBWTtBQUNoQyxRQUFJLENBQUNqRixTQUFTNEIsVUFBVztBQUV6QixRQUFJO0FBQ0ZILG9CQUFjLElBQUk7QUFDbEJvQiw4QkFBd0IsRUFBRTtBQUMxQixZQUFNcUMsU0FBUyxNQUFNNUYsUUFBUTtBQUFBLFFBQzNCNkYsYUFBYXRFO0FBQUFBLFFBQ2JGO0FBQUFBLFFBQ0FLO0FBQUFBLFFBQ0FvRSxrQkFBa0JwRjtBQUFBQSxNQUNwQixDQUFDO0FBQ0RtQixnQkFBVStELE9BQU9oRSxVQUFVZ0UsT0FBT0csVUFBVSxXQUFXO0FBQ3ZELFVBQUlILE9BQU9JLGNBQWM7QUFDdkIsY0FBTUMsS0FBS0wsT0FBT0k7QUFDbEJ6QyxnQ0FBd0IsVUFBVTBDLEdBQUdDLE1BQU0sTUFBTUQsR0FBR0UsS0FBSyxFQUFFO0FBQzNEOUMscUJBQWEsQ0FBQytDLGNBQWM7QUFDMUIsaUJBQU9BLFVBQVVDLElBQUksQ0FBQ0MsR0FBR0MsUUFBUTtBQUMvQixrQkFBTUMsVUFBVVAsR0FBR1EsVUFBVUYsR0FBRztBQUNoQyxnQkFBSUMsU0FBUztBQUNYLHFCQUFPO0FBQUEsZ0JBQ0wsR0FBR0Y7QUFBQUEsZ0JBQ0hKLFFBQVFNLFFBQVFOO0FBQUFBLGdCQUNoQlEsUUFBUUYsUUFBUUU7QUFBQUEsZ0JBQ2hCQyxLQUFLO0FBQUEsY0FDUDtBQUFBLFlBQ0Y7QUFDQSxtQkFBT0w7QUFBQUEsVUFDVCxDQUFDO0FBQUEsUUFDSCxDQUFDO0FBQ0QsWUFBSUwsR0FBR0MsV0FBV0QsR0FBR0UsT0FBTztBQUMxQnJHLGdCQUFNOEcsUUFBUSw0QkFBNEI7QUFBQSxRQUM1QyxPQUFPO0FBQ0w5RyxnQkFBTWdGLE1BQU0sb0JBQW9CO0FBQUEsUUFDbEM7QUFBQSxNQUNGLE9BQU87QUFDTCxZQUFJYyxPQUFPaEUsV0FBVyw2QkFBNkI7QUFDakQ5QixnQkFBTThHLFFBQVEsNEJBQTRCO0FBQUEsUUFDNUMsT0FBTztBQUNMOUcsZ0JBQU1nRixNQUFNLG9CQUFvQjtBQUFBLFFBQ2xDO0FBQUEsTUFDRjtBQUFBLElBQ0YsU0FBU0EsT0FBTztBQUNkaEYsWUFBTWdGLE1BQU0sbUJBQW1CO0FBQUEsSUFDakMsVUFBQztBQUNDM0Msb0JBQWMsS0FBSztBQUFBLElBQ3JCO0FBQUEsRUFDRjtBQUVBLFFBQU0wRSxlQUFlLFlBQVk7QUFDL0IsUUFBSSxDQUFDbkcsU0FBUzRCLFdBQVc7QUFDdkJ4QyxZQUFNZ0YsTUFBTSw2Q0FBNkM7QUFDekQ7QUFBQSxJQUNGO0FBQ0F6QyxxQkFBaUIsSUFBSTtBQUNyQixRQUFJO0FBQ0YsWUFBTXlFLFdBQVcsTUFBTTdHLGVBQWU7QUFBQSxRQUNwQzZGLGtCQUFrQnBGO0FBQUFBLFFBQ2xCbUYsYUFBYXRFO0FBQUFBLFFBQ2JGO0FBQUFBLE1BQ0YsQ0FBQztBQUVELFVBQUl5RixTQUFTcEQsV0FBVyxLQUFLO0FBQzNCWCwyQkFBbUIsSUFBSTtBQUN2QixjQUFNZ0UsUUFBUUQsU0FBU0UsS0FBS0M7QUFFNUIsWUFBSUMsV0FBVztBQUNmLGNBQU1DLGNBQWM7QUFDcEIsY0FBTUMsZUFBZTtBQUVyQixlQUFPRixXQUFXQyxhQUFhO0FBQzdCLGdCQUFNLElBQUlFLFFBQVEsQ0FBQ0MsWUFBWUMsV0FBV0QsU0FBU0YsWUFBWSxDQUFDO0FBQ2hFRjtBQUNBLGNBQUk7QUFDRixrQkFBTU0sV0FBVyxNQUFNdEgsY0FBYzZHLEtBQUs7QUFDMUMsZ0JBQUlTLFNBQVNDLFVBQVUsUUFBUUQsU0FBU0MsVUFBVUMsVUFBYUYsU0FBU0csZUFBZTtBQUNyRjFFLDJCQUFhLElBQUk7QUFDakI7QUFBQSxZQUNGO0FBQUEsVUFDRixTQUFTMkUsU0FBUztBQUNoQkMsb0JBQVEvQyxNQUFNLGtCQUFrQjhDLE9BQU87QUFBQSxVQUN6QztBQUFBLFFBQ0Y7QUFDQSxZQUFJVixZQUFZQyxhQUFhO0FBQzNCckgsZ0JBQU1nRixNQUFNLCtFQUErRTtBQUFBLFFBQzdGO0FBQ0EvQiwyQkFBbUIsS0FBSztBQUFBLE1BQzFCLE9BQU87QUFDTEUscUJBQWEsSUFBSTtBQUFBLE1BQ25CO0FBQUEsSUFDRixTQUFTNkUsS0FBVTtBQUNqQmhJLFlBQU1nRixNQUFNZ0QsS0FBS2hCLFVBQVVFLE1BQU1lLFVBQVUsbUJBQW1CO0FBQUEsSUFDaEUsVUFBQztBQUNDMUYsdUJBQWlCLEtBQUs7QUFDdEJVLHlCQUFtQixLQUFLO0FBQUEsSUFDMUI7QUFBQSxFQUNGO0FBRUEsTUFBSWpCLFNBQVM7QUFDWCxXQUNFLHVCQUFDLFNBQUksV0FBVSw4REFDYixpQ0FBQyxXQUFRLE9BQU0sMEJBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxQyxLQUR2QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBRUEsTUFBSSxDQUFDcEIsU0FBU3NCLFVBQVU7QUFDdEIsV0FDRSx1QkFBQyxTQUFJLFdBQVUsbUVBQ2IsaUNBQUMsU0FBSSxXQUFVLDJGQUNiO0FBQUEsNkJBQUMsUUFBRyxXQUFVLHFDQUFvQywwQ0FBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0RTtBQUFBLE1BQzVFLHVCQUFDLE9BQUUsV0FBVSwrQkFBOEIsMkRBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0Y7QUFBQSxTQUZ4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0EsS0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0E7QUFBQSxFQUVKO0FBRUEsTUFBSWdCLFdBQVc7QUFDYixXQUNFLHVCQUFDLFNBQUksV0FBVSxtRkFDYixpQ0FBQyxTQUFJLFdBQVUsdUNBQ2I7QUFBQSw2QkFBQyxRQUFHLFdBQVUsc0NBQXFDLDBCQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZEO0FBQUEsTUFDN0QsdUJBQUMsT0FBRSxXQUFVLG9DQUFrQywrRkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0E7QUFBQSxFQUVKO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsNENBQ2I7QUFBQSwyQkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSw2QkFBQyxXQUFNLFdBQVUsMEZBQ2Y7QUFBQSwrQkFBQyxTQUFJLFdBQVUsZ0RBQ2I7QUFBQSxpQ0FBQyxTQUNDO0FBQUEsbUNBQUMsUUFBRyxXQUFVLHFDQUFxQ3JDLDZCQUFtQixnQkFBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUY7QUFBQSxZQUNuRix1QkFBQyxTQUFJLFdBQVUsNkZBQTZGRSx3QkFBNUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUg7QUFBQSxlQUZ6SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsZ0dBQWdHdUUsMkJBQS9HO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZIO0FBQUEsYUFML0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsa0NBQ2I7QUFBQSxpQ0FBQyxhQUNDO0FBQUEsbUNBQUMsUUFBRyxXQUFVLHFFQUFvRSx1QkFBbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUY7QUFBQSxZQUN6Rix1QkFBQyxPQUFFLFdBQVUsd0RBQXdEckUsOEJBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNGO0FBQUEsZUFGeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBRUEsdUJBQUMsYUFDQztBQUFBLG1DQUFDLFFBQUcsV0FBVSxxRUFBb0UsMkJBQWxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZGO0FBQUEsWUFDN0YsdUJBQUMsT0FBRSxXQUFVLHdEQUF3REUseUJBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlGO0FBQUEsZUFGbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBRUEsdUJBQUMsYUFDQztBQUFBLG1DQUFDLFFBQUcsV0FBVSxxRUFBb0Usd0JBQWxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBGO0FBQUEsWUFDMUYsdUJBQUMsT0FBRSxXQUFVLHdEQUF3REUsc0JBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThFO0FBQUEsZUFGaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLGFBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWVBO0FBQUEsV0F4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXlCQTtBQUFBLE1BRUEsdUJBQUMsVUFBSyxXQUFVLDJCQUNkO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGdEQUNiLGlDQUFDLG9CQUFpQixPQUFPRSxVQUFVLFVBQVVDLGVBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUQsS0FEM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFFQSx1QkFBQyxjQUFXLFVBQW9CLE9BQU9DLE1BQU0sVUFBVUMsV0FBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErRDtBQUFBLFFBRS9ELHVCQUFDLFNBQUksV0FBVSw0Q0FDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSx1REFDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSxpREFBZ0QscUJBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNFO0FBQUEsWUFDdEUsdUJBQUMsY0FBUyxPQUFPRSxPQUFPLFVBQVUsQ0FBQ3NHLFVBQVVyRyxTQUFTcUcsTUFBTUMsT0FBT0MsS0FBSyxHQUFHLFdBQVUsMEtBQXlLLGFBQVksc0JBQTFRO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRSO0FBQUEsZUFGOVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLHVEQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLDBDQUNiLGlDQUFDLFVBQUssV0FBVSxzQ0FBcUMsc0JBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJELEtBRDdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSwyR0FBMkd0RyxvQkFBMUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUk7QUFBQSxlQUpuSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsYUFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBWUE7QUFBQSxRQUdDd0IsVUFBVStFLFNBQVMsS0FDbEIsdUJBQUMsU0FBSSxXQUFVLDREQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLHlFQUNiO0FBQUEsbUNBQUMsVUFBSyxXQUFVLGlFQUFnRSwwQkFBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEY7QUFBQSxZQUN6RjdFLHdCQUNDLHVCQUFDLFVBQUssV0FBVywwQ0FDZCxNQUFNO0FBQ0wsb0JBQU04RSxRQUFROUUscUJBQXFCK0UsUUFBUSxXQUFXLEVBQUUsRUFBRUMsTUFBTSxLQUFLO0FBQ3JFLHFCQUFPRixNQUFNLENBQUMsTUFBTUEsTUFBTSxDQUFDO0FBQUEsWUFDN0IsR0FBRyxJQUNDLDJEQUNBLGlFQUFpRSxJQUVwRTlFLGtDQVJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBU0E7QUFBQSxlQVpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBY0E7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxhQUNaRixvQkFBVWlEO0FBQUFBLFlBQUksQ0FBQ2tDLElBQUloQyxRQUNsQix1QkFBQyxTQUF1QixXQUFVLDBEQUNoQztBQUFBLHFDQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSwyQkFDWmdDLGFBQUdDLFlBQ0YsdUJBQUMsVUFBSyxXQUFVLGtFQUFnRTtBQUFBO0FBQUEsa0JBQ3pEakMsTUFBTTtBQUFBLHFCQUQ3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBLElBRUEsdUJBQUMsVUFBSyxXQUFVLHdDQUFzQztBQUFBO0FBQUEsa0JBQ2pDQSxNQUFNO0FBQUEscUJBRDNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUEsS0FSSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVVBO0FBQUEsZ0JBQ0NnQyxHQUFHNUIsT0FDRix1QkFBQyxVQUFLLFdBQVcsNkNBQ2Y0QixHQUFHckMsU0FDQyw4REFDQSxrREFBa0QsSUFFckRxQyxhQUFHckMsU0FBUyxXQUFXLFlBTDFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBTUE7QUFBQSxtQkFuQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFxQkE7QUFBQSxjQUVDLENBQUNxQyxHQUFHQyxhQUNILHVCQUFDLFNBQUksV0FBVSxvREFDYjtBQUFBLHVDQUFDLFNBQ0M7QUFBQSx5Q0FBQyxVQUFLLFdBQVUsNkRBQTRELHFCQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFpRjtBQUFBLGtCQUNqRix1QkFBQyxTQUFJLFdBQVUsNEZBQTRGRCxhQUFHRSxTQUE5RztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFvSDtBQUFBLHFCQUZ0SDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FDQztBQUFBLHlDQUFDLFVBQUssV0FBVSw2REFBNEQsK0JBQTVFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTJGO0FBQUEsa0JBQzNGLHVCQUFDLFNBQUksV0FBVSw0RkFBNEZGLGFBQUdHLG1CQUE5RztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE4SDtBQUFBLHFCQUZoSTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsZ0JBQ0NILEdBQUc1QixPQUFPNEIsR0FBRzdCLFVBQ1osdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSx5Q0FBQyxVQUFLLFdBQVUsNkRBQTRELDZCQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF5RjtBQUFBLGtCQUN6Rix1QkFBQyxTQUFJLFdBQVcsK0NBQ2Q2QixHQUFHckMsU0FDQyxpREFDQSxpREFBaUQsSUFDbERxQyxhQUFHN0IsVUFKUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUllO0FBQUEscUJBTmpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBT0E7QUFBQSxtQkFqQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFtQkE7QUFBQSxpQkE1Q002QixHQUFHSSxNQUFNcEMsS0FBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE4Q0E7QUFBQSxVQUNELEtBakRIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBa0RBO0FBQUEsYUFuRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW9FQTtBQUFBLFFBR0YsdUJBQUMsU0FBSSxXQUFVLDBEQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLHVCQUNaakQsa0NBQ0MsdUJBQUMsVUFBSyxZQUNILE1BQU07QUFDTCxrQkFBTThFLFFBQVE5RSxxQkFBcUIrRSxRQUFRLFdBQVcsRUFBRSxFQUFFQyxNQUFNLEtBQUs7QUFDckUsbUJBQU9GLE1BQU0sQ0FBQyxNQUFNQSxNQUFNLENBQUM7QUFBQSxVQUM3QixHQUFHLElBQ0Msa0JBQ0Esb0JBRUYsaUJBQU07QUFDTixrQkFBTUEsUUFBUTlFLHFCQUFxQitFLFFBQVEsV0FBVyxFQUFFLEVBQUVDLE1BQU0sS0FBSztBQUNyRSxrQkFBTU0sY0FBY0MsU0FBU1QsTUFBTSxDQUFDLEdBQUcsRUFBRTtBQUN6QyxrQkFBTVUsYUFBYUQsU0FBU1QsTUFBTSxDQUFDLEdBQUcsRUFBRTtBQUN4QyxnQkFBSVEsZ0JBQWdCRSxZQUFZO0FBQzlCLGtCQUFJQSxlQUFlLEdBQUc7QUFDcEIsdUJBQU87QUFBQSxjQUNUO0FBQ0EscUJBQU8sc0JBQXNCRixXQUFXLElBQUlFLFVBQVU7QUFBQSxZQUN4RDtBQUNBLG1CQUFPO0FBQUEsVUFDVCxHQUFHLEtBbkJMO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBb0JBLEtBdEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBd0JBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLG1DQUFDLFVBQU8sTUFBSyxVQUFTLFNBQVEsYUFBWSxVQUFVNUcsY0FBY0ksV0FBVyxTQUFTcUQsZUFDbkZ6RCx1QkFBYSx1QkFBQyxXQUFRLE9BQU0sYUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3QixJQUFNLGNBRDlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFVBQU8sTUFBSyxVQUFTLFVBQVVFLGlCQUFpQkUsV0FBVyxTQUFTdUUsY0FDbEV6RSwwQkFBZ0IsdUJBQUMsV0FBUSxPQUFNLGdCQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJCLElBQU0sWUFEcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLGFBbENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFtQ0E7QUFBQSxXQWpJRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBa0lBO0FBQUEsU0E5SkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQStKQTtBQUFBLElBRUNVLG1CQUNDLHVCQUFDLFNBQUksV0FBVSwyRUFDYixpQ0FBQyxTQUFJLFdBQVUsNkdBQ2I7QUFBQSw2QkFBQyxXQUFRLE9BQU0sOEJBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5QztBQUFBLE1BQ3pDLHVCQUFDLE9BQUUsV0FBVSwrQkFBNkIsNkZBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtBLEtBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9BO0FBQUEsT0ExS0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTRLQTtBQUVKO0FBQUNyQyxHQWpidUJELGdCQUFjO0FBQUEsVUFDbEJYLFNBQVM7QUFBQTtBQUFBLEtBRExXO0FBQWMsSUFBQXVJO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZU1lbW8iLCJ1c2VTdGF0ZSIsInVzZVBhcmFtcyIsInRvYXN0IiwiZ2V0SW52aXRhdGlvbiIsInJ1bkNvZGUiLCJzdWJtaXRTb2x1dGlvbiIsImdldFN1Ym1pc3Npb24iLCJDb2RlRWRpdG9yIiwiTGFuZ3VhZ2VTZWxlY3RvciIsIkJ1dHRvbiIsIlNwaW5uZXIiLCJsYW5ndWFnZVRlbXBsYXRlcyIsIlRha2VBc3Nlc3NtZW50IiwiX3MiLCJ0b2tlbiIsImFzc2Vzc21lbnRUaXRsZSIsInNldEFzc2Vzc21lbnRUaXRsZSIsImRpZmZpY3VsdHkiLCJzZXREaWZmaWN1bHR5IiwicHJvYmxlbVN0YXRlbWVudCIsInNldFByb2JsZW1TdGF0ZW1lbnQiLCJjb25zdHJhaW50cyIsInNldENvbnN0cmFpbnRzIiwiZXhhbXBsZXMiLCJzZXRFeGFtcGxlcyIsImxhbmd1YWdlIiwic2V0TGFuZ3VhZ2UiLCJjb2RlIiwic2V0Q29kZSIsInB5dGhvbiIsInN0ZGluIiwic2V0U3RkaW4iLCJzdGRvdXQiLCJzZXRTdGRvdXQiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsIm5vdEZvdW5kIiwic2V0Tm90Rm91bmQiLCJydW5Mb2FkaW5nIiwic2V0UnVuTG9hZGluZyIsInN1Ym1pdExvYWRpbmciLCJzZXRTdWJtaXRMb2FkaW5nIiwiaXNFeHBpcmVkIiwic2V0SXNFeHBpcmVkIiwidGltZUxlZnRTZWNvbmRzIiwic2V0VGltZUxlZnRTZWNvbmRzIiwicmVzdWx0T3BlbiIsInNldFJlc3VsdE9wZW4iLCJzdWJtaXNzaW9uUmVzdWx0Iiwic2V0U3VibWlzc2lvblJlc3VsdCIsInByb2Nlc3NpbmdBc3luYyIsInNldFByb2Nlc3NpbmdBc3luYyIsInN1Ym1pdHRlZCIsInNldFN1Ym1pdHRlZCIsInF1ZXN0aW9uU3RhcnRlckNvZGUiLCJzZXRRdWVzdGlvblN0YXJ0ZXJDb2RlIiwidGVzdENhc2VzIiwic2V0VGVzdENhc2VzIiwicnVuVGVzdFJlc3VsdFN1bW1hcnkiLCJzZXRSdW5UZXN0UmVzdWx0U3VtbWFyeSIsImZldGNoQXNzZXNzbWVudCIsImludml0YXRpb24iLCJzdGF0dXMiLCJhc3Nlc3NtZW50X3RpdGxlIiwidGltZV9saW1pdF9taW5zIiwiZmlyc3RRIiwicXVlc3Rpb25zIiwic2MiLCJzdGFydGVyX2NvZGUiLCJhbGxMYW5ncyIsIk9iamVjdCIsImtleXMiLCJhbnlDb2RlIiwidmFsdWVzIiwiZm9yRWFjaCIsImxhbmciLCJwcm9ibGVtX3N0YXRlbWVudCIsImFzc2Vzc21lbnRfZGVzY3JpcHRpb24iLCJ0ZXN0X2Nhc2VzIiwicmF3RXhhbXBsZXMiLCJmb3JtYXR0ZWRFeGFtcGxlcyIsImpvaW4iLCJlcnJvciIsInRpbWVyIiwid2luZG93Iiwic2V0SW50ZXJ2YWwiLCJjdXJyZW50IiwiY2xlYXJJbnRlcnZhbCIsImZvcm1hdHRlZFRpbWUiLCJtaW51dGVzIiwiTWF0aCIsImZsb29yIiwic2Vjb25kcyIsInRvU3RyaW5nIiwicGFkU3RhcnQiLCJoYW5kbGVSdW5Db2RlIiwicmVzdWx0Iiwic291cmNlX2NvZGUiLCJpbnZpdGF0aW9uX3Rva2VuIiwic3RkZXJyIiwidGVzdF9yZXN1bHRzIiwidHIiLCJwYXNzZWQiLCJ0b3RhbCIsInByZXZDYXNlcyIsIm1hcCIsImMiLCJpZHgiLCJydW5JbmZvIiwicmVzdWx0cyIsImFjdHVhbCIsInJ1biIsInN1Y2Nlc3MiLCJoYW5kbGVTdWJtaXQiLCJyZXNwb25zZSIsInN1YklkIiwiZGF0YSIsInN1Ym1pc3Npb25faWQiLCJhdHRlbXB0cyIsIm1heEF0dGVtcHRzIiwicG9sbEludGVydmFsIiwiUHJvbWlzZSIsInJlc29sdmUiLCJzZXRUaW1lb3V0IiwiY2hlY2tSZXMiLCJzY29yZSIsInVuZGVmaW5lZCIsImFpX2V2YWx1YXRpb24iLCJwb2xsRXJyIiwiY29uc29sZSIsImVyciIsImRldGFpbCIsImV2ZW50IiwidGFyZ2V0IiwidmFsdWUiLCJsZW5ndGgiLCJwYXJ0cyIsInJlcGxhY2UiLCJzcGxpdCIsInRjIiwiaXNfaGlkZGVuIiwiaW5wdXQiLCJleHBlY3RlZF9vdXRwdXQiLCJpZCIsInBhc3NlZENvdW50IiwicGFyc2VJbnQiLCJ0b3RhbENvdW50IiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiVGFrZUFzc2Vzc21lbnQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHVzZVBhcmFtcyB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XG5pbXBvcnQgdG9hc3QgZnJvbSBcInJlYWN0LWhvdC10b2FzdFwiO1xuaW1wb3J0IHsgZ2V0QXNzZXNzbWVudCwgZ2V0SW52aXRhdGlvbiB9IGZyb20gXCIuLi9hcGkvYXNzZXNzbWVudHNcIjtcbmltcG9ydCB7IHJ1bkNvZGUsIHN1Ym1pdFNvbHV0aW9uLCBnZXRTdWJtaXNzaW9uLCB0eXBlIFN1Ym1pc3Npb25SZXN1bHQgfSBmcm9tIFwiLi4vYXBpL3N1Ym1pc3Npb25zXCI7XG5pbXBvcnQgQ29kZUVkaXRvciBmcm9tIFwiLi4vY29tcG9uZW50cy9lZGl0b3IvQ29kZUVkaXRvclwiO1xuaW1wb3J0IExhbmd1YWdlU2VsZWN0b3IgZnJvbSBcIi4uL2NvbXBvbmVudHMvZWRpdG9yL0xhbmd1YWdlU2VsZWN0b3JcIjtcbmltcG9ydCBCdXR0b24gZnJvbSBcIi4uL2NvbXBvbmVudHMvdWkvQnV0dG9uXCI7XG5pbXBvcnQgU3Bpbm5lciBmcm9tIFwiLi4vY29tcG9uZW50cy91aS9TcGlubmVyXCI7XG5pbXBvcnQgeyBsYW5ndWFnZVRlbXBsYXRlcywgdHlwZSBTdXBwb3J0ZWRMYW5ndWFnZSB9IGZyb20gXCIuLi9jb25zdGFudHMvdGVtcGxhdGVzXCI7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFRha2VBc3Nlc3NtZW50KCkge1xuICBjb25zdCB7IHRva2VuIH0gPSB1c2VQYXJhbXMoKTtcbiAgY29uc3QgW2Fzc2Vzc21lbnRUaXRsZSwgc2V0QXNzZXNzbWVudFRpdGxlXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbZGlmZmljdWx0eSwgc2V0RGlmZmljdWx0eV0gPSB1c2VTdGF0ZShcImVhc3lcIik7XG4gIGNvbnN0IFtwcm9ibGVtU3RhdGVtZW50LCBzZXRQcm9ibGVtU3RhdGVtZW50XSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbY29uc3RyYWludHMsIHNldENvbnN0cmFpbnRzXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbZXhhbXBsZXMsIHNldEV4YW1wbGVzXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbbGFuZ3VhZ2UsIHNldExhbmd1YWdlXSA9IHVzZVN0YXRlPFN1cHBvcnRlZExhbmd1YWdlPihcInB5dGhvblwiKTtcbiAgY29uc3QgW2NvZGUsIHNldENvZGVdID0gdXNlU3RhdGUobGFuZ3VhZ2VUZW1wbGF0ZXMucHl0aG9uKTtcbiAgY29uc3QgW3N0ZGluLCBzZXRTdGRpbl0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW3N0ZG91dCwgc2V0U3Rkb3V0XSA9IHVzZVN0YXRlKFwiUnVuIHlvdXIgY29kZSB0byBzZWUgb3V0cHV0IGhlcmUuXCIpO1xuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKTtcbiAgY29uc3QgW25vdEZvdW5kLCBzZXROb3RGb3VuZF0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtydW5Mb2FkaW5nLCBzZXRSdW5Mb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3N1Ym1pdExvYWRpbmcsIHNldFN1Ym1pdExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbaXNFeHBpcmVkLCBzZXRJc0V4cGlyZWRdID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbdGltZUxlZnRTZWNvbmRzLCBzZXRUaW1lTGVmdFNlY29uZHNdID0gdXNlU3RhdGUoMCk7XG4gIGNvbnN0IFtyZXN1bHRPcGVuLCBzZXRSZXN1bHRPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3N1Ym1pc3Npb25SZXN1bHQsIHNldFN1Ym1pc3Npb25SZXN1bHRdID0gdXNlU3RhdGU8U3VibWlzc2lvblJlc3VsdCB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbcHJvY2Vzc2luZ0FzeW5jLCBzZXRQcm9jZXNzaW5nQXN5bmNdID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbc3VibWl0dGVkLCBzZXRTdWJtaXR0ZWRdID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbcXVlc3Rpb25TdGFydGVyQ29kZSwgc2V0UXVlc3Rpb25TdGFydGVyQ29kZV0gPSB1c2VTdGF0ZTxSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+IHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFt0ZXN0Q2FzZXMsIHNldFRlc3RDYXNlc10gPSB1c2VTdGF0ZTxBcnJheTx7XG4gICAgaWQ6IHN0cmluZztcbiAgICBpc19oaWRkZW46IGJvb2xlYW47XG4gICAgaW5wdXQ/OiBzdHJpbmc7XG4gICAgZXhwZWN0ZWRfb3V0cHV0Pzogc3RyaW5nO1xuICAgIHBhc3NlZD86IGJvb2xlYW47XG4gICAgYWN0dWFsPzogc3RyaW5nO1xuICAgIHJ1bj86IGJvb2xlYW47XG4gIH0+PihbXSk7XG4gIGNvbnN0IFtydW5UZXN0UmVzdWx0U3VtbWFyeSwgc2V0UnVuVGVzdFJlc3VsdFN1bW1hcnldID0gdXNlU3RhdGU8c3RyaW5nPihcIlwiKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IGZldGNoQXNzZXNzbWVudCA9IGFzeW5jICgpID0+IHtcbiAgICAgIGlmICghdG9rZW4pIHtcbiAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgaW52aXRhdGlvbiA9IGF3YWl0IGdldEludml0YXRpb24odG9rZW4pO1xuICAgICAgICBpZiAoaW52aXRhdGlvbi5zdGF0dXMgPT09IFwiY29tcGxldGVkXCIpIHtcbiAgICAgICAgICBzZXRTdWJtaXR0ZWQodHJ1ZSk7XG4gICAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHNldEFzc2Vzc21lbnRUaXRsZShpbnZpdGF0aW9uLmFzc2Vzc21lbnRfdGl0bGUgfHwgXCJBc3Nlc3NtZW50XCIpO1xuICAgICAgICBzZXREaWZmaWN1bHR5KGludml0YXRpb24uZGlmZmljdWx0eSB8fCBcImVhc3lcIik7XG4gICAgICAgIHNldFRpbWVMZWZ0U2Vjb25kcygoaW52aXRhdGlvbi50aW1lX2xpbWl0X21pbnMgfHwgMzApICogNjApO1xuXG4gICAgICAgIGNvbnN0IGZpcnN0USA9IGludml0YXRpb24ucXVlc3Rpb25zPy5bMF07XG4gICAgICAgIGlmIChmaXJzdFEpIHtcbi8vIE5vcm1hbGl6ZSBzdGFydGVyIGNvZGUgYWNyb3NzIGFsbCBsYW5ndWFnZXNcbiAgICAgICAgICBjb25zdCBzYyA9IGZpcnN0US5zdGFydGVyX2NvZGUgfHwge307XG4gICAgICAgICAgY29uc3QgYWxsTGFuZ3MgPSBPYmplY3Qua2V5cyhsYW5ndWFnZVRlbXBsYXRlcyk7XG4gICAgICAgICAgY29uc3QgYW55Q29kZSA9IE9iamVjdC52YWx1ZXMoc2MpWzBdID8/IFwiXCI7XG4gICAgICAgICAgYWxsTGFuZ3MuZm9yRWFjaCgobGFuZykgPT4ge1xuICAgICAgICAgICAgaWYgKCFzY1tsYW5nXSkge1xuICAgICAgICAgICAgICBzY1tsYW5nXSA9IGFueUNvZGU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSk7XG4gICAgICAgICAgc2V0UXVlc3Rpb25TdGFydGVyQ29kZShzYyk7XG4gICAgICAgICAgc2V0UHJvYmxlbVN0YXRlbWVudChmaXJzdFEucHJvYmxlbV9zdGF0ZW1lbnQgfHwgaW52aXRhdGlvbi5hc3Nlc3NtZW50X2Rlc2NyaXB0aW9uIHx8IFwiTm8gcHJvYmxlbSBzdGF0ZW1lbnQgYXZhaWxhYmxlLlwiKTtcbiAgICAgICAgICBzZXRDb25zdHJhaW50cyhmaXJzdFEuY29uc3RyYWludHMgfHwgXCJObyBhZGRpdGlvbmFsIGNvbnN0cmFpbnRzIHdlcmUgc3VwcGxpZWQuXCIpO1xuICAgICAgICAgIHNldFRlc3RDYXNlcyhmaXJzdFEudGVzdF9jYXNlcyB8fCBbXSk7XG4gICAgICAgICAgY29uc3QgcmF3RXhhbXBsZXMgPSBmaXJzdFEuZXhhbXBsZXM7XG4gICAgICAgICAgbGV0IGZvcm1hdHRlZEV4YW1wbGVzID0gXCJObyBleGFtcGxlcyB3ZXJlIHN1cHBsaWVkLlwiO1xuICAgICAgICAgIGlmIChyYXdFeGFtcGxlcykge1xuICAgICAgICAgICAgaWYgKHR5cGVvZiByYXdFeGFtcGxlcyA9PT0gXCJzdHJpbmdcIikge1xuICAgICAgICAgICAgICBmb3JtYXR0ZWRFeGFtcGxlcyA9IHJhd0V4YW1wbGVzO1xuICAgICAgICAgICAgfSBlbHNlIGlmICh0eXBlb2YgcmF3RXhhbXBsZXMgPT09IFwib2JqZWN0XCIpIHtcbiAgICAgICAgICAgICAgZm9ybWF0dGVkRXhhbXBsZXMgPSBPYmplY3QudmFsdWVzKHJhd0V4YW1wbGVzKS5qb2luKFwiXFxuXFxuXCIpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgICBzZXRFeGFtcGxlcyhmb3JtYXR0ZWRFeGFtcGxlcyB8fCBcIk5vIGV4YW1wbGVzIHdlcmUgc3VwcGxpZWQuXCIpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHNldFByb2JsZW1TdGF0ZW1lbnQoaW52aXRhdGlvbi5hc3Nlc3NtZW50X2Rlc2NyaXB0aW9uIHx8IFwiTm8gcHJvYmxlbSBzdGF0ZW1lbnQgYXZhaWxhYmxlLlwiKTtcbiAgICAgICAgICBzZXRDb25zdHJhaW50cyhcIk5vIGFkZGl0aW9uYWwgY29uc3RyYWludHMgd2VyZSBzdXBwbGllZC5cIik7XG4gICAgICAgICAgc2V0RXhhbXBsZXMoXCJObyBleGFtcGxlcyB3ZXJlIHN1cHBsaWVkLlwiKTtcbiAgICAgICAgfVxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgc2V0Tm90Rm91bmQodHJ1ZSk7XG4gICAgICAgIHRvYXN0LmVycm9yKFwiVGhpcyBhc3Nlc3NtZW50IGxpbmsgaXMgaW52YWxpZCBvciBleHBpcmVkLlwiKTtcbiAgICAgIH0gZmluYWxseSB7XG4gICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgICAgfVxuICAgIH07XG5cbiAgICB2b2lkIGZldGNoQXNzZXNzbWVudCgpO1xuICB9LCBbdG9rZW5dKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChxdWVzdGlvblN0YXJ0ZXJDb2RlICYmIHF1ZXN0aW9uU3RhcnRlckNvZGVbbGFuZ3VhZ2VdKSB7XG4gICAgICBzZXRDb2RlKHF1ZXN0aW9uU3RhcnRlckNvZGVbbGFuZ3VhZ2VdKTtcbiAgICB9IGVsc2Uge1xuICAgICAgc2V0Q29kZShsYW5ndWFnZVRlbXBsYXRlc1tsYW5ndWFnZV0gfHwgXCJcIik7XG4gICAgfVxuICB9LCBbbGFuZ3VhZ2UsIHF1ZXN0aW9uU3RhcnRlckNvZGVdKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghdGltZUxlZnRTZWNvbmRzIHx8IHRpbWVMZWZ0U2Vjb25kcyA8PSAwKSB7XG4gICAgICBpZiAodGltZUxlZnRTZWNvbmRzIDw9IDAgJiYgdGltZUxlZnRTZWNvbmRzICE9PSAwKSB7XG4gICAgICAgIHNldElzRXhwaXJlZCh0cnVlKTtcbiAgICAgIH1cbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBjb25zdCB0aW1lciA9IHdpbmRvdy5zZXRJbnRlcnZhbCgoKSA9PiB7XG4gICAgICBzZXRUaW1lTGVmdFNlY29uZHMoKGN1cnJlbnQpID0+IHtcbiAgICAgICAgaWYgKGN1cnJlbnQgPD0gMSkge1xuICAgICAgICAgIHdpbmRvdy5jbGVhckludGVydmFsKHRpbWVyKTtcbiAgICAgICAgICBzZXRJc0V4cGlyZWQodHJ1ZSk7XG4gICAgICAgICAgcmV0dXJuIDA7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGN1cnJlbnQgLSAxO1xuICAgICAgfSk7XG4gICAgfSwgMTAwMCk7XG5cbiAgICByZXR1cm4gKCkgPT4gd2luZG93LmNsZWFySW50ZXJ2YWwodGltZXIpO1xuICB9LCBbdGltZUxlZnRTZWNvbmRzXSk7XG5cbiAgY29uc3QgZm9ybWF0dGVkVGltZSA9IHVzZU1lbW8oKCkgPT4ge1xuICAgIGNvbnN0IG1pbnV0ZXMgPSBNYXRoLmZsb29yKHRpbWVMZWZ0U2Vjb25kcyAvIDYwKTtcbiAgICBjb25zdCBzZWNvbmRzID0gdGltZUxlZnRTZWNvbmRzICUgNjA7XG4gICAgcmV0dXJuIGAke21pbnV0ZXMudG9TdHJpbmcoKS5wYWRTdGFydCgyLCBcIjBcIil9OiR7c2Vjb25kcy50b1N0cmluZygpLnBhZFN0YXJ0KDIsIFwiMFwiKX1gO1xuICB9LCBbdGltZUxlZnRTZWNvbmRzXSk7XG5cbiAgY29uc3QgaGFuZGxlUnVuQ29kZSA9IGFzeW5jICgpID0+IHtcbiAgICBpZiAoIXRva2VuIHx8IGlzRXhwaXJlZCkgcmV0dXJuO1xuXG4gICAgdHJ5IHtcbiAgICAgIHNldFJ1bkxvYWRpbmcodHJ1ZSk7XG4gICAgICBzZXRSdW5UZXN0UmVzdWx0U3VtbWFyeShcIlwiKTtcbiAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHJ1bkNvZGUoe1xuICAgICAgICBzb3VyY2VfY29kZTogY29kZSxcbiAgICAgICAgbGFuZ3VhZ2UsXG4gICAgICAgIHN0ZGluLFxuICAgICAgICBpbnZpdGF0aW9uX3Rva2VuOiB0b2tlbixcbiAgICAgIH0pO1xuICAgICAgc2V0U3Rkb3V0KHJlc3VsdC5zdGRvdXQgfHwgcmVzdWx0LnN0ZGVyciB8fCBcIk5vIG91dHB1dFwiKTtcbiAgICAgIGlmIChyZXN1bHQudGVzdF9yZXN1bHRzKSB7XG4gICAgICAgIGNvbnN0IHRyID0gcmVzdWx0LnRlc3RfcmVzdWx0cztcbiAgICAgICAgc2V0UnVuVGVzdFJlc3VsdFN1bW1hcnkoYFBhc3NlZCAke3RyLnBhc3NlZH0gLyAke3RyLnRvdGFsfWApO1xuICAgICAgICBzZXRUZXN0Q2FzZXMoKHByZXZDYXNlcykgPT4ge1xuICAgICAgICAgIHJldHVybiBwcmV2Q2FzZXMubWFwKChjLCBpZHgpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHJ1bkluZm8gPSB0ci5yZXN1bHRzPy5baWR4XTtcbiAgICAgICAgICAgIGlmIChydW5JbmZvKSB7XG4gICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgLi4uYyxcbiAgICAgICAgICAgICAgICBwYXNzZWQ6IHJ1bkluZm8ucGFzc2VkLFxuICAgICAgICAgICAgICAgIGFjdHVhbDogcnVuSW5mby5hY3R1YWwsXG4gICAgICAgICAgICAgICAgcnVuOiB0cnVlXG4gICAgICAgICAgICAgIH07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gYztcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG4gICAgICAgIGlmICh0ci5wYXNzZWQgPT09IHRyLnRvdGFsKSB7XG4gICAgICAgICAgdG9hc3Quc3VjY2VzcyhcIkNvZGUgZXhlY3V0aW9uIHN1Y2Nlc3NmdWwuXCIpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHRvYXN0LmVycm9yKFwiVGVzdCBjYXNlcyBmYWlsZWQuXCIpO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBpZiAocmVzdWx0LnN0ZG91dCA9PT0gXCJjb2RlIGV4ZWN1dGlvbiBzdWNjZXNzZnVsXCIpIHtcbiAgICAgICAgICB0b2FzdC5zdWNjZXNzKFwiQ29kZSBleGVjdXRpb24gc3VjY2Vzc2Z1bC5cIik7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgdG9hc3QuZXJyb3IoXCJUZXN0IGNhc2VzIGZhaWxlZC5cIik7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgdG9hc3QuZXJyb3IoXCJFeGVjdXRpb24gZmFpbGVkLlwiKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0UnVuTG9hZGluZyhmYWxzZSk7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jICgpID0+IHtcbiAgICBpZiAoIXRva2VuIHx8IGlzRXhwaXJlZCkge1xuICAgICAgdG9hc3QuZXJyb3IoXCJUaGlzIGFzc2Vzc21lbnQgY2FuIG5vIGxvbmdlciBiZSBzdWJtaXR0ZWQuXCIpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBzZXRTdWJtaXRMb2FkaW5nKHRydWUpO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IHN1Ym1pdFNvbHV0aW9uKHtcbiAgICAgICAgaW52aXRhdGlvbl90b2tlbjogdG9rZW4sXG4gICAgICAgIHNvdXJjZV9jb2RlOiBjb2RlLFxuICAgICAgICBsYW5ndWFnZSxcbiAgICAgIH0pO1xuXG4gICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzID09PSAyMDIpIHtcbiAgICAgICAgc2V0UHJvY2Vzc2luZ0FzeW5jKHRydWUpO1xuICAgICAgICBjb25zdCBzdWJJZCA9IHJlc3BvbnNlLmRhdGEuc3VibWlzc2lvbl9pZDtcblxuICAgICAgICBsZXQgYXR0ZW1wdHMgPSAwO1xuICAgICAgICBjb25zdCBtYXhBdHRlbXB0cyA9IDYwOyAvLyA5MCBzZWNvbmRzIG1heFxuICAgICAgICBjb25zdCBwb2xsSW50ZXJ2YWwgPSAxNTAwOyAvLyAxLjUgc2Vjb25kc1xuXG4gICAgICAgIHdoaWxlIChhdHRlbXB0cyA8IG1heEF0dGVtcHRzKSB7XG4gICAgICAgICAgYXdhaXQgbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHNldFRpbWVvdXQocmVzb2x2ZSwgcG9sbEludGVydmFsKSk7XG4gICAgICAgICAgYXR0ZW1wdHMrKztcbiAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3QgY2hlY2tSZXMgPSBhd2FpdCBnZXRTdWJtaXNzaW9uKHN1YklkKTtcbiAgICAgICAgICAgIGlmIChjaGVja1Jlcy5zY29yZSAhPT0gbnVsbCAmJiBjaGVja1Jlcy5zY29yZSAhPT0gdW5kZWZpbmVkICYmIGNoZWNrUmVzLmFpX2V2YWx1YXRpb24pIHtcbiAgICAgICAgICAgICAgc2V0U3VibWl0dGVkKHRydWUpO1xuICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9IGNhdGNoIChwb2xsRXJyKSB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKFwiUG9sbGluZyBlcnJvcjpcIiwgcG9sbEVycik7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmIChhdHRlbXB0cyA+PSBtYXhBdHRlbXB0cykge1xuICAgICAgICAgIHRvYXN0LmVycm9yKFwiRXZhbHVhdGlvbiBpcyB0YWtpbmcgbG9uZ2VyIHRoYW4gZXhwZWN0ZWQuIFBsZWFzZSBjaGVjayB5b3VyIGRhc2hib2FyZCBsYXRlci5cIik7XG4gICAgICAgIH1cbiAgICAgICAgc2V0UHJvY2Vzc2luZ0FzeW5jKGZhbHNlKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHNldFN1Ym1pdHRlZCh0cnVlKTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgdG9hc3QuZXJyb3IoZXJyPy5yZXNwb25zZT8uZGF0YT8uZGV0YWlsIHx8IFwiU3VibWlzc2lvbiBmYWlsZWRcIik7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldFN1Ym1pdExvYWRpbmcoZmFsc2UpO1xuICAgICAgc2V0UHJvY2Vzc2luZ0FzeW5jKGZhbHNlKTtcbiAgICB9XG4gIH07XG5cbiAgaWYgKGxvYWRpbmcpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG1pbi1oLVs3MHZoXSBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctc2xhdGUtOTUwXCI+XG4gICAgICAgIDxTcGlubmVyIGxhYmVsPVwiUHJlcGFyaW5nIGFzc2Vzc21lbnRcIiAvPlxuICAgICAgPC9kaXY+XG4gICAgKTtcbiAgfVxuXG4gIGlmICghdG9rZW4gfHwgbm90Rm91bmQpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG1pbi1oLVs3MHZoXSBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctc2xhdGUtOTUwIHB4LTZcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtdy1tZCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIGJnLXNsYXRlLTkwMCBwLTggdGV4dC1jZW50ZXIgdGV4dC1zbGF0ZS0yMDBcIj5cbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZCB0ZXh0LXdoaXRlXCI+NDA0IOKAlCBBc3Nlc3NtZW50IG5vdCBmb3VuZDwvaDI+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtc2xhdGUtNDAwXCI+VGhpcyBhc3Nlc3NtZW50IGxpbmsgaXMgaW52YWxpZCBvciBtaXNzaW5nLjwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICApO1xuICB9XG5cbiAgaWYgKHN1Ym1pdHRlZCkge1xuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWluLWgtc2NyZWVuIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBiZy1zbGF0ZS05NTAgcHgtNiBhbmltYXRlLWZhZGUtaW5cIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtdy1tZCB0ZXh0LWNlbnRlciB0ZXh0LXNsYXRlLTIwMFwiPlxuICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTR4bCBmb250LWJvbGQgdGV4dC13aGl0ZSBtYi00XCI+VGhhbmsgWW91ITwvaDE+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgdGV4dC1zbSBsZWFkaW5nLTZcIj5cbiAgICAgICAgICAgIFlvdXIgYXNzZXNzbWVudCBoYXMgYmVlbiBzdWNjZXNzZnVsbHkgc3VibWl0dGVkLiBZb3UgbWF5IG5vdyBjbG9zZSB0aGlzIHdpbmRvdy5cbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgKTtcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gYmctc2xhdGUtOTAwIHRleHQtc2xhdGUtMTAwXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWluLWgtc2NyZWVuIGZsZXgtY29sIGxnOmZsZXgtcm93XCI+XG4gICAgICAgIDxhc2lkZSBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBiZy1zbGF0ZS05NTAgcC02IGxnOnctWzQwJV0gbGc6Ym9yZGVyLWItMCBsZzpib3JkZXItclwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTNcIj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkIHRleHQtd2hpdGVcIj57YXNzZXNzbWVudFRpdGxlIHx8IFwiQXNzZXNzbWVudFwifTwvaDE+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMiBpbmxpbmUtZmxleCByb3VuZGVkLWZ1bGwgYmctc2xhdGUtODAwIHB4LTIuNSBweS0xIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS0yMDBcIj57ZGlmZmljdWx0eX08L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLW1kIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIGJnLXNsYXRlLTkwMCBweC0zIHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTIwMFwiPntmb3JtYXR0ZWRUaW1lfTwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTYgb3ZlcmZsb3cteS1hdXRvIHByLTFcIj5cbiAgICAgICAgICAgIDxzZWN0aW9uPlxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwibWItMiB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgdGV4dC1zbGF0ZS00MDBcIj5Qcm9ibGVtPC9oMj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwid2hpdGVzcGFjZS1wcmUtd3JhcCB0ZXh0LXNtIGxlYWRpbmctNyB0ZXh0LXNsYXRlLTIwMFwiPntwcm9ibGVtU3RhdGVtZW50fTwvcD5cbiAgICAgICAgICAgIDwvc2VjdGlvbj5cblxuICAgICAgICAgICAgPHNlY3Rpb24+XG4gICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJtYi0yIHRleHQtc20gZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSB0ZXh0LXNsYXRlLTQwMFwiPkNvbnN0cmFpbnRzPC9oMj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwid2hpdGVzcGFjZS1wcmUtd3JhcCB0ZXh0LXNtIGxlYWRpbmctNyB0ZXh0LXNsYXRlLTIwMFwiPntjb25zdHJhaW50c308L3A+XG4gICAgICAgICAgICA8L3NlY3Rpb24+XG5cbiAgICAgICAgICAgIDxzZWN0aW9uPlxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwibWItMiB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgdGV4dC1zbGF0ZS00MDBcIj5FeGFtcGxlczwvaDI+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIndoaXRlc3BhY2UtcHJlLXdyYXAgdGV4dC1zbSBsZWFkaW5nLTcgdGV4dC1zbGF0ZS0yMDBcIj57ZXhhbXBsZXN9PC9wPlxuICAgICAgICAgICAgPC9zZWN0aW9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2FzaWRlPlxuXG4gICAgICAgIDxtYWluIGNsYXNzTmFtZT1cImZsZXgtMSBiZy1zbGF0ZS05MDAgcC02XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi00IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtM1wiPlxuICAgICAgICAgICAgPExhbmd1YWdlU2VsZWN0b3IgdmFsdWU9e2xhbmd1YWdlfSBvbkNoYW5nZT17c2V0TGFuZ3VhZ2V9IC8+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8Q29kZUVkaXRvciBsYW5ndWFnZT17bGFuZ3VhZ2V9IHZhbHVlPXtjb2RlfSBvbkNoYW5nZT17c2V0Q29kZX0gLz5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNSBncmlkIGdhcC01IHhsOmdyaWQtY29scy1bMWZyXzEuMmZyXVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLWxnIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIGJnLXNsYXRlLTk1MCBwLTRcIj5cbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cIm1iLTIgYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTMwMFwiPklucHV0PC9sYWJlbD5cbiAgICAgICAgICAgICAgPHRleHRhcmVhIHZhbHVlPXtzdGRpbn0gb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0U3RkaW4oZXZlbnQudGFyZ2V0LnZhbHVlKX0gY2xhc3NOYW1lPVwibWluLWgtMjggdy1mdWxsIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgYmctc2xhdGUtOTAwIHB4LTMgcHktMiB0ZXh0LXNtIHRleHQtc2xhdGUtMTAwIG91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItYnJhbmQtNTAwIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJyYW5kLTkwMFwiIHBsYWNlaG9sZGVyPVwiRW50ZXIgc3RkaW4gaGVyZVwiIC8+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLWxnIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIGJnLXNsYXRlLTk1MCBwLTRcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0yIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS0zMDBcIj5PdXRwdXQ8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8cHJlIGNsYXNzTmFtZT1cIm1pbi1oLTI4IHdoaXRlc3BhY2UtcHJlLXdyYXAgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCBiZy1zbGF0ZS05MDAgcC0zIHRleHQtc20gdGV4dC1zbGF0ZS0xMDBcIj57c3Rkb3V0fTwvcHJlPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogVGVzdCBDYXNlcyBQYW5lbCAqL31cbiAgICAgICAgICB7dGVzdENhc2VzLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgYmctc2xhdGUtOTUwIHAtNFwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgcGItMlwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0cmFja2luZy13aWRlciB1cHBlcmNhc2UgdGV4dC1zbGF0ZS00MDBcIj5UZXN0IENhc2VzPC9zcGFuPlxuICAgICAgICAgICAgICAgIHtydW5UZXN0UmVzdWx0U3VtbWFyeSAmJiAoXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2B0ZXh0LXhzIGZvbnQtYm9sZCBweC0yIHB5LTAuNSByb3VuZGVkICR7XG4gICAgICAgICAgICAgICAgICAgICgoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgY29uc3QgcGFydHMgPSBydW5UZXN0UmVzdWx0U3VtbWFyeS5yZXBsYWNlKFwiUGFzc2VkIFwiLCBcIlwiKS5zcGxpdChcIiAvIFwiKTtcbiAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gcGFydHNbMF0gIT09IHBhcnRzWzFdO1xuICAgICAgICAgICAgICAgICAgICB9KSgpXG4gICAgICAgICAgICAgICAgICAgICAgPyBcImJnLXJvc2UtOTUwLzYwIHRleHQtcm9zZS00MDAgYm9yZGVyIGJvcmRlci1yb3NlLTgwMC82MFwiXG4gICAgICAgICAgICAgICAgICAgICAgOiBcImJnLWVtZXJhbGQtOTUwLzYwIHRleHQtZW1lcmFsZC00MDAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTgwMC82MFwiXG4gICAgICAgICAgICAgICAgICB9YH0+XG4gICAgICAgICAgICAgICAgICAgIHtydW5UZXN0UmVzdWx0U3VtbWFyeX1cbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxuICAgICAgICAgICAgICAgIHt0ZXN0Q2FzZXMubWFwKCh0YywgaWR4KSA9PiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IGtleT17dGMuaWQgfHwgaWR4fSBjbGFzc05hbWU9XCJyb3VuZGVkLW1kIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGJnLXNsYXRlLTkwMC80MCBwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7dGMuaXNfaGlkZGVuID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIPCflJIgSGlkZGVuIFRlc3QgQ2FzZSB7aWR4ICsgMX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtMzUwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgVmlzaWJsZSBUZXN0IENhc2Uge2lkeCArIDF9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAge3RjLnJ1biAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2B0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgcHgtMiBweS0wLjUgcm91bmRlZCAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICB0Yy5wYXNzZWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctZW1lcmFsZC05NTAgdGV4dC1lbWVyYWxkLTQwMCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtOTAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiYmctcm9zZS05NTAgdGV4dC1yb3NlLTQwMCBib3JkZXIgYm9yZGVyLXJvc2UtOTAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge3RjLnBhc3NlZCA/IFwiUGFzc2VkXCIgOiBcIkZhaWxlZFwifVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgIHshdGMuaXNfaGlkZGVuICYmIChcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTMgZ3JpZCBnYXAtMyBtZDpncmlkLWNvbHMtMiB0ZXh0LXhzIGZvbnQtbW9ub1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdXBwZXJjYXNlIHRleHQtc2xhdGUtNTAwIGZvbnQtYm9sZCBibG9jayBtYi0xXCI+SW5wdXQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwcmUgY2xhc3NOYW1lPVwicm91bmRlZCBiZy1zbGF0ZS05NTAgcC0yIGJvcmRlciBib3JkZXItc2xhdGUtODAwIG92ZXJmbG93LXgtYXV0byB0ZXh0LXNsYXRlLTMwMCBtYXgtaC0yNFwiPnt0Yy5pbnB1dH08L3ByZT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdXBwZXJjYXNlIHRleHQtc2xhdGUtNTAwIGZvbnQtYm9sZCBibG9jayBtYi0xXCI+RXhwZWN0ZWQgT3V0cHV0PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cHJlIGNsYXNzTmFtZT1cInJvdW5kZWQgYmctc2xhdGUtOTUwIHAtMiBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBvdmVyZmxvdy14LWF1dG8gdGV4dC1zbGF0ZS0zMDAgbWF4LWgtMjRcIj57dGMuZXhwZWN0ZWRfb3V0cHV0fTwvcHJlPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICB7dGMucnVuICYmIHRjLmFjdHVhbCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLXNwYW4tMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHVwcGVyY2FzZSB0ZXh0LXNsYXRlLTUwMCBmb250LWJvbGQgYmxvY2sgbWItMVwiPkFjdHVhbCBPdXRwdXQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHByZSBjbGFzc05hbWU9e2Byb3VuZGVkIHAtMiBib3JkZXIgb3ZlcmZsb3cteC1hdXRvIG1heC1oLTI0ICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0Yy5wYXNzZWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJnLXNsYXRlLTk1MCBib3JkZXItc2xhdGUtODAwIHRleHQtc2xhdGUtMjAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcImJnLXJvc2UtOTUwLzIwIGJvcmRlci1yb3NlLTkwMC80MCB0ZXh0LXJvc2UtMzAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH0+e3RjLmFjdHVhbH08L3ByZT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNSBmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW1cIj5cbiAgICAgICAgICAgICAge3J1blRlc3RSZXN1bHRTdW1tYXJ5ICYmIChcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e1xuICAgICAgICAgICAgICAgICAgKCgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcGFydHMgPSBydW5UZXN0UmVzdWx0U3VtbWFyeS5yZXBsYWNlKFwiUGFzc2VkIFwiLCBcIlwiKS5zcGxpdChcIiAvIFwiKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHBhcnRzWzBdICE9PSBwYXJ0c1sxXTtcbiAgICAgICAgICAgICAgICAgIH0pKClcbiAgICAgICAgICAgICAgICAgICAgPyBcInRleHQtcm9zZS00MDBcIlxuICAgICAgICAgICAgICAgICAgICA6IFwidGV4dC1lbWVyYWxkLTQwMFwiXG4gICAgICAgICAgICAgICAgfT5cbiAgICAgICAgICAgICAgICAgIHsoKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBwYXJ0cyA9IHJ1blRlc3RSZXN1bHRTdW1tYXJ5LnJlcGxhY2UoXCJQYXNzZWQgXCIsIFwiXCIpLnNwbGl0KFwiIC8gXCIpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBwYXNzZWRDb3VudCA9IHBhcnNlSW50KHBhcnRzWzBdLCAxMCk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHRvdGFsQ291bnQgPSBwYXJzZUludChwYXJ0c1sxXSwgMTApO1xuICAgICAgICAgICAgICAgICAgICBpZiAocGFzc2VkQ291bnQgIT09IHRvdGFsQ291bnQpIHtcbiAgICAgICAgICAgICAgICAgICAgICBpZiAodG90YWxDb3VudCA9PT0gMSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFwidGVzdCAxLzEgZmFpbGVkXCI7XG4gICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBgdGVzdCBjYXNlcyBmYWlsZWQ6ICR7cGFzc2VkQ291bnR9LyR7dG90YWxDb3VudH0gcGFzc2VkYDtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gXCJhbGwgdGVzdCBjYXNlcyBwYXNzZWRcIjtcbiAgICAgICAgICAgICAgICAgIH0pKCl9XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtM1wiPlxuICAgICAgICAgICAgICA8QnV0dG9uIHR5cGU9XCJidXR0b25cIiB2YXJpYW50PVwic2Vjb25kYXJ5XCIgZGlzYWJsZWQ9e3J1bkxvYWRpbmcgfHwgaXNFeHBpcmVkfSBvbkNsaWNrPXtoYW5kbGVSdW5Db2RlfT5cbiAgICAgICAgICAgICAgICB7cnVuTG9hZGluZyA/IDxTcGlubmVyIGxhYmVsPVwiUnVubmluZ1wiIC8+IDogXCJSdW4gQ29kZVwifVxuICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgPEJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgZGlzYWJsZWQ9e3N1Ym1pdExvYWRpbmcgfHwgaXNFeHBpcmVkfSBvbkNsaWNrPXtoYW5kbGVTdWJtaXR9PlxuICAgICAgICAgICAgICAgIHtzdWJtaXRMb2FkaW5nID8gPFNwaW5uZXIgbGFiZWw9XCJTdWJtaXR0aW5nXCIgLz4gOiBcIlN1Ym1pdFwifVxuICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L21haW4+XG4gICAgICA8L2Rpdj5cblxuICAgICAge3Byb2Nlc3NpbmdBc3luYyAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJnLXNsYXRlLTk1MC83MCBwLTRcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBtYXgtdy1tZCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIGJnLXNsYXRlLTkwMCBwLTYgc2hhZG93LXhsIHRleHQtY2VudGVyIGFuaW1hdGUtZmFkZS1pblwiPlxuICAgICAgICAgICAgPFNwaW5uZXIgbGFiZWw9XCJFdmFsdWF0aW5nIHN1Ym1pc3Npb24uLi5cIiAvPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtNCB0ZXh0LXNtIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgIFJ1bm5pbmcgdGVzdCBjYXNlcyBhbmQgZ2VuZXJhdGluZyBBSSBmZWVkYmFjay4gVGhpcyBtYXkgdGFrZSBhIGZldyBzZWNvbmRzLi4uXG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiQzovVXNlcnMvWWFzd2FudGggUmFodWwvRG93bmxvYWRzL0JpdExhYnMtQ29kaW5nLUxhYi9mcm9udGVuZC9zcmMvcm91dGVzL1Rha2VBc3Nlc3NtZW50LnRzeCJ9