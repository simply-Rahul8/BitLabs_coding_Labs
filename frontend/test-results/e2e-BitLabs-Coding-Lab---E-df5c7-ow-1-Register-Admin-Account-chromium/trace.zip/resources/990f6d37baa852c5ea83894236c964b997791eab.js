import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/Button.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1cbb189e"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/components/ui/Button.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
const variantClasses = {
  primary: "bg-brand-600 text-white hover:bg-brand-700 focus:ring-brand-200",
  secondary: "border border-slate-300 bg-white text-slate-700 hover:bg-slate-50 focus:ring-slate-200",
  danger: "bg-red-600 text-white hover:bg-red-700 focus:ring-red-200"
};
export default function Button({ variant = "primary", className = "", children, ...props }) {
  return /* @__PURE__ */ jsxDEV(
    "button",
    {
      className: [
        "inline-flex items-center justify-center rounded-md px-4 py-2 text-sm font-semibold shadow-sm transition focus:outline-none focus:ring-2 disabled:cursor-not-allowed disabled:opacity-60",
        variantClasses[variant],
        className
      ].join(" "),
      ...props,
      children
    },
    void 0,
    false,
    {
      fileName: "C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/components/ui/Button.tsx",
      lineNumber: 38,
      columnNumber: 5
    },
    this
  );
}
_c = Button;
var _c;
$RefreshReg$(_c, "Button");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/components/ui/Button.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Yaswanth Rahul/Downloads/BitLabs-Coding-Lab/frontend/src/components/ui/Button.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0JJOzs7Ozs7Ozs7Ozs7Ozs7O0FBUkosTUFBTUEsaUJBQWdEO0FBQUEsRUFDcERDLFNBQVM7QUFBQSxFQUNUQyxXQUFXO0FBQUEsRUFDWEMsUUFBUTtBQUNWO0FBRUEsd0JBQXdCQyxPQUFPLEVBQUVDLFVBQVUsV0FBV0MsWUFBWSxJQUFJQyxVQUFVLEdBQUdDLE1BQW1CLEdBQUc7QUFDdkcsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsV0FBVztBQUFBLFFBQ1Q7QUFBQSxRQUNBUixlQUFlSyxPQUFPO0FBQUEsUUFDdEJDO0FBQUFBLE1BQVMsRUFDVEcsS0FBSyxHQUFHO0FBQUEsTUFDVixHQUFJRDtBQUFBQSxNQUVIRDtBQUFBQTtBQUFBQSxJQVJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVNBO0FBRUo7QUFBQ0csS0FidUJOO0FBQU0sSUFBQU07QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidmFyaWFudENsYXNzZXMiLCJwcmltYXJ5Iiwic2Vjb25kYXJ5IiwiZGFuZ2VyIiwiQnV0dG9uIiwidmFyaWFudCIsImNsYXNzTmFtZSIsImNoaWxkcmVuIiwicHJvcHMiLCJqb2luIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQnV0dG9uLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBCdXR0b25IVE1MQXR0cmlidXRlcywgUHJvcHNXaXRoQ2hpbGRyZW4gfSBmcm9tIFwicmVhY3RcIjtcblxudHlwZSBCdXR0b25WYXJpYW50ID0gXCJwcmltYXJ5XCIgfCBcInNlY29uZGFyeVwiIHwgXCJkYW5nZXJcIjtcblxudHlwZSBCdXR0b25Qcm9wcyA9IFByb3BzV2l0aENoaWxkcmVuPFxuICBCdXR0b25IVE1MQXR0cmlidXRlczxIVE1MQnV0dG9uRWxlbWVudD4gJiB7XG4gICAgdmFyaWFudD86IEJ1dHRvblZhcmlhbnQ7XG4gIH1cbj47XG5cbmNvbnN0IHZhcmlhbnRDbGFzc2VzOiBSZWNvcmQ8QnV0dG9uVmFyaWFudCwgc3RyaW5nPiA9IHtcbiAgcHJpbWFyeTogXCJiZy1icmFuZC02MDAgdGV4dC13aGl0ZSBob3ZlcjpiZy1icmFuZC03MDAgZm9jdXM6cmluZy1icmFuZC0yMDBcIixcbiAgc2Vjb25kYXJ5OiBcImJvcmRlciBib3JkZXItc2xhdGUtMzAwIGJnLXdoaXRlIHRleHQtc2xhdGUtNzAwIGhvdmVyOmJnLXNsYXRlLTUwIGZvY3VzOnJpbmctc2xhdGUtMjAwXCIsXG4gIGRhbmdlcjogXCJiZy1yZWQtNjAwIHRleHQtd2hpdGUgaG92ZXI6YmctcmVkLTcwMCBmb2N1czpyaW5nLXJlZC0yMDBcIlxufTtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQnV0dG9uKHsgdmFyaWFudCA9IFwicHJpbWFyeVwiLCBjbGFzc05hbWUgPSBcIlwiLCBjaGlsZHJlbiwgLi4ucHJvcHMgfTogQnV0dG9uUHJvcHMpIHtcbiAgcmV0dXJuIChcbiAgICA8YnV0dG9uXG4gICAgICBjbGFzc05hbWU9e1tcbiAgICAgICAgXCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1tZCBweC00IHB5LTIgdGV4dC1zbSBmb250LXNlbWlib2xkIHNoYWRvdy1zbSB0cmFuc2l0aW9uIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkIGRpc2FibGVkOm9wYWNpdHktNjBcIixcbiAgICAgICAgdmFyaWFudENsYXNzZXNbdmFyaWFudF0sXG4gICAgICAgIGNsYXNzTmFtZVxuICAgICAgXS5qb2luKFwiIFwiKX1cbiAgICAgIHsuLi5wcm9wc31cbiAgICA+XG4gICAgICB7Y2hpbGRyZW59XG4gICAgPC9idXR0b24+XG4gICk7XG59XG4iXSwiZmlsZSI6IkM6L1VzZXJzL1lhc3dhbnRoIFJhaHVsL0Rvd25sb2Fkcy9CaXRMYWJzLUNvZGluZy1MYWIvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvdWkvQnV0dG9uLnRzeCJ9